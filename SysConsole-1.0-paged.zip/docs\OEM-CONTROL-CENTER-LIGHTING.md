# 官方控制台（Gaming Center 5.17.49.19）灯光效果解析

本文件记录对原厂 `ControlCenter_5.17.49.19_Mechrevo` 安装包的解包、反汇编与上机验证结果。

**一句话结论：本机 EC 固件里只有一个硬件动画 —— 彩虹（`0x767` bit7，已人眼确认），
这是早先判断失误的地方。除它之外再无第二个硬件效果；
其余花哨效果（波浪 / 跑马 / 涟漪 / 极光 …）属于四区键盘和灯带机型，本机单区键盘不支持。**

另外查出两个亮度寄存器：`0x78C` bit4~7（4 档）和 `0x7C5` 低三位（8 档，已人眼确认）。
⚠️ `0x767` 的低位与风扇有关，不要乱写 —— 见 3.8。

---

## 一、包结构与入口

| 文件 | 大小 | 说明 |
|---|---:|---|
| `ControlCenter_5.17.49.19_Mechrevo.exe` | 163.8 MB | **Inno Setup** 壳，内含完整安装内容 |
| `PreinstallKit/GamingCenter3_Cross.UWP_5.17.49.19_x64.msixbundle` | 41.5 MB | UWP 应用包（内含一个 41.2 MB 的 msix） |
| `RGBKeyboard.reg` | 526 KB | 原厂灯光配置的注册表导出 |

msix 解开后 501 个条目 / 65.7 MB，核心是：

| 文件 | 大小 | 类型 |
|---|---:|---|
| `GamingCenter3_Cross.dll` | 27.35 MB | **.NET Native 编译，无 IL**（只能抽字符串和元数据） |
| `Win32/DefaultTool.exe` | 1.19 MB | 托管程序集 —— 见下 |
| `Win32/SystrayComponent.exe` | 2.38 MB | 托管程序集（托盘） |
| `Win32/PowerToys.KeyboardManagerEngine.exe` | 0.98 MB | PowerToys 原生组件，与灯光无关 |

> ⚠️ 关键：**UWP 主程序是 .NET Native 的，`GamingCenter3_Cross.dll` 里没有 IL**，反编译不出源码。
> 但灯光逻辑的实现落在 **`DefaultTool.exe`**（未混淆的托管程序集）里，那个可以完整反汇编。

---

## 二、本机键盘类型与可用模式

注册表 `HKLM\SOFTWARE\OEM\GamingCenter2\RGBKeyboard\SingleZone` 里是本机的配置：

```json
{"save_effect":1, "MonochromeIndex":1, "BreathingIndex":1,
 "ManualIndex1":1, "ManualIndex2":5, "ManualIndex3":9,
 "ManualIndex4":13, "ManualIndex5":21, "ManualIndex6":25,
 "ManualInterval":10}
```

数据模型里只有 **单色 / 手动 / 呼吸** 三组字段（`MonochromeIndex`、`ManualIndex1..6`、`BreathingIndex`），
彩虹是程序算出来的。界面上对应的词条（从 `resources.pri` 的中文串池取到）：

```
单色模式   自定义模式   单色   静态选色   每色显示时间   颜色饱和度
选取键盘按键，设置背光颜色        键盘背光电源开关   键盘和Logo背光
开启或关闭键盘灯效电源            未动作10分钟后会自动关闭灯效
```

`GamingCenter3_Cross.dll` 里还有两个专用资源键：`strSingleZoneEffectManual`、`strSingleZoneEffectRainbow`。

**所以单区键盘（本机）的模式集是：单色 / 自定义 / 呼吸 / 彩虹。**

---

## 三、反汇编得到的实现细节

全部来自 `DefaultTool.exe`，反汇编器带自校验（解码后指令指针必须正好落在方法体末尾）。

### 3.1 `StartRainbowMode`（RVA `0x3E5B0`，自校验通过）

```csharp
WriteECRAM(0x769, 0);            // 三个电平清零
WriteECRAM(0x76A, 0);
WriteECRAM(0x76B, 0);
ReadECRAM(0x767, out v);
bitArray(v)[7] = true;           // ← 置 bit7
WriteECRAM(0x767, newValue);
```

`StopRainbowMode` 就是 `[7] = false`。

**上机验证：置 `0x767` bit7 后键盘立刻开始跑彩虹动画**（人眼确认）。

> ⚠️ **重要**：EC 跑彩虹时**完全不回写** `0x769/0x76A/0x76B`。
> 所以只盯着电平寄存器是发现不了这个效果的 —— 这正是早先"EC 没有固件效果"误判的根源。
> 早先只探测了 `0x7AB`，从未试过 `0x767` 的 bit7。

### 3.2 `SetBrightness_EC`（RVA `0x3D868`）—— 亮度档编码在 `0x78C`

```csharp
ReadECRAM(0x78C, out v);
var bits = new BitArray(new byte[]{ (byte)v });
switch (level) {
    case 1: bits[4]=1; bits[5]=1; bits[6]=0; bits[7]=0; break;   // 0x30
    case 2: bits[4]=1; bits[5]=0; bits[6]=1; bits[7]=0; break;   // 0x50
    case 3: bits[4]=1; bits[5]=1; bits[6]=1; bits[7]=0; break;   // 0x70
    case 4: bits[4]=1; bits[5]=0; bits[6]=0; bits[7]=1; break;   // 0x90
}
```

| 亮度档 | `0x78C` 值 |
|---|---|
| 1 | `0x30` |
| 2 | `0x50` |
| 3 | `0x70` |
| 4 | `0x90` |

**四档都带 bit4** —— 这就是早先往 `0x78C` 写 `0 / 32 / 64 / 96 / 128` 全部无效的原因。
该地址在 EC 地址表里正是 `ADDR_SINGLEKBL_ENABLE`（Single Keyboard Light）。

### 3.3 `Translate_EC_EffectIndex`（RVA `0x3C6C5`，自校验通过）

```csharp
switch (appIndex) {
    case 0:  return 1;
    case 1:  return 2;
    case 2:  return 255;    // 无
    case 3:  return 255;    // 无
    case 4:  return 5;
}
if (appIndex == 24) return 64;
return 255;
```

### 3.4 `StartManualMode` / `InitManualMode`（RVA `0x3E758` / `0x3E684`，均自校验通过）

```csharp
timer.Interval = ManualInterval * 1000;   // 秒 → 毫秒
timer.Start();
_TimersTimer_Elapsed(this, null);         // 立刻先切一次
```

`InitManualMode` 里把 `Interval` 先设成 `double.MaxValue`，`AutoReset = true`，然后挂上 `Elapsed`。
**原厂的"自定义模式"就是每 `ManualInterval` 秒换一个颜色，默认 10 秒。**

### 3.5 `AP_Effect_Task`（RVA `0x78A4`，方法体 **20290 字节**）

这是原厂的软件效果引擎。开头就是：

```csharp
Color[] a = new Color[3];
Color[] b = new Color[126];      // ← 126 色调色板
...
SetColor(...)
```

**126 色的调色板**解释了注册表里 `ManualIndex1..6 = 1/5/9/13/21/25` —— 它们是这个表的下标。
（该方法的 RVA 有效但自校验未通过，只取到开头这一段；完整还原需要更细的分支跟踪。）

### 3.6 `Set_Lighting_Effect`（RVA `0x10F08`）

按效果 ID 分发的入口：

```csharp
if (effect == 255) return;                    // 无
if (effect == 34)  { ... DLL_SetMusicMode(...); }   // 音乐模式走 HID
if (effect == 1)   SetSingleEffect(...);
// 另外还会调用 SingleEffectReset / Set_ITE_Effect_Type_ApMode_Stop / BatteryEable
```

### 3.7 `0x7C5` 低三位 = 亮度档（8 档，**上机验证**）

`RunEffctEC`（RVA `0x38450`，方法体 1764 字节）里有一段：

```csharp
ec.Write(0x767, (byte)(ec.Read(0x767) & 0x7F));   // 清掉 bit7（彩虹位）
ec.Write(0x7C5, (byte)(ec.Read(0x7C5) & 0xF8));   // 清掉低三位
```

把 `0x7C5` 的低三位从 0 轮播到 7，**人眼观察到背光有明显的明暗变化** ——
这是第二个亮度寄存器，而且是 **8 档**，比 `0x78C` 的 4 档更细。

⚠️ 注意 `0x7C5` 在 `RecoveryBatteryLogoECValue`、`RunEffctECALogo` 里也出现，
所以它可能同时服务键盘背光和 A 面 Logo / 电池灯。

### 3.8 ⚠️ `0x767` 的低位与风扇有关 —— 不要乱写

把 `0x767` 的 bit0~3 从 0 扫到 15（每值停 1.5 秒）时，**风扇出现了有节奏的加速**（人耳观察）。
同时 EC 会**改写**部分取值（写 `0x05` 读回 `0x04`、写 `0x07` 读回 `0x04`、
写 `0x0B` 读回 `0x03`、写 `0x0C` 读回 `0x04`、写 `0x0D` 读回 `0x05`），
说明 bit0~3 不是自由位，有明确语义。

地址表里 `0x767` 的名字是 `ADDR_TRIGGER_BYTE`（`0x75D` 是 `ADDR_TRIGGER_BYTE2`），
推测 bit0~3 是给 EC 的"AP 触发/心跳"类信号，EC 会据此调整风扇策略。

**本控制台只写 bit5（电平提交位）并保留其它位，是安全的**；
但**不要**把 `0x767` 当成通用位桶来试。

### 3.8b `0x7AB` 是 **A 面 Logo 灯**，不是键盘灯

`SetBrightnessALogo`（RVA `0x1A924`）把亮度档编码进 `0x7AB` 的 **bit5~7**：

```csharp
int v = 64;                                   // 默认 0x40
switch (level) { case 0: v=0; case 1: v=32; case 2: v=64; case 3: v=96; case 4: v=128; }
Read(0x7AB, out cur);
Write(0x7AB, (byte)((cur & 31) | v));         // 低 5 位原样保留，高 3 位放亮度档
```

所以 `0x7AB` 低 5 位 = Logo 灯的模式/效果索引，高 3 位 = 亮度档（5 档）。
**这就是早先拿 `0x7AB` 的 0~31 去试键盘灯毫无反应的原因 —— 那个寄存器管的是 A 面 Logo 灯。**

### 3.8c `0x7C5` 低三位 = 键盘的硬件状态指示（会盖住软件写的颜色）

`RunEffctEC` 里会 `Write(0x7C5, Read(0x7C5) & 0xF8)`（清低三位），
`RecoveryBatteryLogoECValue`（RVA `0x2DB4`，自校验通过）会 `0x7C5 &= 0xBF`（清 bit6）。

**上机实测**：把 `0x7C5` 的低三位设成非零值，键盘会出现**硬件闪烁**，
实测出现三种颜色（黄 / 红 / 蓝），过程中固定写入的红色会被覆盖。
结合 `RecoveryBatteryLogoECValue` 这个名字，这些很可能是**电量 / 充电状态指示**，
而不是装饰性效果。

**逐值实测结果**（每段前全黑 1.8 秒作分隔，段内保持 9 秒，底色固定暗红）：

| `0x7C5` 低三位 | 现象 |
|---|---|
| 0 | 正常 —— 显示程序写入的颜色 |
| **1** | **黄色闪烁** |
| **2** | **红色闪烁** |
| **3** | **绿色闪烁** |
| **4** | **蓝色闪烁** |
| 5 / 6 / 7 | 无反应（实测到第 4 段之后再无变化） |

**结论：这是 4 个固定颜色的闪烁指示，不是可自定义的装饰性效果。**
颜色由取值固定，跟程序写进去的底色无关；再结合 `RecoveryBatteryLogoECValue`
也操作同一个寄存器，几乎可以确定它是**电量 / 充电之类的状态指示**，
而不是给应用层用的灯效。所以**没有把它做成灯效选项** —— 那等于劫持状态指示，
而且电池状态一变就会被 EC 覆盖。

**它的真正价值在于**：这是一段会被 EC 自己拉起来的硬件状态，
一旦非零就会把程序写的颜色盖掉。所以 `ClearEffectState()` 必须在每次起灯效前清掉它。

**实践结论**：跑灯效之前**必须**按原厂的做法复位一次 `0x7C5` 低三位，
否则残留的硬件指示状态会把我们写的颜色盖掉。本控制台的
`Ec.KbColor.ClearEffectState()` 就是干这个的，在 `StartLightFx()` 里调用。

### 3.8d 亮度：三个候选全部排除

| 候选 | 结论 |
|---|---|
| `0x78C` bit4~7 | 本机 EC 会把写入顶回去（读回恒为 `0x80`），且疑似 `L4_PWM_DEFAULT_MYFAN2`（风扇 PWM）→ **不能用** |
| `0x7C5` 低三位 | 是硬件状态指示，不是亮度 → **不能用** |
| `0x7AB` bit5~7 | 是 **A 面 Logo 灯**的亮度，不是键盘 → **不能用** |

所以本控制台**刻意不提供键盘亮度设置项** —— 不是偷懒，是三个候选地址都不安全或不对口。

### 3.9 灯光代码真正碰过的 EC 地址（全量）

把 `DefaultTool.exe` 里所有 `WriteECRAM` / `ReadECRAM` 调用点与实例 `Read`/`Write`
调用点的寄存器常量都扫出来之后，**EC 灯光路径的寄存器面就是这些**：

| 地址 | 读 | 写 | 用途 |
|---|---|---|---|
| `0x767` | ✔ | ✔ | bit5 = 电平提交；**bit7 = 硬件彩虹**；bit0~3 与风扇有关（勿动） |
| `0x769/76A/76B` | | ✔ | R/G/B 电平（1..50） |
| `0x76C/76D/76E` | ✔ | | 出厂默认 R/G/B |
| `0x78C` | ✔ | ✔ | bit4~7 = 亮度档（4 档）；`ADDR_SINGLEKBL_ENABLE` |
| `0x7C5` | ✔ | ✔ | 低三位 = 亮度档（8 档） |
| `0x7AB` | ✔ | ✔ | 原厂自记的"当前模式"标记，**不驱动硬件** |
| `0x766` | ✔ | ✔ | 亮度相关的扫描码路径（`ScanCodeUpdatedBrightness`） |
| `0x73C` / `0x740` | ✔ | | 机型/布局判定（`Translate_Layout_LightValue`、`GetProjectID`） |
| `0x741` | | ✔ | `Set_APExistToEC`、`Enable_EC_OnkeyPressed` |
| `0x742` / `0x78E` | ✔ | | 支持位（`isSupportRGBLBFromEC`、`GetSingleZonePowerSupport`） |

**除此之外没有别的灯光寄存器了。** 也就是说：**EC 侧只有一个硬件动画（彩虹）**，
其余效果全部是软件算帧写 `0x769/76A/76B`。

> 方法论提醒：扫 IL 常量时，`ldc.i4 0x7xx` 不一定是 EC 地址 ——
> `RunEffctEC` 里的 `0x731 / 0x734 / 0x752 / 0x755 / 0x77C / 0x780`
> 其实是 `TraceMessage` 的**行号参数**（1841/1844/1874/1877/1916/1920 行）。
> 第一遍扫描就被这个骗了。

### 3.10 结论：本机的硬件灯效资源已经穷尽

逐个验证过之后，**六个候选全部有了明确结论，只剩彩虹一个可用**：

| 候选 | 状态 | 依据 |
|---|---|---|
| `0x767` **bit7** | ✅ **可用 —— 硬件彩虹** | 上机验证：置位后键盘立刻跑彩虹，且不回写电平寄存器 |
| `0x767` bit0~3 | ❌ 不可碰 | 实测写入过程中**风扇有节奏地加速**，且 EC 会改写部分取值 |
| `0x7C5` 低三位 | ❌ 不是装饰效果 | 实测只有 **4 个固定颜色的闪烁**（1=黄 2=红 3=绿 4=蓝，5~7 无效），**与底色无关**，疑似电量/充电指示 |
| `0x78C` bit4~7 | ❌ 不可用 | 本机 EC 会把写入**顶回**（读回恒为 `0x80`），地址表里还可能是 `L4_PWM_DEFAULT_MYFAN2`（风扇 PWM） |
| `0x7AB`（A 面 Logo） | ❌ **本机无此灯** | 从 0 到 `0x20/0x40/0x60/0x80/0x9F/0x1F` 逐档试过，**键盘之外任何位置都没有变化**（已请用户从屏幕背面确认）。IL 里 `SetBrightnessALogo` 开头就有 `if (field != 1) 跳过` 的机型开关，本机没通过这个门 |
| `0x769/76A/76B` | — | 只是电平，不是效果 |

**为什么可以断定"穷尽"**：`DefaultTool.exe` 里对键盘灯光的**直接 `WriteECRAM` 调用只有 10 处**，
全部落在 `0x3C655`~`0x3C859` 那一小段里（`SetRGBLevel` / `StartRainbowMode` / `StopRainbowMode`）；
其余经包装类 `get_Instance().Write` 的调用点在 `RunEffctEC`（键盘）和 `RunEffctECALogo`（A 面 Logo），
用到的寄存器就是上表这几个。把整个文件的 `ldc.i4` 立即数按 EC 区间扫一遍，也没有更多地址。

**所以：能借硬件做的灯效只有彩虹那一个，已经做进控制台了。**
想要更多效果就只能在软件层做（呼吸 / 渐变 / 扩散光等都属此类，原厂也是这么干的）——
那部分本控制台早先实现过，后来按要求精简掉了。

---

## 四、完整效果清单（来自应用图标与字符串表）

`Assets/Image/effect/` 下每个效果都有 `-n`（常态）/`-h`（悬停）/`-s`（选中）三态图标：

| 图标名 | 中文（来自 `resources.pri`） | 本机单区可用 |
|---|---|---|
| `single` / `monoshuffle` | 单色 / 单色轮换 | ✅ |
| `manual` | 自定义（每色显示时间） | ✅ |
| `breathing` | 呼吸 | ✅ |
| `rainbow` | 彩虹 | ✅ 硬件 |
| `wave` | 波浪 / 炫彩波浪 | ❌ 需多区或灯带 |
| `marquee` | 跑马 / 七彩跑马 | ❌ |
| `ripple` | 涟漪 | ❌ |
| `aurora` | 极光 | ❌ |
| `neon` | 霓虹 | ❌ |
| `spark` | 火花 | ❌ |
| `metor` | 流星 | ❌ |
| `flash` | 闪烁 | ❌ |
| `dawn` | 晨光 | ❌ |
| `clash` | 冲突 / 对战 | ❌ |
| `catchup` | 追赶 | ❌ |
| `devour` | 吞噬 | ❌ |
| `impact` | 冲击 | ❌ |
| `thinking` | 思考 | ❌ |
| `music` | 音乐模式 | ❌ |
| `raindrop` | 雨滴 | ❌ |
| `reactive` | 按键响应 | ❌ |
| `alphabet` | 字母 | ❌ |
| `batterypercent` | 电量 | ❌ |
| `gaming` | 游戏 | ❌ |
| `none` | 无 | — |

另有方向类图标 `btn-in / btn-out / btn-up / btn-down / btn-L / btn-R`（对应 `运行方向` 设置项）。

**为什么单区只能用前四个**：波浪 / 跑马 / 涟漪 / 极光这类效果本质是**空间上的**（不同区域不同颜色、
或颜色沿键盘流动）。本机是 EC 单区键盘，`0x769/76A/76B` 一次只能显示一个颜色，
没有分区 / 逐键能力。原厂代码里的 `FourZoneKeyboard`、`HIDKeyboard`、`HIDLightbar*` 路线在本机都不适用
（内置键盘是 PS/2 的，枚举不到 HID 灯光设备）。

---

## 五、对本控制台的影响

1. **早先"EC 固件里没有灯效"的结论是错的**，已在 README / 协议文档中更正。
2. 可用的额外能力：`0x767` bit7 的**硬件彩虹** —— 零 CPU 占用，且**程序退出后仍在跑**，
   这是软件动画做不到的。
3. `0x78C` 的 bit4~7 可以改**亮度档**（4 档），本控制台目前没有提供这个设置项。

---

## 六、复现用的工具

| 脚本 | 作用 |
|---|---|
| `ref/cc_unpack1..3.py` | 逐层拆 zip → msixbundle → msix，识别 PE 类型 |
| `ref/cc_strings.py` | 抽 DLL 的 ASCII / UTF-16 字符串 |
| `ref/cc_pri.py`、`cc_pool.py`、`cc_keys.py` | 解析 `resources.pri` 的中文串池与资源键 |
| `ref/ildis2.py` | 通用 .NET IL 反汇编器（带自校验） |
| `ref/scan_bits2.py` | 扫 IL 找所有 `BitArray` 置位点，还原位映射 |
| `ref/bright_table.py` | 从 `SetBrightness_EC` 解出亮度档位表 |
| `ref/hw_bit.py` | 对 `0x767` 任意位做上机开关（带备份/还原） |
