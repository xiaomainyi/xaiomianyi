# 键盘背光颜色协议（已实测打通）

> 本文取代 `OEM-EC-ADDRESS-MAP.md` 里"无法还原颜色写入值"的结论。
> 那份文档只分析了 `GCUService.exe`（被混淆），所以卡住了；
> 真正的灯光实现位于 **`DefaultTool.exe`，它没有被混淆**，方法名和源码路径都是明文。

## 1. 原厂代码定位

`DefaultTool.exe`（`ref\inno\files\`，1.25 MB，.NET）里内嵌了原始源码路径：

```
E:\WorkSpace\CCU_GX\MyControlCenter\MyControlCenter\MyRgbKeyboard\LightingModel\RGBKeyboard_EC.cs
E:\WorkSpace\CCU_GX\MyControlCenter\MyControlCenter\MyRgbKeyboard\LightingModel\RGBKeyboard_ITE.cs
E:\WorkSpace\CCU_GX\MyControlCenter\MyControlCenter\MyRgbKeyboard\LightingModel\LM_Manager.cs
E:\WorkSpace\CCU_GX\MyControlCenter\MyControlCenter\MyRgbKeyboard\UsbHidModel\HID_Manager.cs
E:\WorkSpace\CCU_GX\MyControlCenter\MyControlCenter\MyRgbKeyboard\RGBKeyboard.cs
E:\WorkSpace\CCU_GX\MyControlCenter\MyControlCenter\MyRgbKeyboard\HIDKeyboard\HIDKeyboard.cs
E:\WorkSpace\CCU_GX\MyControlCenter\MyControlCenter\MyRgbKeyboard\HIDKeyboard\HIDLightbar4.cs
E:\WorkSpace\CCU_GX\MyControlCenter\MyControlCenter\MyRgbKeyboard\HIDKeyboard\SingleZone.cs
```

两条互斥的实现路线：

| 路线 | 类 | 通道 | 本机是否适用 |
|---|---|---|---|
| **EC** | `MyControlCenter.MyRgbKeyboard.SingleZone` | `\\.\ACPIDriver` 读写 EC 0x767/0x769/0x76A/0x76B | **是** |
| ITE/HID | `MyControlCenter.MyRgbKeyboard.HIDKeyboard` / `HIDLightbar*` | USB HID Feature Report（命令码 0x08/0x09/0x14/0x1A/0x12/0x16/0x26） | 否 |

本机内置键盘是 `ACPI\MSFT0001`（标准 PS/2 键盘），枚举不到任何 HID 灯光设备，
所以走的是 **EC 路线**。ITE 路线的日志字符串 `ILM_RGBKB_Init : Not RGB Keyboard moudle`
和 `HID_Manager|Init : PID ={0} VID={1}` 在本机都不会触发。

## 2. 颜色写入协议（`SingleZone.SetRGBLevel`，RVA `0x3E43C`）

反汇编还原出的原厂 IL，逐条对应：

```csharp
WriteECRAM(0x769, rLevel);
WriteECRAM(0x76A, gLevel);
WriteECRAM(0x76B, bLevel);

long v = 0;
ReadECRAM(0x767, ref v);
BitArray ba = new BitArray(new byte[] { (byte)v });
ba.set_Item(5, 1);                       // 置 0x767 的 bit5
WriteECRAM(0x767, ConvertToByte(ba));    // ← 提交触发器
```

原厂日志字符串也一并恢复了：

```
SetRGBLevel
0x767 SetRGBLevel Read: 
0x767 SetRGBLevel Write: 
RGB: ({0}, {1}, {2}), level: ({3}, {4}, {5})
R / G / B
```

## 3. 颜色 → 电平 的换算（`SetRGBColor` → `RGBValueToLevel` → `LimitToRange`）

```
RGBValueToLevel(value, label, divisor, lower) = LimitToRange(value / divisor, lower, 50)

rLevel = clamp(R / 5, 1, 50)
gLevel = clamp(G / 6, 1, 50)
bLevel = clamp(B / 6, 1, 50)
```

调用点实测：R 用除数 5、下限 1；G/B 用除数 6、下限 1；上限统一 50。

原厂还带一张**色彩校准表**（`SetRGBColor` 里从后往前扫一个静态集合，按 (R,G,B) 命中后取
表里存的电平）以及若干硬编码特例，例如 `(255,255,255) → (50,40,40)`。
本机按上面的公式换算即可，实测三原色与白色都正确。

## 4. 寄存器

| 地址 | 原厂符号 | 含义 |
|---|---|---|
| `0x767` | `ADDR_TRIGGER_BYTE` | 提交触发器，**bit5 = 0x20** |
| `0x768` | `ADDR_STAUTS_BYTE` | 状态字节（本机读 0） |
| `0x769` | `RGBKB_LEVEL_R` / `AP_EC_LOGO_R` | 红色电平 1..50 |
| `0x76A` | `RGBKB_LEVEL_G` / `AP_EC_LOGO_G` | 绿色电平 1..50 |
| `0x76B` | `RGBKB_LEVEL_B` / `AP_EC_LOGO_B` | 蓝色电平 1..50 |
| `0x76C` | `RGBKB_LEVEL_DEFAULT_R` | **出厂**红色电平（`GetEcDefaultRGB` 读这三个） |
| `0x76D` | `RGBKB_LEVEL_DEFAULT_G` | 出厂绿色电平 |
| `0x76E` | `RGBKB_LEVEL_DEFAULT_B` | 出厂蓝色电平 |
| `0x7AB` | `AP_EC_LOGO` | 效果/模式索引 |

`GetEcDefaultRGB`（RVA `0x3E020`）就是依次 `ReadECRAM(0x76C/0x76D/0x76E)`，
所以"恢复出厂色"= 读这三个再写回 `0x769/0x76A/0x76B` 并提交。

本机实测出厂电平为 `0/50/50`。

## 5. 实测记录

| 输入 RGB | 写出电平 | 目视结果 |
|---|---|---|
| `(255, 0, 0)` | `50/1/1` | 红 ✔ |
| `(0, 255, 0)` | `1/42/1` | 绿 ✔ |
| `(0, 0, 255)` | `1/1/42` | 蓝 ✔ |
| `(255, 255, 255)` | `50/42/42` | 偏暖的白（浅黄）✔ |

> **坑**：早前直接把 `0..255` 的原始分量写进 `0x769`（例如 255）会超出 1..50 的有效范围，
> EC 会把背光**直接关掉**。必须走上面的电平换算。

## 6. SysConsole 里的实现

* `src/Ec.cs` → `Ec.KbColor`
  * `LevelFromR/G/B`、`RFromLevel/GFromLevel/BFromLevel`
  * `ReadLevels` / `ReadDefaults` / `Commit`
  * `ApplyLevels` / `ApplyRgb`（写后回读校验）
  * `LoadSaved` / `SaveSaved` / `ClearSaved`（`%LOCALAPPDATA%\SysConsole\kbcolor.txt`）
* `src/MainForm.cs` → 「操作面板」第 4 个分区「键盘背光颜色」
  * **调色板**（`PalettePanel`，自绘网格）：2 排 × 35 格 = 70 色
    * 上排 = 24 个全亮度色相（每 15°）+ 11 级灰阶
    * 下排 = 同色相压暗到 55% + 11 级暗灰阶
    * 点任意格子立即改色；鼠标悬停显示该格 RGB
    * 当前颜色会用黑白双线框高亮（按最接近的颜色匹配）
  * 色块预览（显示**硬件实际会发出的颜色**，由电平反推）；点它打开系统取色器，
    可以选调色板里没有的精确颜色
  * 「记住颜色」勾选框
  * 「恢复出厂色」按钮
* 命令行：`--color R G B` / `--color read` / `--color default` / `--color levels r g b`

## 7. 复现本次分析用的脚本

| 脚本 | 作用 |
|---|---|
| `D:\deep.1\ref\tables.py` | 打印 .NET 元数据各表行数（定位 `MethodPtr`/`TypeDef` 结构） |
| `D:\deep.1\ref\whotype.py` | MethodDef → TypeDef 归属映射（注意 `MethodList` 在 `FieldList` 之后 2/4 字节） |
| `D:\deep.1\ref\ildis2.py` | 通用 IL 反汇编器：`python ildis2.py <exe> <方法名子串> [条数]` |
| `D:\deep.1\ref\tok.py` | 解析元数据 token 与 `#US` 字符串：`python tok.py <exe> 0A000392 07000AFA2` |
| `D:\deep.1\ecwork\oemcolor.py` | 按原厂协议读写颜色：`show` / `set R G B` / `raw r g b` / `trig` / `restore` |
