// ============================================================================
//  SysConsole — FanCurve.cs
//  风扇曲线：按温度自动切换风扇档位。
//
//  —— 硬件事实（见 docs/FAN-CONTROL-PROTOCOL.md，均为实测结论）——
//    · 0x75B / 0x75C 是双风扇的**当前占空比，只读**：写进去会被 EC 立刻覆盖，
//      所以"直接设任意转速"这条路在本机不存在。
//    · 唯一可写的是 0x751 风扇模式位域，只有四档：
//        静音 0xA0（稳态占空比 ≈100）   安静 0x00（≈120）
//        标准 0x10（≈140）              强冷位 0x40（≈200，与基础模式按位或）
//      也就是说本机能做的是"按温度切换 EC 的整条风扇曲线档位"，
//      而不是逐度指定 PWM。
//
//  —— 控制律（每秒一次，输入是当前最高热区温度）——
//    目标档位 = 曲线给出的档位，再取 max(安全底线)：
//        ≥80°C 强制强冷；≥70°C 不允许低于"标准"
//      安全底线优先于用户曲线，且不可关闭。
//    升温立刻跟上；降温必须跌出回差带（Hysteresis）才降档，避免在阈值附近来回抖。
//    强冷位只清掉"本模块自己置起来的"那一次 —— 手动「一键强冷」和温度墙联动开的
//    强冷不动（和温度墙"只关自己开的那一次"是同一套约定）。
//
//  —— 还原 ——
//    接管时把进入前的 0x751 原值记到磁盘，关闭时精确写回（与 Ec.FanBoost 同款做法），
//    所以"关掉曲线"不会顺手改掉用户原本的风扇模式。
//
//    · 编译：系统自带 csc.exe（.NET Framework 4.8），无 SDK / 无网络 / 无第三方库
//    · 语法：C# 5，不用 async/await、字符串插值、nameof
// ============================================================================

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace SysConsole
{
    /// <summary>
    /// 曲线上的一个点：温度**低于** LimitC 时用 Level 档；最后一个点是兜底（LimitC 只作显示）。
    /// </summary>
    public class FanCurvePoint
    {
        public int LimitC;
        public int Level;

        public FanCurvePoint() { }
        public FanCurvePoint(int limitC, int level) { LimitC = limitC; Level = level; }
        public FanCurvePoint Clone() { return new FanCurvePoint(LimitC, Level); }
    }

    public class FanCurveConfig
    {
        public bool Enabled;
        public int Hysteresis = 3;
        public List<FanCurvePoint> Points = Defaults();

        /// <summary>
        /// 默认曲线：低负载尽量安静，热起来果断吹。安全性由 FanCurve.SafetyFloor 兜底，
        /// 所以这里可以放心把低档位写在低温段。
        /// </summary>
        public static List<FanCurvePoint> Defaults()
        {
            List<FanCurvePoint> l = new List<FanCurvePoint>();
            l.Add(new FanCurvePoint(50, 0));   // < 50°C  静音
            l.Add(new FanCurvePoint(65, 1));   // 50~65   安静
            l.Add(new FanCurvePoint(78, 2));   // 65~78   标准
            l.Add(new FanCurvePoint(0, 3));    // ≥ 78    强冷
            return l;
        }

        public FanCurveConfig Clone()
        {
            FanCurveConfig c = new FanCurveConfig();
            c.Enabled = Enabled;
            c.Hysteresis = Hysteresis;
            c.Points = new List<FanCurvePoint>();
            for (int i = 0; i < Points.Count; i++) c.Points.Add(Points[i].Clone());
            return c;
        }
    }

    /// <summary>风扇四档的元数据：名字、0x751 基础模式、实测稳态占空比。</summary>
    public static class FanLevels
    {
        public static readonly string[] Names = new string[] { "静音", "安静", "标准", "强冷" };
        public static readonly int[] BaseMode = new int[]
        {
            Ec.FAN_MODE_SILENT,   // 0xA0
            Ec.FAN_MODE_QUIET,    // 0x00
            Ec.FAN_MODE_STD_A,    // 0x10
            Ec.FAN_MODE_STOCK     // 0x30，强冷时再 | 0x40
        };
        public static readonly string[] DutyText = new string[] { "≈100", "≈120", "≈140", "≈200" };

        public static string Name(int level)
        {
            if (level < 0 || level >= Names.Length) return "未知";
            return Names[level];
        }

        /// <summary>把 0x751 的当前值翻译成档位（强冷位优先）。</summary>
        public static int FromReg(int reg)
        {
            if (reg < 0) return -1;
            if ((reg & Ec.FAN_MODE_BOOST) != 0) return 3;
            int b = reg & 0xFF;
            if (b == Ec.FAN_MODE_SILENT) return 0;
            if (b == Ec.FAN_MODE_QUIET) return 1;
            if (b == Ec.FAN_MODE_STD_A || b == Ec.FAN_MODE_STOCK) return 2;
            return -1;
        }
    }

    /// <summary>风扇曲线的持久化。格式与 wall.txt / guard.txt 一致（key=value 纯文本）。</summary>
    public static class FanCurveStore
    {
        public static string FilePath()
        {
            return Path.Combine(Log.Dir(), "fancurve.txt");
        }

        public static void Save(FanCurveConfig c)
        {
            try
            {
                if (c == null) return;
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.AppendLine("# SysConsole 风扇曲线");
                sb.AppendLine("# enabled  0/1");
                sb.AppendLine("# pointN = 温度上限,档位   档位 0静音 1安静 2标准 3强冷；最后一行是兜底");
                sb.AppendLine("enabled=" + (c.Enabled ? "1" : "0"));
                sb.AppendLine("hysteresis=" + c.Hysteresis.ToString(CultureInfo.InvariantCulture));
                for (int i = 0; i < c.Points.Count; i++)
                {
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                        "point{0}={1},{2}", i + 1, c.Points[i].LimitC, c.Points[i].Level));
                }
                File.WriteAllText(FilePath(), sb.ToString(), System.Text.Encoding.UTF8);
            }
            catch (Exception ex) { Log.Write("风扇曲线保存失败: " + ex.Message); }
        }

        public static FanCurveConfig Load()
        {
            FanCurveConfig c = new FanCurveConfig();
            try
            {
                if (!File.Exists(FilePath())) return c;
                string[] lines = File.ReadAllLines(FilePath(), System.Text.Encoding.UTF8);
                List<FanCurvePoint> pts = new List<FanCurvePoint>();
                for (int i = 0; i < lines.Length; i++)
                {
                    string line = lines[i].Trim();
                    if (line.Length == 0 || line.StartsWith("#")) continue;
                    int eq = line.IndexOf('=');
                    if (eq <= 0) continue;
                    string k = line.Substring(0, eq).Trim().ToLowerInvariant();
                    string v = line.Substring(eq + 1).Trim();
                    if (k == "enabled") c.Enabled = (v == "1" || v.ToLowerInvariant() == "true");
                    else if (k == "hysteresis")
                    {
                        int n;
                        if (int.TryParse(v, NumberStyles.Integer, CultureInfo.InvariantCulture, out n))
                            c.Hysteresis = Clamp(n, 0, 15);
                    }
                    else if (k.StartsWith("point"))
                    {
                        string[] p = v.Split(',');
                        if (p.Length == 2)
                        {
                            int t, lv;
                            if (int.TryParse(p[0].Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out t) &&
                                int.TryParse(p[1].Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out lv))
                                pts.Add(new FanCurvePoint(Clamp(t, 0, 120), Clamp(lv, 0, 3)));
                        }
                    }
                }
                if (pts.Count >= 2)
                {
                    // 按温度升序，兜底那条（温度 0）排到最后 —— 兜底必须唯一且在末尾
                    List<FanCurvePoint> bounds = new List<FanCurvePoint>();
                    FanCurvePoint last = null;
                    for (int i = 0; i < pts.Count; i++)
                    {
                        if (pts[i].LimitC <= 0) last = pts[i];
                        else bounds.Add(pts[i]);
                    }
                    bounds.Sort(delegate(FanCurvePoint a, FanCurvePoint b) { return a.LimitC.CompareTo(b.LimitC); });
                    if (last != null) bounds.Add(last);
                    else bounds.Add(new FanCurvePoint(0, 3));
                    if (bounds.Count >= 2) c.Points = bounds;
                }
            }
            catch (Exception ex) { Log.Write("风扇曲线读取失败: " + ex.Message); }
            return c;
        }

        static int Clamp(int v, int lo, int hi)
        {
            if (v < lo) return lo;
            if (v > hi) return hi;
            return v;
        }
    }

    /// <summary>
    /// 风扇曲线执行器。每秒调用一次 Tick()，由它决定是否写 0x751。
    /// 状态是静态的：MainForm 和 CLI 看到的是同一份。
    /// </summary>
    public static class FanCurve
    {
        // 安全底线：不可被用户曲线突破
        public const double ForceBoostC = 80.0;    // ≥ 此温度强制强冷
        public const double MinStandardC = 70.0;   // ≥ 此温度不允许低于"标准"

        static int _level = -1;        // 当前生效档位；-1 = 本模块尚未接管
        static bool _ownBoost;         // 强冷位是不是本模块置起来的
        static int _restoreReg = -1;   // 接管前的 0x751 原值
        static bool _active;           // 上一拍是否处于接管状态

        public static bool Active { get { return _active; } }
        public static int CurrentLevel { get { return _level; } }

        /// <summary>由温度求曲线档位（不含安全底线）。</summary>
        public static int TargetLevel(double tempC, FanCurveConfig cfg)
        {
            if (cfg == null || cfg.Points == null || cfg.Points.Count == 0) return 2;
            for (int i = 0; i < cfg.Points.Count - 1; i++)
                if (tempC < cfg.Points[i].LimitC) return cfg.Points[i].Level;
            return cfg.Points[cfg.Points.Count - 1].Level;
        }

        /// <summary>
        /// 带回差的下一档：升温立刻跟上；降温要把温度再加一个回差带之后仍低于边界才降，
        /// 这样在阈值附近就不会一格一格地抖。
        /// </summary>
        public static int NextLevel(double tempC, int current, FanCurveConfig cfg)
        {
            int t = TargetLevel(tempC, cfg);
            if (current < 0) return t;
            if (t >= current) return t;
            int t2 = TargetLevel(tempC + cfg.Hysteresis, cfg);
            return t2 < current ? t2 : current;
        }

        /// <summary>安全底线：优先于用户曲线，且不可关闭。</summary>
        public static int SafetyFloor(double tempC)
        {
            if (tempC >= ForceBoostC) return 3;
            if (tempC >= MinStandardC) return 2;
            return 0;
        }

        /// <summary>
        /// 每秒调用一次。返回需要写日志的一句话；没有动作时返回 null。
        /// 关闭状态下的第一次调用会把接管前的 0x751 原值写回去。
        /// </summary>
        public static string Tick(double tempC, FanCurveConfig cfg)
        {
            if (cfg == null || !cfg.Enabled)
            {
                if (!_active) return null;
                _active = false;
                return Restore();
            }

            if (!_active)
            {
                // 刚接管：记住原值，并从 EC 当前状态推断起始档位（回差判定的起点）
                _active = true;
                _ownBoost = false;
                int cur0 = Ec.Read(Ec.REG_FAN_CTRL);
                _restoreReg = cur0 >= 0 ? cur0 : Ec.FAN_MODE_STOCK;
                _level = FanLevels.FromReg(cur0);
                Log.Write(string.Format(CultureInfo.InvariantCulture,
                    "风扇曲线: 接管风扇控制，原 0x751 = 0x{0:X2}", _restoreReg));
            }

            int want = NextLevel(tempC, _level, cfg);
            int floorLevel = SafetyFloor(tempC);
            bool bySafety = floorLevel > want;
            if (bySafety) want = floorLevel;

            int cur = Ec.Read(Ec.REG_FAN_CTRL);
            if (cur < 0) return "风扇曲线: 读取 0x751 失败（" + Ec.LastError + "）";

            bool boostByOthers = ((cur & Ec.FAN_MODE_BOOST) != 0) && !_ownBoost;
            bool wantBoost = (want == 3);
            int target = FanLevels.BaseMode[want];
            if (wantBoost || boostByOthers) target |= Ec.FAN_MODE_BOOST;

            if (target == cur)
            {
                _level = want;
                _ownBoost = wantBoost && !boostByOthers;
                return null;
            }

            if (!Ec.WriteVerify(Ec.REG_FAN_CTRL, target))
                return "风扇曲线: 写入 0x751 失败（" + Ec.LastError + "）";

            _ownBoost = wantBoost && !boostByOthers;
            _level = want;
            return string.Format(CultureInfo.InvariantCulture,
                "风扇曲线: {0:0.0}°C -> {1}{2}  (0x751: 0x{3:X2} -> 0x{4:X2})",
                tempC, FanLevels.Name(want), bySafety ? " [安全底线]" : "", cur, target);
        }

        /// <summary>关闭曲线：只还原基础模式；强冷位只清掉自己置的那一次。</summary>
        public static string Restore()
        {
            int reg = _restoreReg;
            bool ownBoost = _ownBoost;
            _level = -1;
            _ownBoost = false;
            _restoreReg = -1;
            if (reg < 0) return "风扇曲线: 已关闭（没有记录到原值）";

            int cur = Ec.Read(Ec.REG_FAN_CTRL);
            if (cur < 0) return "风扇曲线: 已关闭，但读不到 0x751（" + Ec.LastError + "）";

            int target = reg & ~Ec.FAN_MODE_BOOST & 0xFF;
            // 强冷位：不是自己开的就别动 —— 手动强冷 / 温度墙联动可能还开着
            if (!ownBoost && (cur & Ec.FAN_MODE_BOOST) != 0) target |= Ec.FAN_MODE_BOOST;

            if (target == cur) return "风扇曲线: 已关闭（风扇模式无需改动）";
            if (!Ec.WriteVerify(Ec.REG_FAN_CTRL, target))
                return "风扇曲线: 关闭时写回 0x751 失败（" + Ec.LastError + "）";
            return string.Format(CultureInfo.InvariantCulture,
                "风扇曲线: 已关闭，风扇模式还原 (0x751: 0x{0:X2} -> 0x{1:X2})", cur, target);
        }

        /// <summary>不开写、只看：给定温度会选哪一档（CLI 与界面预览共用）。</summary>
        public static string Preview(double tempC, FanCurveConfig cfg)
        {
            int curve = TargetLevel(tempC, cfg);
            int floorLevel = SafetyFloor(tempC);
            int use = Math.Max(curve, floorLevel);
            return string.Format(CultureInfo.InvariantCulture,
                "{0:0.0}°C -> 曲线档 {1}，安全底线 {2}，实际用 {3}（0x751 = 0x{4:X2}{5}）",
                tempC, FanLevels.Name(curve), FanLevels.Name(floorLevel), FanLevels.Name(use),
                FanLevels.BaseMode[use], use == 3 ? " | 强冷位" : "");
        }
    }
}
