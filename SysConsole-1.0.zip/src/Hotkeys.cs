// ============================================================================
//  SysConsole — Hotkeys.cs
//  全局快捷键：注册/注销、配置持久化，以及一个低级键盘钩子用来录键。
//  钩子只用于"录制快捷键"和按键诊断，平时不常驻。
//
//    · 编译：系统自带 csc.exe（.NET Framework 4.8），无 SDK / 无网络 / 无第三方库
//    · 语法：C# 5，不用 async/await、字符串插值、nameof 等新语法
//    · 编码：UTF-8；.ps1 脚本另需纯 ASCII 或带 BOM，否则 PS 5.1 会按 GBK 解码
//    · 硬件寄存器地址来自原厂文件反汇编 + 本机实测，出处见 docs/ 下的协议文档
// ============================================================================

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace SysConsole
{
    // ------------------------------------------------------------- binding

    public class HotkeyBinding
    {
        public string Action = "";
        public string Label = "";
        public uint Modifiers;
        public uint Vk;
        public int Id;

        public HotkeyBinding() { }

        public HotkeyBinding(string action, string label, uint mods, uint vk)
        {
            Action = action;
            Label = label;
            Modifiers = mods;
            Vk = vk;
        }

        public string Text
        {
            get { return HotkeyKeys.Describe(Modifiers, Vk); }
        }

        public HotkeyBinding Clone()
        {
            return new HotkeyBinding(Action, Label, Modifiers, Vk);
        }
    }

    public static class HotkeyKeys
    {
        public const uint MOD_ALT = 0x0001;
        public const uint MOD_CONTROL = 0x0002;
        public const uint MOD_SHIFT = 0x0004;
        public const uint MOD_WIN = 0x0008;
        public const uint MOD_NOREPEAT = 0x4000;

        static Dictionary<string, uint> _rev;

        static void BuildReverse()
        {
            _rev = new Dictionary<string, uint>(StringComparer.OrdinalIgnoreCase);
            for (uint vk = 1; vk <= 0xFE; vk++)
            {
                string n = KeyName(vk);
                if (!string.IsNullOrEmpty(n) && !_rev.ContainsKey(n)) _rev[n] = vk;
            }
        }

        public static string KeyName(uint vk)
        {
            if (vk == 0) return "";
            if (vk >= 0x30 && vk <= 0x39) return ((char)vk).ToString();          // 0-9
            if (vk >= 0x41 && vk <= 0x5A) return ((char)vk).ToString();          // A-Z
            if (vk >= 0x70 && vk <= 0x87) return "F" + (vk - 0x6F);              // F1-F24
            if (vk >= 0x60 && vk <= 0x69) return "Num" + (vk - 0x60);            // numpad
            try { return ((Keys)vk).ToString(); }
            catch { return "0x" + vk.ToString("X2", CultureInfo.InvariantCulture); }
        }

        public static string Describe(uint mods, uint vk)
        {
            List<string> parts = new List<string>();
            if ((mods & MOD_CONTROL) != 0) parts.Add("Ctrl");
            if ((mods & MOD_ALT) != 0) parts.Add("Alt");
            if ((mods & MOD_SHIFT) != 0) parts.Add("Shift");
            if ((mods & MOD_WIN) != 0) parts.Add("Win");
            if (vk != 0) parts.Add(KeyName(vk));
            if (parts.Count == 0) return "（未设置）";
            return string.Join(" + ", parts.ToArray());
        }

        public static bool TryParse(string s, out uint mods, out uint vk)
        {
            mods = 0; vk = 0;
            if (string.IsNullOrEmpty(s)) return false;
            if (_rev == null) BuildReverse();

            string[] toks = s.Split('+');
            bool ok = false;
            for (int i = 0; i < toks.Length; i++)
            {
                string t = toks[i].Trim();
                if (t.Length == 0) continue;
                string l = t.ToLowerInvariant();
                if (l == "ctrl" || l == "control") { mods |= MOD_CONTROL; continue; }
                if (l == "alt") { mods |= MOD_ALT; continue; }
                if (l == "shift") { mods |= MOD_SHIFT; continue; }
                if (l == "win" || l == "windows") { mods |= MOD_WIN; continue; }
                uint v;
                if (_rev.TryGetValue(t, out v)) { vk = v; ok = true; }
            }
            return ok;
        }

        // A bare key with no modifier would swallow normal typing, so only
        // function/media/browser keys may be used unmodified.
        public static bool SafeCombination(uint mods, uint vk)
        {
            if (vk == 0) return false;
            if (mods != 0) return true;
            if (vk >= 0x70 && vk <= 0x87) return true;   // F1-F24
            if (vk >= 0xA6 && vk <= 0xB7) return true;   // browser / media
            return false;
        }

        public static bool IsModifierKey(uint vk)
        {
            return vk == 0x10 || vk == 0x11 || vk == 0x12 ||            // Shift, Ctrl, Alt
                   vk == 0x5B || vk == 0x5C || vk == 0xA0 || vk == 0xA1 ||
                   vk == 0xA2 || vk == 0xA3 || vk == 0xA4 || vk == 0xA5;
        }

        public static uint CurrentModifiers()
        {
            uint m = 0;
            if ((GetKeyState(0x11) & 0x8000) != 0) m |= MOD_CONTROL;
            if ((GetKeyState(0x12) & 0x8000) != 0) m |= MOD_ALT;
            if ((GetKeyState(0x10) & 0x8000) != 0) m |= MOD_SHIFT;
            if ((GetKeyState(0x5B) & 0x8000) != 0 || (GetKeyState(0x5C) & 0x8000) != 0) m |= MOD_WIN;
            return m;
        }

        [DllImport("user32.dll")]
        static extern short GetKeyState(int vKey);
    }

    // ------------------------------------------------------------- manager

    public class HotkeyManager : IDisposable
    {
        [DllImport("user32.dll", SetLastError = true)]
        static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

        [DllImport("user32.dll", SetLastError = true)]
        static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        public const int WM_HOTKEY = 0x0312;

        readonly IntPtr _hwnd;
        readonly List<HotkeyBinding> _active = new List<HotkeyBinding>();

        public HotkeyManager(IntPtr hwnd) { _hwnd = hwnd; }

        public int ActiveCount { get { return _active.Count; } }

        // Registers every binding. Returns a per-binding report; failures are
        // normally "the combination is already owned by another program".
        public string Apply(List<HotkeyBinding> bindings)
        {
            UnregisterAll();
            StringBuilder sb = new StringBuilder();
            if (bindings == null) return sb.ToString();

            int id = 0x4200;
            for (int i = 0; i < bindings.Count; i++)
            {
                HotkeyBinding b = bindings[i];
                if (b.Vk == 0)
                {
                    sb.AppendLine(b.Label + " : 未设置，已跳过");
                    continue;
                }
                b.Id = id + i;
                bool ok = RegisterHotKey(_hwnd, b.Id, b.Modifiers | HotkeyKeys.MOD_NOREPEAT, b.Vk);
                if (ok)
                {
                    _active.Add(b);
                    sb.AppendLine(b.Label + " : 注册成功   " + b.Text);
                }
                else
                {
                    sb.AppendLine(b.Label + " : 注册失败，该组合已被占用或系统保留   " + b.Text);
                }
            }
            Log.Write("Hotkeys applied:\r\n" + sb.ToString());
            return sb.ToString();
        }

        public void UnregisterAll()
        {
            for (int i = 0; i < _active.Count; i++)
            {
                try { UnregisterHotKey(_hwnd, _active[i].Id); } catch { }
            }
            _active.Clear();
        }

        // Maps a WM_HOTKEY id back to its action key, or null if unknown.
        public string Resolve(int id)
        {
            for (int i = 0; i < _active.Count; i++)
            {
                if (_active[i].Id == id) return _active[i].Action;
            }
            return null;
        }

        public void Dispose()
        {
            UnregisterAll();
        }
    }

    // --------------------------------------------------- low level keyboard hook

    public class KeyboardHook : IDisposable
    {
        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        static extern IntPtr SetWindowsHookEx(int idHook, LowLevelProc lpfn, IntPtr hMod, uint dwThreadId);

        [DllImport("user32.dll", SetLastError = true)]
        static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll")]
        static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        static extern IntPtr GetModuleHandle(string lpModuleName);

        public const int WH_KEYBOARD_LL = 13;
        public const int WM_KEYDOWN = 0x0100;
        public const int WM_SYSKEYDOWN = 0x0104;
        public const int WM_KEYUP = 0x0101;
        public const int WM_SYSKEYUP = 0x0105;

        [StructLayout(LayoutKind.Sequential)]
        public struct KBDLLHOOKSTRUCT
        {
            public uint vkCode;
            public uint scanCode;
            public uint flags;
            public uint time;
            public IntPtr dwExtraInfo;
        }

        public delegate IntPtr LowLevelProc(int nCode, IntPtr wParam, IntPtr lParam);

        // Return true to swallow the key so it never reaches the focused app.
        public Func<uint, uint, uint, bool> OnKeyDown;
        public Func<uint, uint, uint, bool> OnKeyUp;

        LowLevelProc _proc;
        IntPtr _hook = IntPtr.Zero;

        public bool IsInstalled { get { return _hook != IntPtr.Zero; } }

        public bool Install()
        {
            if (_hook != IntPtr.Zero) return true;
            _proc = HookProc;
            IntPtr hMod = GetModuleHandle(null);
            _hook = SetWindowsHookEx(WH_KEYBOARD_LL, _proc, hMod, 0);
            if (_hook == IntPtr.Zero)
            {
                Log.Write("SetWindowsHookEx failed, win32 err=" + Marshal.GetLastWin32Error());
                return false;
            }
            return true;
        }

        IntPtr HookProc(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0)
            {
                int msg = wParam.ToInt32();
                bool down = (msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN);
                bool up = (msg == WM_KEYUP || msg == WM_SYSKEYUP);
                if (down || up)
                {
                    KBDLLHOOKSTRUCT k = (KBDLLHOOKSTRUCT)Marshal.PtrToStructure(lParam, typeof(KBDLLHOOKSTRUCT));
                    bool swallow = false;
                    try
                    {
                        if (down && OnKeyDown != null) swallow = OnKeyDown(k.vkCode, k.scanCode, k.flags);
                        else if (up && OnKeyUp != null) swallow = OnKeyUp(k.vkCode, k.scanCode, k.flags);
                    }
                    catch { }
                    if (swallow) return (IntPtr)1;
                }
            }
            return CallNextHookEx(_hook, nCode, wParam, lParam);
        }

        public void Dispose()
        {
            if (_hook != IntPtr.Zero)
            {
                try { UnhookWindowsHookEx(_hook); } catch { }
                _hook = IntPtr.Zero;
            }
            OnKeyDown = null;
            OnKeyUp = null;
        }
    }

    // ------------------------------------------------------------- persistence

    public static class HotkeyStore
    {
        public static string StorePath()
        {
            return Path.Combine(Log.Dir(), "hotkeys.txt");
        }

        public static List<HotkeyBinding> Defaults()
        {
            List<HotkeyBinding> l = new List<HotkeyBinding>();
            l.Add(new HotkeyBinding("performance", "性能模式", HotkeyKeys.MOD_CONTROL | HotkeyKeys.MOD_ALT, 0x31));
            l.Add(new HotkeyBinding("balanced", "均衡模式", HotkeyKeys.MOD_CONTROL | HotkeyKeys.MOD_ALT, 0x32));
            l.Add(new HotkeyBinding("quiet", "静音模式", HotkeyKeys.MOD_CONTROL | HotkeyKeys.MOD_ALT, 0x33));
            l.Add(new HotkeyBinding("cycle", "循环切换", HotkeyKeys.MOD_CONTROL | HotkeyKeys.MOD_ALT, 0x4D));
            l.Add(new HotkeyBinding("fanboost", "一键强冷", HotkeyKeys.MOD_CONTROL | HotkeyKeys.MOD_ALT, 0x46));
            return l;
        }

        public class Config
        {
            public bool Enabled = true;
            public List<HotkeyBinding> Bindings = Defaults();
        }

        public static Config Load()
        {
            Config c = new Config();
            try
            {
                if (!File.Exists(StorePath())) return c;
                string[] lines = File.ReadAllLines(StorePath(), Encoding.UTF8);
                List<HotkeyBinding> defs = Defaults();
                for (int i = 0; i < lines.Length; i++)
                {
                    string line = lines[i].Trim();
                    if (line.Length == 0 || line.StartsWith("#")) continue;
                    int eq = line.IndexOf('=');
                    if (eq <= 0) continue;
                    string k = line.Substring(0, eq).Trim().ToLowerInvariant();
                    string v = line.Substring(eq + 1).Trim();

                    if (k == "enabled")
                    {
                        c.Enabled = (v == "1" || v.ToLowerInvariant() == "true");
                        continue;
                    }
                    for (int j = 0; j < defs.Count; j++)
                    {
                        if (defs[j].Action != k) continue;
                        if (v.Length == 0 || v == "-")
                        {
                            defs[j].Modifiers = 0;
                            defs[j].Vk = 0;
                        }
                        else
                        {
                            uint m, vk;
                            if (HotkeyKeys.TryParse(v, out m, out vk))
                            {
                                defs[j].Modifiers = m;
                                defs[j].Vk = vk;
                            }
                        }
                    }
                }
                c.Bindings = defs;
            }
            catch (Exception ex)
            {
                Log.Write("HotkeyStore.Load failed: " + ex.Message);
            }
            return c;
        }

        public static void Save(Config c)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("# SysConsole 全局快捷键配置");
                sb.AppendLine("# 每行格式: 动作=修饰键+按键      留空或写 - 表示不绑定");
                sb.AppendLine("enabled=" + (c.Enabled ? "1" : "0"));
                for (int i = 0; i < c.Bindings.Count; i++)
                {
                    HotkeyBinding b = c.Bindings[i];
                    string v = (b.Vk == 0) ? "-" : HotkeyKeys.Describe(b.Modifiers, b.Vk);
                    sb.AppendLine(b.Action + "=" + v);
                }
                File.WriteAllText(StorePath(), sb.ToString(), Encoding.UTF8);
            }
            catch (Exception ex)
            {
                Log.Write("HotkeyStore.Save failed: " + ex.Message);
            }
        }
    }

    // --------------------------------------------------------------- key test

    // Diagnostic used to discover whether the Fn key (or any other special key)
    // produces an event that Windows can see. If Fn+Q reaches the OS at all, it
    // shows up here and can then be bound like any other combination.
    public static class KeyTest
    {
        public static string ResultPath()
        {
            return Path.Combine(Log.Dir(), "keytest.txt");
        }

        public static void Run(int seconds)
        {
            string path = ResultPath();
            StringBuilder head = new StringBuilder();
            head.AppendLine("=== SysConsole 按键诊断 ===");
            head.AppendLine("开始时间 : " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
            head.AppendLine("时长     : " + seconds + " 秒");
            head.AppendLine("说明     : 请在此时段内按下想测试的按键（例如 Fn+Q）。");
            head.AppendLine("           下面每一行代表一次按键按下事件：vk=虚拟键码 scan=扫描码 flags=标志位");
            head.AppendLine("           若按下某些键后此处没有任何输出，说明该键未传递给 Windows（被 EC 固件拦截）。");
            head.AppendLine();
            try { File.WriteAllText(path, head.ToString(), Encoding.UTF8); } catch { }

            KeyboardHook hook = new KeyboardHook();
            hook.OnKeyDown = delegate(uint vk, uint scan, uint flags)
            {
                string line = DateTime.Now.ToString("HH:mm:ss.fff", CultureInfo.InvariantCulture) +
                              "   vk=0x" + vk.ToString("X2", CultureInfo.InvariantCulture) +
                              " (" + HotkeyKeys.KeyName(vk) + ")" +
                              "   scan=0x" + scan.ToString("X2", CultureInfo.InvariantCulture) +
                              "   flags=0x" + flags.ToString("X2", CultureInfo.InvariantCulture) +
                              "   " + (HotkeyKeys.IsModifierKey(vk) ? "(修饰键)" : "");
                try { File.AppendAllText(path, line + "\r\n", Encoding.UTF8); } catch { }
                return false;   // do not swallow while diagnosing
            };
            if (!hook.Install())
            {
                try { File.AppendAllText(path, "!! 键盘钩子安装失败，无法诊断\r\n", Encoding.UTF8); } catch { }
                return;
            }

            DateTime end = DateTime.Now.AddSeconds(seconds);
            while (DateTime.Now < end)
            {
                Application.DoEvents();
                Thread.Sleep(10);
            }
            hook.Dispose();
            try
            {
                File.AppendAllText(path,
                    "\r\n=== 诊断结束 " + DateTime.Now.ToString("HH:mm:ss", CultureInfo.InvariantCulture) + " ===\r\n",
                    Encoding.UTF8);
            }
            catch { }
        }
    }
}
