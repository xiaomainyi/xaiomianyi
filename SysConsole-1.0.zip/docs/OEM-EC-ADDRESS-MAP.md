# 机械革命（Uniwill）OEM EC 地址表

> 数据来源：`D:\deep.1\ref\inno\files\GCUService.exe` 的 .NET **Constant 表（0x0B）**。
> 这些 `ADDR_*` 是 OEM 自己定义的 `const` 字段，值就是真实 EC 地址。
> 提取脚本：`D:\deep.1\ref\constfind.py`（本文件由 `mkdoc.py` 自动生成）。

## 提取方法（以及踩过的坑）

1. 定位 CLI 头 → MetaData 根（`BSJB`）→ 5 个流：`#~` / `#Strings` / `#US` / `#GUID` / `#Blob`
2. **`Module` 表行宽是 `2 + StringIdx + 3*GUIDIdx`**。我一开始写成 `2 + 2*StringIdx + 12`，
   导致后面所有表的偏移错 10 字节，`MethodDef` 的 RVA 全是垃圾值。修正后前 200 项 RVA **全部**落在 .text 里。
3. `ADDR_*` 是 `const`，**不走 `stsfld` 初始化**，值在 **Constant 表**里（Type=0x08 ELEMENT_TYPE_I4，
   Parent 是 HasConstant 编码、tag=0 表示 Field，Value 指向 Blob 堆中的 4 字节小端整数）。
4. `#US`（用户字符串）堆在这份程序集里是**被混淆的**（内容形如 `7f 00 7e 00 c6 00 a6 00 74 00…`），
   所以按字符串字面量定位代码这条路不通；改用 `#Strings` 里的**字段名/类名**（可读）。

## 统计

共 **157** 条 `ADDR_*` 常量，覆盖 **131** 个不同地址。

## 键盘灯 / 灯带（本次目标）

| 地址 | 常量名 | 说明 |
|---|---|---|
| `0x740` | ADDR_PROJECT_ID_BYTE | |
| `0x748` | ADDR_LIGHTBAR_CONTROL_BYTE | |
| `0x74A` | ADDR_GREENBAR_CONTROL_BYTE | |
| `0x74B` | ADDR_BLUEBAR_CONTROL_BYTE | |
| `0x74C` | ADDR_OEMSERVICE_PROJECT_ID_BYTE | |
| `0x765` | ADDR_SUPPORT_BYTE1 | |
| `0x766` | ADDR_SUPPORT_BYTE2 | |
| `0x767` | ADDR_TRIGGER_BYTE | |
| `0x768` | ADDR_STAUTS_BYTE | |
| `0x769` | ADDR_AP_EC_LOGO_R / ADDR_RGBKB_LEVEL_R | |
| `0x76A` | ADDR_AP_EC_LOGO_G / ADDR_RGBKB_LEVEL_G | |
| `0x76B` | ADDR_AP_EC_LOGO_B / ADDR_RGBKB_LEVEL_B | |
| `0x76C` | ADDR_RGBKB_LEVEL_DEFAULT_R | |
| `0x76D` | ADDR_RGBKB_LEVEL_DEFAULT_G | |
| `0x76E` | ADDR_RGBKB_LEVEL_DEFAULT_B | |
| `0x76F` | ADDR_RGBKB_MUSIC_NO | |
| `0x78C` | ADDR_AP_EC_LOGO_CONFIRM / ADDR_AP_OEM_BYTE2 / ADDR_L4_PWM_DEFAULT_MYFAN2 / ADDR_SINGLEKBL_ENABLE | |
| `0x78E` | ADDR_SINGLEKBL_SUPPORTPOWER / ADDR_SUPPORT_BYTE6 | |
| `0x7AB` | ADDR_AP_EC_LOGO / ADDR_MyFanCCI_Mode_Index | |
| `0xD00` | ADDR_AP_OEM_SingleZone | |

## 全部常量

| 地址 | 常量名 |
|---|---|
| `0x402` | ADDR_EC_BIF_DC_BYTE1 |
| `0x403` | ADDR_EC_BIF_DC_BYTE2 |
| `0x408` | ADDR_EC_BIF_DV_BYTE1 |
| `0x434` | ADDR_EC_BST_BPR_BYTE1 |
| `0x435` | ADDR_EC_BST_BPR_BYTE2 |
| `0x436` | ADDR_EC_BST_BRC_BYTE1 |
| `0x437` | ADDR_EC_BST_BRC_BYTE2 |
| `0x438` | ADDR_EC_BST_BPV_BYTE1 |
| `0x439` | ADDR_EC_BST_BPV_BYTE2 |
| `0x456` | ADDR_SystemID |
| `0x45B` | ADDR_SILENTMODE_STATUS_BYTE |
| `0x464` | ADDR_EC_MAIN_FAN_RPM_BYTE1 |
| `0x465` | ADDR_EC_MAIN_FAN_RPM_BYTE2 |
| `0x466` | ADDR_EC_BIOS_INFO5 |
| `0x46B` | ADDR_EC_SECOND_FAN_RPM_BYTE2 |
| `0x46C` | ADDR_EC_SECOND_FAN_RPM_BYTE1 |
| `0x494` | ADDR_BATTERY_ALERT_BYTE |
| `0x49F` | ADDR_BIOS_INFO_3_BYTE |
| `0x4A6` | ADDR_EC_BT1CycleCount_BYTE1 |
| `0x4A7` | ADDR_EC_BT1CycleCount_BYTE2 |
| `0x706` | ADDR_AP_BIOS_CONTROL_BYTE |
| `0x726` | ADDR_AP_OEM_BYTE9 |
| `0x727` | ADDR_AP_OEM_BYTE10_CUSTOM_LIGHT_TEST / ADDR_CPU_DOUBLE_FLAG_SUPPORT / ADDR_ESHUTTER_STATUS |
| `0x728` | ADDR_AP_OEM_BYTEB |
| `0x72A` | ADDR_GPU_STATUS |
| `0x730` | ADDR_GAMING_PL1_DEFAULT_VALUE |
| `0x731` | ADDR_GAMING_PL2_DEFAULT_VALUE |
| `0x732` | ADDR_GAMING_PL4_DEFAULT_VALUE |
| `0x733` | ADDR_GAMING_D_DEFAULT_VALUE |
| `0x734` | ADDR_OFFICE_PL1_DEFAULT_VALUE |
| `0x735` | ADDR_OFFICE_PL2_DEFAULT_VALUE |
| `0x736` | ADDR_OFFICE_PL4_DEFAULT_VALUE |
| `0x737` | ADDR_OFFICE_D_DEFAULT_VALUE |
| `0x738` | ADDR_MYFAN3_CPU_TAU |
| `0x740` | ADDR_PROJECT_ID_BYTE |
| `0x741` | ADDR_AP_OEM_BYTE / ADDR_FAN_ALERT_BYTE |
| `0x742` | ADDR_SUPPORT_BYTE5 |
| `0x743` | ADDR_ConfigurableTGP_DynamicBoost_CTRL_BYTE / ADDR_MYFAN2_L1_PWM |
| `0x744` | ADDR_ConfigurableTGP_VALUE / ADDR_MYFAN2_L2_PWM |
| `0x745` | ADDR_DynamicBoost_TotalProcessingPowerTarget_VALUE / ADDR_MYFAN2_L3_PWM |
| `0x746` | ADDR_DynamicBoost_MaxinumTGP_VALUE / ADDR_MYFAN2_L4_PWM |
| `0x747` | ADDR_MYFAN2_L5_PWM |
| `0x748` | ADDR_LIGHTBAR_CONTROL_BYTE |
| `0x74A` | ADDR_GREENBAR_CONTROL_BYTE |
| `0x74B` | ADDR_BLUEBAR_CONTROL_BYTE |
| `0x74C` | ADDR_OEMSERVICE_PROJECT_ID_BYTE |
| `0x74E` | ADDR_BIOS_OEM_BYTE |
| `0x751` | ADDR_MAFAN_CONTROL_BYTE |
| `0x753` | ADDR_CPU_VRM_CURRENT_LIMIT_BYTE |
| `0x754` | ADDR_CPU_VRM_MAXI_CURRENT_LIMIT_BYTE |
| `0x75B` | ADDR_EC_MAIN_FAN_L_DUTY_BYTE |
| `0x75C` | ADDR_EC_MAIN_FAN_R_DUTY_BYTE |
| `0x75D` | ADDR_TRIGGER_BYTE2 |
| `0x765` | ADDR_SUPPORT_BYTE1 |
| `0x766` | ADDR_SUPPORT_BYTE2 |
| `0x767` | ADDR_TRIGGER_BYTE |
| `0x768` | ADDR_STAUTS_BYTE |
| `0x769` | ADDR_AP_EC_LOGO_R / ADDR_RGBKB_LEVEL_R |
| `0x76A` | ADDR_AP_EC_LOGO_G / ADDR_RGBKB_LEVEL_G |
| `0x76B` | ADDR_AP_EC_LOGO_B / ADDR_RGBKB_LEVEL_B |
| `0x76C` | ADDR_RGBKB_LEVEL_DEFAULT_R |
| `0x76D` | ADDR_RGBKB_LEVEL_DEFAULT_G |
| `0x76E` | ADDR_RGBKB_LEVEL_DEFAULT_B |
| `0x76F` | ADDR_RGBKB_MUSIC_NO |
| `0x771` | ADDR_ROMID |
| `0x772` | ADDR_ROMID2 |
| `0x782` | ADDR_BIOS_OEM_BYTE2 |
| `0x783` | ADDR_PL1_SETTING_VALUE |
| `0x784` | ADDR_PL2_SETTING_VALUE |
| `0x785` | ADDR_PL4_SETTING_VALUE |
| `0x786` | ADDR_L1_PWM_DEFAULT_MYFAN3 / ADDR_TimAP_TccOffset_Setting |
| `0x787` | ADDR_L2_PWM_DEFAULT_MYFAN3 / ADDR_TimAP_FanSwitchSpeedT100mSec |
| `0x788` | ADDR_L3_PWM_DEFAULT_MYFAN3 |
| `0x789` | ADDR_L1_PWM_DEFAULT_MYFAN2 / ADDR_L4_PWM_DEFAULT_MYFAN3 |
| `0x78A` | ADDR_L2_PWM_DEFAULT_MYFAN2 / ADDR_L5_PWM_DEFAULT_MYFAN3 |
| `0x78B` | ADDR_L3_PWM_DEFAULT_MYFAN2 / ADDR_MYFAN3_GPU_SETTING |
| `0x78C` | ADDR_AP_EC_LOGO_CONFIRM / ADDR_AP_OEM_BYTE2 / ADDR_L4_PWM_DEFAULT_MYFAN2 / ADDR_SINGLEKBL_ENABLE |
| `0x78D` | ADDR_L5_PWM_DEFAULT_MYFAN2 |
| `0x78E` | ADDR_SINGLEKBL_SUPPORTPOWER / ADDR_SUPPORT_BYTE6 |
| `0x79E` | ADDR_MYFANI_MIN_SPEED |
| `0x79F` | ADDR_MYFANI_MIN_TEMP |
| `0x7A0` | ADDR_MYFANI_EXTRA_SPEED |
| `0x7A3` | ADDR_BIOS_OEM_BYTE3 |
| `0x7A4` | ADDR_AP_BIOS_BYTE |
| `0x7A5` | ADDR_AP_OEM_BYTE3 |
| `0x7A6` | ADDR_AP_OEM_BYTE4 |
| `0x7A7` | ADDR_BATTERYSAVER_PL1_DEFAULT_VALUE |
| `0x7A8` | ADDR_BATTERYSAVER_PL2_DEFAULT_VALUE |
| `0x7A9` | ADDR_BATTERYSAVER_PL4_DEFAULT_VALUE |
| `0x7AA` | ADDR_BATTERYSAVER_D_DEFAULT_VALUE |
| `0x7AB` | ADDR_AP_EC_LOGO / ADDR_MyFanCCI_Mode_Index |
| `0x7B0` | ADDR_MyFanCCI_Mode_Profile1 |
| `0x7B1` | ADDR_MyFanCCI_Mode_Profile2 |
| `0x7B2` | ADDR_MyFanCCI_Mode_Profile3 |
| `0x7B9` | ADDR_BATTERY_CHARGE_LIMIT_UP |
| `0x7C5` | ADDR_AP_OEM_BYTE5 |
| `0x7C6` | ADDR_AP_OEM_BYTE6 |
| `0x7C7` | ADDR_AP_OEM_BYTE7 |
| `0x7C8` | ADDR_AP_OEM_BYTE8 |
| `0x7CA` | ADDR_BIOS_OEM_BYTE8 |
| `0x7CC` | ADDR_COMPLEX_POWER_STATUS |
| `0x7D0` | ADDR_BATTERY_CHARGE_LIMIT_DOWN |
| `0x7D2` | ADDR_ModuleID_GPU |
| `0x7D3` | ADDR_ModuleID |
| `0x7D8` | ADDR_GAMING_TCC_OFFSET_DEFAULT_VALUE |
| `0x7D9` | ADDR_OFFICE_TCC_OFFSET_DEFAULT_VALUE |
| `0x7DA` | ADDR_TURBO_TCC_OFFSET_DEFAULT_VALUE |
| `0x7E6` | ADDR_LC_FAN_VALUE |
| `0x7E7` | ADDR_LC_PUMP_VALUE |
| `0x7E8` | ADDR_EC_DEFAULT_MODE |
| `0x7FB` | ADDR_CHANGE_PORT_ID_WKD |
| `0xD00` | ADDR_AP_OEM_SingleZone |
| `0xD4F` | ADDR_AP_MISCSWITCH2 |
| `0xF00` | ADDR_CPU_FAN_TABLE_TEMP_UP0 / ADDR_TABLE_F1_CPU_TEMP_UP0 |
| `0xF10` | ADDR_CPU_FAN_TABLE_TEMP_DOWN0 / ADDR_TABLE_F1_CPU_TEMP_DOWN0 |
| `0xF20` | ADDR_CPU_FAN_TABLE_DUTY0 / ADDR_TABLE_F1_DUTY0 |
| `0xF30` | ADDR_GPU_FAN_TABLE_TEMP_UP0 / ADDR_TABLE_F1_GPU_TEMP_UP0 |
| `0xF40` | ADDR_GPU_FAN_TABLE_TEMP_DOWN0 / ADDR_TABLE_F1_GPU_TEMP_DOWN0 |
| `0xF50` | ADDR_GPU_FAN_TABLE_DUTY0 / ADDR_TABLE_F2_CPU_TEMP_UP0 |
| `0xF5D` | ADDR_RAMFAN1P5_TABLE_STATUS1 |
| `0xF5E` | ADDR_RAMFAN1P5_TABLE_STATUS2 |
| `0xF5F` | ADDR_RAMFAN1P5_TABLE_CTRL |
| `0xF60` | ADDR_TABLE_F2_CPU_TEMP_DOWN0 |
| `0xF70` | ADDR_TABLE_F2_DUTY0 |
| `0xF80` | ADDR_TABLE_F2_GPU_TEMP_UP0 |
| `0xF90` | ADDR_TABLE_F2_GPU_TEMP_DOWN0 |
| `0xFA0` | ADDR_TABLE_F3_CPU_TEMP_UP0 |
| `0xFB0` | ADDR_TABLE_F3_CPU_TEMP_DOWN0 |
| `0xFC0` | ADDR_TABLE_F3_DUTY0 |
| `0xFD0` | ADDR_TABLE_F3_GPU_TEMP_UP0 |
| `0xFE0` | ADDR_TABLE_F3_GPU_TEMP_DOWN0 |

## 已实测的键盘灯结论

硬件：内置键盘是 `ACPI\MSFT0001`（Standard PS/2 Keyboard），**不在 HID 总线上**；
全机没有任何键盘相关的厂商 HID 集合（`VID_30FA` 是英菲克鼠标、`TABLETHID` 是 HUION 数位板、
`UNIW0001` 是触摸板）。所以键盘灯**只可能走 EC**。

| 实验 | 结果 |
|---|---|
| 写 `0x78C`(CONFIRM) 为 0/32/64/96/128 | **灯光无变化**；且 EC 会把写入顶回去（读回始终 0x80）。说明该地址在本机是 `L4_PWM_DEFAULT_MYFAN2`，不是 logo confirm —— **同一地址按机型复用** |
| 写 `0x769/0x76A/0x76B` = (50,0,0) | **颜色无变化**（原值 0/50/50） |
| 写 `0x769/0x76A/0x76B` = (255,0,0) | **灯被关掉**（可恢复）→ 证明这三个寄存器**确实接在灯上**，但 255 超出有效范围 |
| 高频监视按键（184 Hz，54 个寄存器） | 按键引发的变化集中在一批寄存器上，其中 `0x78C` 呈 **32 的整数倍** 阶梯（0/32/64/96/128 = 5 档） |

`<SetColorMode>` 方法里可见的写序列（IL 片段）：

```il
1897  loc0   WriteEC      ; WriteEC(0x769, R)
1898  loc1   WriteEC      ; WriteEC(0x76A, G)
1899  loc2   WriteEC      ; WriteEC(0x76B, B)
1932  ReadEC(0x78C) -> loc3 ;  loc3 | 16 ;  WriteEC(0x78C, ...)
1895  ReadEC(0x767) -> arg3 ;  arg3 & 0x7F ;  WriteEC(0x767, ...)   ; 位域读-改-写
1963  ReadEC(0x7AB) -> loc1 ;  loc1 & 0x1F ;  loc1 | loc2 ;  WriteEC(0x7AB, ...)  ; 位域读-改-写
```

## 尚未解决 / 卡点

1. **模式使能值未知**。`0x767`（低 7 位）与 `0x7AB`（低 5 位）都是位域，OEM 用读-改-写设置，
   但**具体写入什么值**取决于调用方传入的参数，需要完整反编译 `<SetColorMode>` 才能还原。
2. **R/G/B 的取值范围未知**。原值 50 有效、255 会关灯；怀疑是 0–100 或某个档位数。
3. `ADDR_AP_OEM_SingleZone = 0xD00` 与 `0x200` 是同一份数据的两个镜像地址
   （`0xD50` 起是 `0x250` 序列号字符串的镜像，偏移正好 0xB00），当前值 `[5, R, G, B]`。
4. 本机 `PROJECT_ID = 0x740 = 25`、`OEMSERVICE_PROJECT_ID = 0x74C = 216`。
   OEM 存在**同一地址按机型复用**的现象（见上表多个名字指向同一地址），
   所以不能假定某个名字在本机就成立——必须逐个实测。

## 为什么无法继续靠反编译拿到确切取值：程序集被重度混淆

`GCUService.exe` 的 IL 层做了针对性混淆。实测到的形态：

| 现象 | 实测证据 |
|---|---|
| 大量方法被替换成 `ldstr` + `newobj` + `throw` 的**桩** | `SetColorMode` 本体（RVA `0x970FF8`，bodySize 仅 11）就是这个桩；MethodDef 里 row 1..5、5000 等**几十行都指向同一个 RVA `0x970FF8`** |
| 方法体**去重** | row 2028 / 2068 / 2103 / 2140 共享 RVA `0x034514`；`<SetColorMode>b__0` 与 `<SetColorMode>b__1` 共享 RVA `0xC4E1A`（bodySize 仅 22） |
| 部分 MethodDef 的 RVA **清零** | row 1000 / 9000 / 9574 的 RVA = 0 |
| `#US`（用户字符串）堆**加密** | 内容形如 `7f 00 7e 00 c6 00 a6 00 74 00 73 00 96 00 7a 00 70 00…`（字母与高位字节混杂），无法按字符串字面量定位代码 |

**结论**：从 Constant 表拿**常量值**是可靠的（本文件主要内容），
但无法把某个常量可靠地归属到某段代码，也就无法还原 `0x767` / `0x7AB` 这两个位域寄存器
在每个分支下**具体写入的数值**。这不是解析器写错，是对方刻意为之。

对比：`ACPIDriverDll.dll`（原生 x64，无混淆）反而好读得多 —— 风扇强冷那条链路就是靠它反汇编打通的。

## 复现本次分析用的脚本

| 脚本 | 作用 |
|---|---|
| `D:\deep.1\ref\constfind.py` | 从 Constant 表提取全部 `ADDR_*` 常量值（本文件数据来源） |
| `D:\deep.1\ref\ildis.py` | 完整 IL 反汇编器（带自校验：解完必须正好落在方法体末尾） |
| `D:\deep.1\ref\whowrites.py` | 按方法体真实范围 `[RVA, RVA+bodySize)` 定位"谁引用了某地址" |
| `D:\deep.1\ecwork\rgb.py` | 键盘灯 R/G/B 读写与还原（含原值备份 `rgb_orig.json`） |

