// ============================================================================
//  SysConsole — HotkeyForm.cs
//  快捷键设置对话框。核心是一个"按键录制框"，能捕获 Windows 看得到的任何按键
//  （用来试探 Fn 组合到底有没有产生事件）。
//
//    · 编译：系统自带 csc.exe（.NET Framework 4.8），无 SDK / 无网络 / 无第三方库
//    · 语法：C# 5，不用 async/await、字符串插值、nameof 等新语法
//    · 编码：UTF-8；.ps1 脚本另需纯 ASCII 或带 BOM，否则 PS 5.1 会按 GBK 解码
//    · 硬件寄存器地址来自原厂文件反汇编 + 本机实测，出处见 docs/ 下的协议文档
// ============================================================================

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace SysConsole
{
    public class HotkeyForm : Form
    {
        CheckBox chkEnable;
        Label lblHint, lblStatus;
        List<HotkeyBinding> _work = new List<HotkeyBinding>();
        TextBox[] _display;
        Button[] _rec;
        Button[] _clr;
        KeyboardHook _hook;
        int _recording = -1;

        public HotkeyStore.Config Result = new HotkeyStore.Config();

        static readonly Color CBack = Color.FromArgb(250, 250, 252);
        static readonly Color CText = Color.FromArgb(32, 36, 44);
        static readonly Color CSub = Color.FromArgb(120, 128, 140);
        static readonly Color CRecord = Color.FromArgb(255, 236, 160);

        public HotkeyForm(HotkeyStore.Config cfg)
        {
            List<HotkeyBinding> src = (cfg != null && cfg.Bindings != null)
                ? cfg.Bindings : HotkeyStore.Defaults();
            for (int i = 0; i < src.Count; i++) _work.Add(src[i].Clone());

            BuildUi();
            chkEnable.Checked = cfg != null && cfg.Enabled;
            RefreshRows();
        }

        int Measure(string s)
        {
            return TextRenderer.MeasureText(s, Font).Width;
        }

        // 系统 DPI / 96。这个窗口的尺寸全是手写常量，而字体是"点"、会随 DPI 放大 ——
        // 不乘 DPI 的话，150% 屏上 9pt 行高 25px 会被塞进 20px 的框里，文字上下被切。
        float _k = 1f;
        int S(int v) { return (int)Math.Round(v * _k); }
        int TextH() { return Font.Height + S(8); }

        void BuildUi()
        {
            _k = UiScaleStore.DpiK();
            Text = "快捷键设置";
            ClientSize = new Size(S(680), S(360));
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            BackColor = CBack;
            Font = new Font("Microsoft YaHei UI", 9F);
            // 缩放全部由 S() 手工完成，关掉自带的字体自动缩放，避免两套叠加
            AutoScaleMode = AutoScaleMode.None;

            int margin = S(16);
            int contentW = ClientSize.Width - margin * 2;

            chkEnable = new CheckBox();
            chkEnable.Text = "启用全局快捷键（最小化到托盘后依然生效）";
            chkEnable.AutoSize = false;
            chkEnable.Location = new Point(margin, S(14));
            chkEnable.Size = new Size(Measure(chkEnable.Text) + S(28), TextH() + S(2));
            chkEnable.CheckedChanged += delegate { UpdateEnableState(); };

            lblHint = new Label();
            lblHint.Text = "点击「录制」后按下想要的组合，Esc 取消。\r\n" +
                           "建议使用 Ctrl/Alt/Shift/Win + 键等组合键。\r\n" +
                           "纯 Fn 组合能否绑定取决于固件；按了没反应即为不支持。";
            lblHint.AutoSize = false;
            lblHint.Location = new Point(margin, S(46));
            lblHint.Size = new Size(contentW, Font.Height * 3 + S(16));
            lblHint.ForeColor = CSub;

            Controls.Add(chkEnable);
            Controls.Add(lblHint);

            int n = _work.Count;
            _display = new TextBox[n];
            _rec = new Button[n];
            _clr = new Button[n];

            // fixed label column, sized from the longest action name
            int labelCol = 0;
            for (int i = 0; i < n; i++)
            {
                int w = Measure(_work[i].Label);
                if (w > labelCol) labelCol = w;
            }
            int tbX = margin + labelCol + S(14);
            int tbW = S(320);

            for (int i = 0; i < n; i++)
            {
                int y = S(132) + i * S(40);
                int idx = i;

                Label lb = new Label();
                lb.Text = _work[i].Label;
                lb.AutoSize = false;
                lb.Location = new Point(margin, y + (TextH() - Font.Height) / 2);
                lb.Size = new Size(labelCol + S(8), TextH());
                lb.ForeColor = CText;

                TextBox tb = new TextBox();
                tb.ReadOnly = true;
                tb.TextAlign = HorizontalAlignment.Center;
                tb.Location = new Point(tbX, y);
                tb.Size = new Size(tbW, Font.Height + S(10));
                tb.BackColor = Color.White;
                _display[i] = tb;

                Button rb = new Button();
                rb.Text = "录制";
                rb.Location = new Point(tbX + tbW + S(10), y - S(1));
                rb.Size = new Size(Measure("录制") + S(30), TextH() + S(6));
                rb.FlatStyle = FlatStyle.System;
                rb.Click += delegate { StartRecord(idx); };
                _rec[i] = rb;

                Button cb = new Button();
                cb.Text = "清除";
                cb.Location = new Point(rb.Right + S(8), y - S(1));
                cb.Size = new Size(Measure("清除") + S(30), TextH() + S(6));
                cb.FlatStyle = FlatStyle.System;
                cb.Click += delegate
                {
                    _work[idx].Modifiers = 0;
                    _work[idx].Vk = 0;
                    RefreshRows();
                    lblStatus.Text = _work[idx].Label + " 已清除绑定。";
                };
                _clr[i] = cb;

                Controls.Add(lb);
                Controls.Add(tb);
                Controls.Add(rb);
                Controls.Add(cb);
            }

            int statusY = S(132) + n * S(40) + S(14);
            lblStatus = new Label();
            lblStatus.Text = "";
            lblStatus.AutoSize = false;
            lblStatus.Location = new Point(margin, statusY);
            lblStatus.Size = new Size(contentW, TextH());
            lblStatus.ForeColor = CSub;

            int btnY = statusY + TextH() + S(18);

            Button bDef = new Button();
            bDef.Text = "恢复默认";
            bDef.Location = new Point(margin, btnY);
            bDef.Size = new Size(Measure("恢复默认") + S(32), TextH() + S(8));
            bDef.FlatStyle = FlatStyle.System;
            bDef.Click += delegate
            {
                _work = HotkeyStore.Defaults();
                RefreshRows();
                lblStatus.Text = "已恢复为默认快捷键。";
            };

            Button bOk = new Button();
            bOk.Text = "确定";
            bOk.Size = new Size(Measure("确定") + S(40), TextH() + S(8));
            bOk.Location = new Point(ClientSize.Width - margin - bOk.Width, btnY);
            bOk.FlatStyle = FlatStyle.System;
            bOk.Click += OnOk;

            Button bCancel = new Button();
            bCancel.Text = "取消";
            bCancel.Size = new Size(Measure("取消") + S(40), TextH() + S(8));
            bCancel.Location = new Point(bOk.Left - S(10) - bCancel.Width, btnY);
            bCancel.FlatStyle = FlatStyle.System;
            bCancel.Click += delegate { StopRecord(); DialogResult = DialogResult.Cancel; Close(); };

            Controls.Add(lblStatus);
            Controls.Add(bDef);
            Controls.Add(bOk);
            Controls.Add(bCancel);

            // grow the dialog if the rows need more room than planned
            int needH = btnY + TextH() + S(8) + S(16);
            if (needH > ClientSize.Height) ClientSize = new Size(ClientSize.Width, needH);

            AcceptButton = bOk;
            CancelButton = bCancel;
            FormClosing += delegate { StopRecord(); };
        }

        void OnOk(object sender, EventArgs e)
        {
            StopRecord();
            Result = new HotkeyStore.Config();
            Result.Enabled = chkEnable.Checked;
            Result.Bindings = _work;
            DialogResult = DialogResult.OK;
            Close();
        }

        void RefreshRows()
        {
            for (int i = 0; i < _work.Count; i++)
            {
                _display[i].Text = (_work[i].Vk == 0) ? "（未绑定）" : _work[i].Text;
            }
            UpdateEnableState();
        }

        void UpdateEnableState()
        {
            bool en = chkEnable.Checked;
            for (int i = 0; i < _work.Count; i++)
            {
                _display[i].Enabled = en;
                _rec[i].Enabled = en;
                _clr[i].Enabled = en && _work[i].Vk != 0;
            }
        }

        void StartRecord(int idx)
        {
            StopRecord();
            _recording = idx;
            _rec[idx].Text = "按下…";
            _rec[idx].BackColor = CRecord;
            lblStatus.Text = "正在录制 " + _work[idx].Label + " —— 请按下组合键（Esc 取消）。";

            KeyboardHook hook = new KeyboardHook();
            hook.OnKeyDown = delegate(uint vk, uint scan, uint flags)
            {
                if (vk == 0x1B)   // Esc
                {
                    lblStatus.Text = "已取消录制。";
                    StopRecord();
                    return true;
                }
                if (HotkeyKeys.IsModifierKey(vk)) return false;   // keep waiting for a real key

                uint mods = HotkeyKeys.CurrentModifiers();
                if (!HotkeyKeys.SafeCombination(mods, vk))
                {
                    lblStatus.Text = "「" + HotkeyKeys.KeyName(vk) + "」单独使用会干扰输入，请改用组合键或 F1-F12。";
                    StopRecord();
                    return true;
                }

                _work[idx].Modifiers = mods;
                _work[idx].Vk = vk;
                StopRecord();
                RefreshRows();
                lblStatus.Text = _work[idx].Label + " 已绑定为 " + _work[idx].Text;
                return true;
            };

            if (!hook.Install())
            {
                lblStatus.Text = "键盘钩子安装失败，无法录制（可能被安全软件拦截）。";
                StopRecord();
                return;
            }
            _hook = hook;
        }

        void StopRecord()
        {
            if (_hook != null)
            {
                try { _hook.Dispose(); } catch { }
                _hook = null;
            }
            if (_recording >= 0 && _recording < _rec.Length)
            {
                _rec[_recording].Text = "录制";
                _rec[_recording].BackColor = SystemColors.Control;
            }
            _recording = -1;
        }
    }
}
