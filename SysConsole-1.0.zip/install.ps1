#Requires -RunAsAdministrator
# install.ps1 - install SysConsole into Program Files and register autostart there.
# Run ELEVATED. Keeps the source tree intact.
#
# ASCII only on purpose (Windows PowerShell 5.1 mangles UTF-8 scripts without a BOM).

$ErrorActionPreference = 'Stop'

$srcRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$srcExe = Join-Path $srcRoot 'bin\SysConsole.exe'
$dstRoot = Join-Path $env:ProgramFiles 'SysConsole'
$dstExe = Join-Path $dstRoot 'SysConsole.exe'

Write-Host '=== Installing SysConsole ===' -ForegroundColor Cyan

if (-not (Test-Path $srcExe)) {
    throw "Not built yet. Run build.ps1 first. Missing: $srcExe"
}

Write-Host '  [1] stopping any running instance'
Get-Process SysConsole -ErrorAction SilentlyContinue | ForEach-Object {
    Write-Host ("      kill PID " + $_.Id)
    Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
}
Start-Sleep -Seconds 3

Write-Host '  [2] copying files'
if (-not (Test-Path $dstRoot)) { New-Item -ItemType Directory -Path $dstRoot | Out-Null }
Copy-Item -LiteralPath $srcExe -Destination $dstExe -Force
$readme = Join-Path $srcRoot 'README.md'
if (Test-Path $readme) { Copy-Item -LiteralPath $readme -Destination $dstRoot -Force }
Write-Host ("      " + $dstExe)
Write-Host ("      " + $dstRoot)

Write-Host '  [3] registering autostart against the new path'
& $dstExe --autostart on

Write-Host '  [4] creating Start Menu shortcut'
# The shortcut name is built from code points so this file stays pure ASCII.
# (Literal CJK here would be mangled by PowerShell 5.1 decoding a BOM-less UTF-8 file.)
$cnName = [string]([char]0x7CFB + [char]0x7EDF + [char]0x63A7 + [char]0x5236 + [char]0x53F0)
$lnk = Join-Path $env:ProgramData ("Microsoft\Windows\Start Menu\Programs\" + $cnName + ".lnk")
try {
    $ws = New-Object -ComObject WScript.Shell
    $sc = $ws.CreateShortcut($lnk)
    $sc.TargetPath = $dstExe
    $sc.WorkingDirectory = $dstRoot
    $sc.Description = 'SysConsole'
    $sc.Save()
    Write-Host ("      " + $lnk)
} catch {
    Write-Host ("      shortcut failed: " + $_.Exception.Message) -ForegroundColor Yellow
}

Write-Host '  [5] verification'
$t = Get-ScheduledTask -TaskName 'SysConsoleAutostart' -ErrorAction SilentlyContinue
if ($t) {
    Write-Host ("      task state    : " + $t.State)
    Write-Host ("      task runlevel : " + $t.Principal.RunLevel)
    Write-Host ("      task command  : " + $t.Actions[0].Execute)
    Write-Host ("      task args     : " + $t.Actions[0].Arguments)
} else {
    Write-Host '      task NOT found' -ForegroundColor Red
}
Write-Host ("      installed exe : " + (Test-Path $dstExe))

Write-Host ''
Write-Host 'Install complete. Log in again (or run the task) to see the tray icon.' -ForegroundColor Green
Write-Host 'The original source tree can stay where it is, or be deleted after copying.'
