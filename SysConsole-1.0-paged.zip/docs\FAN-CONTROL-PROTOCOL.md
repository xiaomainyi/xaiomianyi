# 原生风扇控制 —— 完整逆向工程报告

> 目标：不安装、不运行机械革命控制中心的任何组件，直接控制风扇（一键强冷）。
> 状态：**已实现并实测验证。** 代码见 `src/Ec.cs`，入口 `--fanboost on|off|status`。

---

## 1. 结论摘要

| 项目 | 结果 |
|---|---|
| 控制链路 | `SysConsole` → `\\.\ACPIDriver` → `UWACPIDriver.sys` → EC |
| 是否需要 OEM 软件 | **不需要**（0 个 OEM 进程 / 服务 / DLL） |
| 是否需要第三方工具 | 不需要（无 devcon、无 inpout32、无 WinRing0） |
| 驱动签名 | 微软 WHQL（`oem111.inf`，类 `{4d36e97d-e325-11ce-bfc1-08002be10318}`，KMDF 1.15） |
| 强冷寄存器 | EC `0x751`，**强冷位 = `0x40`** |
| 实测效果 | 风扇1 **4540 → 5875 RPM**（+29%），风扇2 **4482 → 5762 RPM**（+29%），占空比 **138 → 200** |
| 可逆性 | 100%（关闭时精确还原进入强冷前的基础模式） |
| 附加能力 | 双风扇实时转速、风扇模式、PL1/PL2/PL4、TCC 偏移读取、**按温度的软件分档曲线**（见 §7.4） |

**核心结论**：机械革命（Uniwill 代工）的风扇控制完全走 EC 寄存器，而访问 EC 的通道是一个
普通的内核驱动设备 `\\.\ACPIDriver`。这个设备对应的 ACPI 硬件节点是 BIOS 里**本来就存在**的
`_SB.INOU`（`_HID = "INOU0000"`），驱动程序也由 Windows 自带安装。因此只要把设备枚举出来，
任何程序都能用标准 `DeviceIoControl` 读写 EC——OEM 控制中心只是一个外壳。

---

## 2. 完整链路

```
   BIOS ACPI 命名空间
   └─ _SB.INOU   (_HID = "INOU0000")          ← 真实存在的硬件设备，不是软件枚举
        │  PnP 自动匹配
        ▼
   ACPI\INOU0000\0   "ACPIDriver"  (Uniwill, 类 System)
        │  oem111.inf → uwacpidriver.inf
        ▼
   UWACPIDriver.sys  (KMDF 1.15, 46,352 字节)  ← 微软 WHQL 签名
        │  IoCreateDevice + 符号链接
        ▼
   \\.\ACPIDriver   ← 用户态可打开的设备对象
        │
        ▼
   嵌入式控制器 (EC)  寄存器 0x000 - 0x7FF
```

OEM 原链路（仅作对照，本方案完全不使用）：

```
CCUWinUI.dll ──named pipe "SystrayExtensionPipe"──▶ GCUService.exe (.NET, 18 MB)
                                                      └─▶ ACPIDriverDll.dll (3.9 MB)
                                                            └─▶ DeviceIoControl ──▶ \\.\ACPIDriver
```

`ACPIDriverDll.dll` 只是把 `CreateFile` + `DeviceIoControl` 包了一层的转发层，
它的 19 个导出函数（`ReadEC` / `WriteEC` / `ReadIndexIO` / `WriteIndexIO` / `SMAPCTable` …）
全部都是 `CreateFileW` + `DeviceIoControl` + `CloseHandle`。所以完全可以自己实现。

---

## 3. 设备恢复（关键一步）

### 3.1 问题

OEM 卸载脚本会执行：

```
"C:\Program Files\OEM\机械革命控制中心\AirplaneDriver\devcon.exe" remove acpi\INOU0000
```

（见 `C:\Windows\INF\setupapi.dev.log` 第 34837/34839 行）

这会**删除设备实例**，导致 `\\.\ACPIDriver` 消失、`Services\UWACPIDriver\Enum\Count = 0`。
但驱动包仍留在 DriverStore 里（`uwacpidriver.inf_amd64_*`），而且
`ACPI\INOU0000` 是 BIOS ACPI 命名空间中的真实设备——**重新扫描一次就会自动回来**。

### 3.2 恢复命令

```powershell
pnputil /scan-devices          # 需要管理员
```

执行后 PnP 会重新枚举 `ACPI\INOU0000`，自动匹配 `oem111.inf`，
加载 `UWACPIDriver.sys` 并创建 `\\.\ACPIDriver`。**无需重装任何 OEM 软件。**

SysConsole 已内置这个自愈逻辑：`Ec.EnsureDevice()`，在 GUI 启动时后台执行一次。

### 3.3 验证

```powershell
pnputil /enum-devices /class System | Select-String -Context 0,6 INOU0000
```

期望输出：

```
实例 ID:     ACPI\INOU0000\0
设备描述:  ACPIDriver
制造商名称: Uniwill
状态:       已启动
驱动程序:   oem111.inf
```

---

## 4. IOCTL 协议

反汇编自 `ACPIDriverDll.dll`（导出 `ReadEC` RVA `0x3410`、`WriteEC` RVA `0x34F0`，
每个 224 字节），并用写入回读实测确认。

### 4.1 打开设备

```c
CreateFileW(L"\\\\.\\ACPIDriver",
            GENERIC_READ | GENERIC_WRITE,   // 0xC0000000
            FILE_SHARE_READ | FILE_SHARE_WRITE,  // 3
            NULL, OPEN_EXISTING /*3*/, 0, NULL);
```

### 4.2 共享缓冲区

输入和输出是**同一个指针**，长度 **`0x400000`（4 MiB）**，与 OEM DLL 完全一致：

```
偏移 0..3   地址 (小端 int32)
偏移 4..7   数值 (仅写操作使用，小端 int32)
偏移 0      读操作的结果字节
```

### 4.3 读 / 写

```c
// 读
*(int32_t*)buf = addr;
DeviceIoControl(h, 0x9C40A488, buf, 0x400000, buf, 0x400000, &ret, NULL);
value = buf[0];

// 写
*(int32_t*)buf     = addr;
*(int32_t*)(buf+4) = value;
DeviceIoControl(h, 0x9C40A48C, buf, 0x400000, buf, 0x400000, &ret, NULL);
```

> 实测 `ret`（bytesReturned）恒为 `0x400000`。

### 4.4 全部 IOCTL 码

`DeviceType = 0x9C40`，`Method = METHOD_BUFFERED`，`Access = FILE_WRITE_ACCESS`。

| 功能 | IOCTL | 功能 | IOCTL |
|---|---|---|---|
| ReadCMOS | `0x9C40A480` | WriteCMOS | `0x9C40A484` |
| **ReadEC** | **`0x9C40A488`** | **WriteEC** | **`0x9C40A48C`** |
| ReadMEMB | `0x9C40A490` | WriteMEMB | `0x9C40A498` |
| ReadPCI | `0x9C40A4A0` | WritePCI | `0x9C40A4A4` |
| ReadIO | `0x9C40A4C0` | WriteIO | `0x9C40A4C4` |
| ReadIndexIO | `0x9C40A4C8` | WriteIndexIO | `0x9C40A4CC` |
| TempRead1/2/3 | `0x9C40A4D0` / `D4` / `D8` | TempWrite1/2/3 | `0x9C40A4DC` / `E0` / `E4` |

---

## 5. EC 寄存器表（0x700 - 0x7FF，本机实测）

### 5.1 风扇 —— 本报告核心

| 地址 | 含义 | 本机实测值 | 说明 |
|---|---|---|---|
| **`0x751`** | **风扇模式（位域）** | `0x30` | 见 §6 |
| `0x75B` | 风扇1 占空比 | 138 → 200 | **只读输出**，写入会被 EC 立刻覆盖 |
| `0x75C` | 风扇2 占空比 | 138 → 200 | 同上 |
| `0x464` / `0x465` | 风扇1 转速 高/低字节 | `0x12` / `0x83` | `rpm = (0x464<<8) \| 0x465` |
| `0x46C` / `0x46B` | 风扇2 转速 高/低字节 | `0x12` / `0x82` | `rpm = (0x46C<<8) \| 0x46B` |
| `0x740` | 风扇状态/告警 | `0x19` | |
| `0x741` | 风扇告警 | `0x84` | |
| `0x743` - `0x747` | MYFAN2 曲线 L1-L5 PWM | `0x00` | 自定义曲线写入点 |
| `0x748` - `0x74B` | 风扇曲线点 | `0x80 0x00 0x00 0x00` | OEM 使用最频繁（63 处） |
| `0x752` | 副控制字节 | `0x6C` | |
| `0x758` | 副控制字节 | `0x40` | |

### 5.2 功耗与温度

| 地址 | 含义 | 本机实测值 |
|---|---|---|
| `0x730` / `0x731` | GAMING PL1 / PL2 (W) | 75 / 75 |
| `0x732` / `0x733` | GAMING PL4 / 标志 | 200 / 1 |
| `0x734` / `0x735` | OFFICE PL1 / PL2 (W) | 45 / 45 |
| `0x736` / `0x737` | OFFICE PL4 / 标志 | 200 / 1 |
| `0x783` / `0x784` / `0x785` | 生效中 PL1 / PL2 / PL4 | 0 / 0 / 0 |
| `0x7D8` | TCC 温度偏移 | 5 |
| `0x7A5` - `0x7AA` | MyFan 参数组 | `00 01 82 82 C8 01` |
| `0x7AB` | MyFan 模式索引 | 0 |
| `0x79E` / `0x79F` / `0x7A0` | MYFANI 最低转速 / 最低温度 / 附加转速 | 44 / 0 / 0 |

---

## 6. 风扇模式位域（`0x751`）—— 强冷的实现

### 6.1 实测对照表

在每个候选值下静置 16 秒，记录稳态占空比与转速（环境温度寄存器全程不变）：

| `0x751` | 模式 | 稳态占空比 | 风扇1 RPM | 风扇2 RPM |
|---|---|---|---|---|
| `0x00` | 安静 | ≈120 | 4114 | 3915 |
| `0x10` | 标准 | ≈140 | 4697 | 4482 |
| `0x30` | **出厂默认**（本机原始值） | ≈140 | 4587 | 4482 |
| **`0x40`** | **★ 强冷** | **200** | **5891** | **5762** |
| `0x70` | `0x30 \| 0x40` | 200 | 5875 | 5762 |
| `0xA0` | 静音 | ≈100 | 3617 | 3373 |

### 6.2 关键性质：`0x40` 是"位"，不是"值"

实测发现 EC 会自行把强冷位与基础模式**按位或**：写入 `0x40` 后过一段时间读回会变成 `0x70`
（`0x30 | 0x40`）。因此：

* **判断必须按位测试** —— `(reg751 & 0x40) != 0`，不能写 `reg751 == 0x40`。
* **开启时应写 `base | 0x40`** —— 保留用户原本的基础模式。
* **关闭时写回进入强冷前记录的 `base`** —— 精确还原，不会顺带把模式改成别的。

### 6.3 与 OEM 代码的对应

在 `GCUService.exe` 的 .NET IL 中，`0x751` 被引用 **96 次**（全部 EC 地址中最多），
其中成对出现：

```il
ldc.i4   0x751
ldc.i4.s 0x40        ; 强冷 ON   ← FAN_BOOST_ON
callvirt WriteEC
...
ldc.i4   0x751
ldc.i4.0             ; 强冷 OFF  ← FAN_BOOST_OFF
callvirt WriteEC
```

另外三处一段式写入对应三个风扇档位：`0x00`（安静）/ `0xA0`（静音）/ `0x10`（标准）。

---

## 7. SysConsole 中的实现

### 7.1 命令行

```powershell
SysConsole.exe --fan                    # EC 报告：模式、双风扇转速、占空比、PL 值
SysConsole.exe --fanboost status        # 强冷状态
SysConsole.exe --fanboost on            # 开启强冷
SysConsole.exe --fanboost off           # 关闭并还原
SysConsole.exe --fanboost toggle
SysConsole.exe --fanboost ensure        # 设备丢失时重新枚举
```

### 7.2 界面

* 「性能场景与风扇」分组新增 **一键强冷** 按钮（强冷中变红显示"强冷已开启"）。
* 同组右侧实时显示 `风扇 xxxx / xxxx RPM　占空比 xx/xx　模式 xxx`，每秒刷新。
* 托盘右键菜单新增 **一键强冷**（带勾选态）。
* 全局快捷键新增 **Ctrl+Alt+F** 一键强冷（可在「快捷键设置…」中改）。
* 超温保护在强冷期间照常工作。

### 7.3 安全设计

| 风险 | 处理 |
|---|---|
| 把用户的风扇模式改掉 | 开启时记录 `0x751` 原值到 `%LOCALAPPDATA%\SysConsole\fanboost.txt`，关闭时精确还原 |
| 强冷期间程序重启 | 记录文件仍在，关闭时按记录还原；无记录则回退到出厂值 `0x30` |
| 重复点击 | 幂等：按位判断已开启/已关闭，不重复写 |
| 写入未生效 | 写后 120 ms 回读校验（`WriteVerify`） |
| 设备被删 | 启动时后台自动 `pnputil /scan-devices` 重新枚举 |
| 误写其它寄存器 | 只写 `0x751` 一个寄存器；`0x75B/0x75C` 经实测是只读输出，不尝试写 |

### 7.4 软件风扇曲线（按温度分档）

强冷解决的是「一键拉满」，风扇曲线让 `0x751` 随温度**自动换档**。但它能用的杠杆由硬件决定：本轮只有四档，所以做的是「温度落在哪一段就切哪一档」，而不是逐度指定 PWM。

**可用杠杆（唯一可写寄存器仍是 `0x751`）**：

| 档位 | 写入值 | 稳态占空比 | 说明 |
|---|---|---|---|
| 静音 | `0xA0` | ≈100 | |
| 安静 | `0x00` | ≈120 | |
| 标准 | `0x10` | ≈140 | |
| 强冷 | 基础模式 \| `0x40` | ≈200 | 强冷位，与基础模式按位或 |

`0x75B` / `0x75C`（当前 PWM）实测**只读**，写进去会被 EC 覆盖，所以不存在「直接写目标转速」这条路。

**控制律**（每 1 秒一次，和温度墙、超温保护同一拍，互不干扰 —— 温度墙管发热量，曲线管散热能力）：

```
读取最高热区温度 T
目标档 = 曲线给出的档位（<50 静音 / <65 安静 / <78 标准 / ≥78 强冷）
安全底线 = (T ≥ 80 ? 强冷 : T ≥ 70 ? 标准 : 不变)
实际档 = max(目标档, 安全底线)
升温：立刻写 0x751
降温：把 T 再加一个回差后重新求目标档，只有它仍低于当前档才降档
```

**回差**：默认 3°C。降温必须跌出回差带才降档，避免在阈值附近一格一格地抖。

**安全底线（不可关闭）**：`T ≥ 70°C` 不允许低于「标准」，`T ≥ 80°C` 强制强冷。它**优先于用户曲线**，所以低温段可以放心写安静档。

**与强冷位、温度墙的关系**：`0x40` 可能由手动「一键强冷」或温度墙联动置起。风扇曲线**只清掉本模块自己置的那一次** —— 别人开的强冷位保持不动（和温度墙「只关自己开的那一次」是同一套约定）；切换档位时若读到外部强冷位，写入值会把它一并保留。

**持久化与还原**：配置存 `%LOCALAPPDATA%\SysConsole\fancurve.txt`（`key=value`：`enabled` / `hysteresis` / `point1`..`point4` = 温度上限,档位）。**默认关闭**，默认曲线 `<50 静音 / <65 安静 / <78 标准 / ≥78 强冷`。启用时把进入前的 `0x751` 原值记在**内存**里，关闭曲线或退出程序时精确写回（与 `Ec.FanBoost` 同款做法），不会顺手改掉用户原本的风扇模式。

**命令行**：

```powershell
SysConsole.exe --fancurve                    # 查看曲线、当前 EC 状态与几个温度的预览（只读）
SysConsole.exe --fancurve on | off           # 启用 / 关闭（off 会立刻还原风扇模式）
SysConsole.exe --fancurve set 50 65 78 3     # 设置三个温度上限与回差（档位固定 静音/安静/标准/强冷）
SysConsole.exe --fancurve preview 72         # 只看这个温度会选哪一档，不写 EC
SysConsole.exe --fancurve run 20             # 真的跑一会儿闭环（会写 0x751，结束时还原）
```

**真机实测**（`--fancurve run`，8 秒，风扇 1 / 风扇 2）：

```
试运行前: 0x751=0x00(安静)  2255/2123 RPM  占空比 60/60
  1s  67.9°C 档位 标准   0x751: 0x00 -> 0x10   占空比升到 61→68   转速 2250→2536 RPM
  4s  55.9°C 档位 安静   0x751: 0x10 -> 0x00   转速逐步回落到 2308/2123
  8s  结束，0x751 已还原成 0x00，2255/2123 RPM 占空比 60/60 —— 与起始完全一致
```

升温立即升档、降温因回差滞后才降档、结束时精确还原 —— 三点都在这一段里体现出来。

界面上还会把每一秒实测的（最高热区温度, 风扇1 转速）画成点云（越新越深、最多保留 600 个 ≈ 10 分钟），叠在按满载参考转速画的曲线下方，可用来核对「期望曲线」与「实际散热」是否吻合。注意参考线是持续负载下的稳态值，空载时 EC 会给更低转速，所以实测点通常落在参考线下方。

> **与固件级 5 点曲线的关系**：EC 固件另有一套 **5 点自定义 PWM 曲线**（写 `0x743`–`0x747`，再用 `0x751 = 0x80 | level` 使能），其写协议见 [`docs\FAN-CURVE-PROTOCOL.md`](FAN-CURVE-PROTOCOL.md)（**已逆向、尚未在真机验证**）。本节描述的始终是「按温度切四档」的**软件**曲线，本程序没有使用固件级逐度曲线。

---

## 8. 复现方法

```powershell
# 1. 确认/恢复设备（管理员）
pnputil /scan-devices
pnputil /enum-devices /class System | Select-String INOU0000

# 2. 读取 EC（无需管理员）
D:\deep.1\SystemConsole\bin\SysConsole.exe --fan

# 3. 开启强冷，观察转速
D:\deep.1\SystemConsole\bin\SysConsole.exe --fanboost on
D:\deep.1\SystemConsole\bin\SysConsole.exe --fan        # 风扇1 应升到 ≈5875 RPM，占空比 200

# 4. 关闭
D:\deep.1\SystemConsole\bin\SysConsole.exe --fanboost off
```

仅用 Python 复现（无需 SysConsole）：

```python
import ctypes, ctypes.wintypes as w, struct
k = ctypes.WinDLL("kernel32", use_last_error=True)
k.CreateFileW.restype = ctypes.c_void_p
k.CreateFileW.argtypes = [w.LPCWSTR, w.DWORD, w.DWORD, ctypes.c_void_p, w.DWORD, w.DWORD, ctypes.c_void_p]
k.DeviceIoControl.argtypes = [ctypes.c_void_p, w.DWORD, ctypes.c_void_p, w.DWORD,
                              ctypes.c_void_p, w.DWORD, ctypes.POINTER(w.DWORD), ctypes.c_void_p]
SZ = 0x400000
h = k.CreateFileW("\\\\.\\ACPIDriver", 0xC0000000, 3, None, 3, 0, None)
buf = ctypes.create_string_buffer(SZ)
def rd(a):
    ctypes.memset(buf, 0, 16); buf[0:4] = struct.pack("<I", a); r = w.DWORD(0)
    k.DeviceIoControl(ctypes.c_void_p(h), 0x9C40A488, buf, SZ, buf, SZ, ctypes.byref(r), None)
    return buf.raw[0]
def wr(a, v):
    ctypes.memset(buf, 0, 16); buf[0:8] = struct.pack("<II", a, v); r = w.DWORD(0)
    return bool(k.DeviceIoControl(ctypes.c_void_p(h), 0x9C40A48C, buf, SZ, buf, SZ, ctypes.byref(r), None))

rpm1 = (rd(0x464) << 8) | rd(0x465)      # 风扇1 转速
wr(0x751, rd(0x751) | 0x40)              # 强冷 ON
# wr(0x751, 0x30)                        # 强冷 OFF
```

---

## 9. 注意事项

1. **强冷位是 `0x40`，判断必须按位。** 写成 `== 0x40` 会在 EC 归一化成 `0x70` 后误判为"未开启"。
2. **`0x75B` / `0x75C` 是只读输出。** 实测写入 255 后 1 秒内被 EC 覆盖回原值，`RPM` 完全不变——
   它们反映 EC 的当前决定，不是设定点。
3. **`0x400000` 缓冲区不能随意缩小。** 与 OEM DLL 保持一致最安全；该调用会带来
   每次约 8 MiB 的内核缓冲拷贝，所以不要在高频循环里读 EC（SysConsole 每秒 7 次，可接受）。
4. **强冷是 EC 模式，不是电压欺骗。** 温度寄存器在切换前后完全不变（`0x765=0xA1`、`0x766=0x94`
   —— 这两个不是摄氏度，是原始 AD 值），证明效果来自风扇模式而非温度变化。
5. **只写 `0x751`。** 其它寄存器（尤其 `0x730`-`0x737` 的 PL 值、`0x7D8` 的 TCC 偏移）
   未经充分验证，不应盲写。
6. **`UWACPIDriver` 服务是 `NOT_STOPPABLE`。** 一旦加载，`sc stop` 会返回 1052；
   这是正常现象，它随系统重启复位。
7. **XMP / BIOS 里的风扇设置** 优先级高于 EC；若用户在 BIOS 里设了"全速"，EC 写入可能无效。

---

## 10. 温度墙：为什么不能用 TCC 偏置，以及实际方案

强冷解决的是"散热能力"，温度墙解决的是"发热量"。实现温度墙有两条候选路径：

### 10.1 被排除：Intel TCC 偏置（硬件温度墙）

TCC 偏置让 CPU 在 `Tjmax − offset` 就主动降频，是**最硬**的温度墙——即使控制程序崩溃也依然生效。

但它只能通过写 **MSR 0x1A2**（`TEMPERATURE_TARGET` 的 bits 23:16）实现，需要内核权限。
OEM 用的是安装包里的 `IntelOverclockingSDK.dll`（735 KB）——它自带驱动来写 MSR。

EC 里的 `0x7D8` 读数为 **5**，与从 `SMAPCTable` 独立提取的 `TccOffset = 5` 一致，看起来很像
TCC 偏置。但在 `GCUService.exe` 的 IL 里，`0x7D8` / `0x7D9` / `0x7DA` 只出现在**读取**序列中：

```il
ldc.i4   0x7D8
ldloca.s 0            ; 取地址 → 输出参数
callvirt 0x06000629   ; ReadEC（读），不是 0x0600062A（WriteEC）
```

三处均为读。**没有任何证据表明 `0x7D8` 可经 EC 写入并生效**，所以不做尝试——
盲写一个语义未确认的寄存器去改变 CPU 的温度保护点，风险与收益不成比例。

### 10.2 采用：软件闭环功耗墙 + EC 强冷联动

用已验证的 `powercfg`（最大处理器状态 / 睿频）做闭环，必要时叠加已验证的 EC 强冷：

```
每 1 秒读一次最高热区温度 T：
  T ≥ 目标            → 最大处理器状态下调 step × (1 + 超出/5)，下限 floor
  T ≤ 目标 − 回差      → 上调 step，上限 = 用户滑块设定值
  回差带内             → 不动
  T > 目标 + 5        → 关闭睿频；降回目标 − 回差 以下恢复
  T ≥ 目标 − 联动余量  → 打开 EC 强冷（0x751 |= 0x40）
  T ≤ 目标 − 回差 − 2  → 关闭（仅关闭"由温度墙自己开启的"那一次）
```

**与超温保护的关系**：温度墙是渐进收敛，超温保护是二元兜底。超温保护一旦接管，
温度墙在下一个 tick 让位，避免两个控制器互相覆盖。

**基线持久化**：程序若在压制期间被重启，`powercfg` 的实时值就是被压低的上限。
若不处理，它会被误当成"用户设定值"，形成"每重启一次就永久降一档"的棘轮效应。
所以压制前的基线写入 `wall.txt` 的 `base_state`，重启后温度一降下来就自动还原。
同理，`RefreshPowerUi` 在压制期间**不会**用实时值覆盖滑块。

**实测**（目标临时设为 60 °C 迫使动作）：

```
00:51:49  ThermalWall: 72.1C over target -> max state 82%
00:51:50  ThermalWall: 72.1C over target -> max state 64%
00:51:51  ThermalWall: 75.1C over target -> max state 43%
00:51:52  ThermalWall: 65.1C over target -> max state 32%
00:51:53  ThermalWall: 65.1C over target -> max state 30%    ← 到达下限
00:52:28  ThermalWall: 联动强冷开启 (72.1C) - 强冷已开启（0x751: 0x30 → 0x70）
...
00:54:27  ThermalWall: 恢复上次被压制的基线 100%             ← 重启后自动还原
```

温度 75.9 °C → 57.9 °C，关闭后回到 100%。
