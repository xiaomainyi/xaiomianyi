// ============================================================================
//  SysConsole — MainForm.cs
//  主窗口，也是整个界面的唯一实现文件（布局、自绘、交互、闭环控制都在这）。
//
//  主要内容：
//    PalettePanel          键盘背光调色板控件（自绘网格，点击取色）
//    UiScaleStore          界面缩放设置的持久化
//    MainForm.BuildUi()    全部布局；数值写成"设计值"，由 S()/Sf() 按缩放系数换算
//    MainForm.PaintXxx()   温度区/曲线图/逐核条/内存条的自绘
//    WallTick/GuardTick    温度墙（闭环）与超温保护（二元兜底）的控制逻辑
//    RebuildUi()           改缩放系数后整界面重建
//
//  界面约定：只有两张顶层卡片（系统监控 / 操作面板），分区标题只锚 Left（锚成
//  Left|Right 会横向拉长并盖住右边的标签），同一容器内不允许控件矩形相交。
//
//    · 编译：系统自带 csc.exe（.NET Framework 4.8），无 SDK / 无网络 / 无第三方库
//    · 语法：C# 5，不用 async/await、字符串插值、nameof 等新语法
//    · 编码：UTF-8；.ps1 脚本另需纯 ASCII 或带 BOM，否则 PS 5.1 会按 GBK 解码
//    · 硬件寄存器地址来自原厂文件反汇编 + 本机实测，出处见 docs/ 下的协议文档
// ============================================================================

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace SysConsole
{
    // Panel that paints without flicker. Control.DoubleBuffered is protected,
    // so the flag has to be set from inside a subclass.
    public class BuffPanel : Panel
    {
        public BuffPanel()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.UserPaint |
                     ControlStyles.ResizeRedraw, true);
        }
    }

    /// <summary>
    /// 调色板：按网格铺一堆色块，点哪块就把那块的颜色交给回调。
    /// 用自绘而不是几十个 Button —— 控件数量不涨、窗口拉宽时格子自动重新排布，
    /// 看起来也更像"调色板"而不是一排按钮。
    /// </summary>
    public class PalettePanel : BuffPanel
    {
        public Color[] Swatches;
        public int Columns = 1;
        public int SelectedIndex = -1;
        public event Action<Color> Pick;

        ToolTip _tip = new ToolTip();

        public PalettePanel()
        {
            // 露出来的 1 像素背景色就是格子线
            BackColor = Color.FromArgb(226, 230, 236);
            _tip.InitialDelay = 250;
        }

        int Rows
        {
            get
            {
                if (Swatches == null || Swatches.Length == 0) return 1;
                return Math.Max(1, (Swatches.Length + Columns - 1) / Columns);
            }
        }
        int CellW { get { return Math.Max(1, ClientSize.Width / Math.Max(1, Columns)); } }
        int CellH { get { return Math.Max(1, ClientSize.Height / Rows); } }

        int IndexAt(int x, int y)
        {
            if (Swatches == null || Swatches.Length == 0) return -1;
            int c = x / CellW, r = y / CellH;
            if (c < 0 || c >= Columns || r < 0 || r >= Rows) return -1;
            int i = r * Columns + c;
            return (i >= 0 && i < Swatches.Length) ? i : -1;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if (Swatches == null) return;
            int cw = CellW, ch = CellH;
            for (int i = 0; i < Swatches.Length; i++)
            {
                int r = i / Columns, c = i % Columns;
                int x = c * cw + 1, y = r * ch + 1;
                int w = Math.Min(cw - 2, ClientSize.Width - x);
                int h = Math.Min(ch - 2, ClientSize.Height - y);
                if (w <= 2 || h <= 2) continue;
                w -= 1; h -= 1;
                using (SolidBrush br = new SolidBrush(Swatches[i]))
                    e.Graphics.FillRectangle(br, x, y, w, h);
                if (i == SelectedIndex && w > 3 && h > 3)
                {
                    e.Graphics.DrawRectangle(Pens.Black, x, y, w - 1, h - 1);
                    e.Graphics.DrawRectangle(Pens.White, x + 1, y + 1, w - 3, h - 3);
                }
            }
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            int i = IndexAt(e.X, e.Y);
            if (i < 0) return;
            SelectedIndex = i;
            Invalidate();
            if (Pick != null) Pick(Swatches[i]);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            int i = IndexAt(e.X, e.Y);
            if (i < 0) { _tip.SetToolTip(this, "点一个色块即可改键盘背光颜色"); return; }
            Color c = Swatches[i];
            _tip.SetToolTip(this, string.Format(CultureInfo.InvariantCulture,
                "RGB({0}, {1}, {2})  —  点击应用", c.R, c.G, c.B));
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && _tip != null) { _tip.Dispose(); _tip = null; }
            base.Dispose(disposing);
        }
    }

    /// <summary>
    /// 界面缩放设置的持久化。
    ///
    /// 档位只保留 **80% ~ 100%**（步进 5）。设计尺寸本身就是"按内容量出来的"，
    /// 再往上放大只是把同样的内容摊开，收益不大，所以 105% 以上的档位已经砍掉；
    /// 之前存在 105% 及以上的配置会在读取时自动收到 100%。
    ///
    /// MaxForScreen() 仍然保留：窗口总高 = 设计客户区高 × 系数 × 系统DPI/96 + 边框，
    /// 在矮屏幕上继续按可用高度往下收，避免底部被切掉。
    /// </summary>
    public static class UiScaleStore
    {
        public const int Min = 80;
        public const int HardMax = 100;   // 档位上限：不再提供 >100% 的放大
        public const int Step = 5;
        public const int Fallback = 100;  // 没有配置文件时用最大档

        // 100% 时的设计客户区高度（分页改版从 900x1197 降到 1092x576）。
        // 屏幕高度早就不是瓶颈了，这里仍参与反算，用于矮屏幕自动收档。
        const int BaseClientH = 576;
        const int ChromeH = 56;         // 标题栏 + 边框

        public static string FilePath() { return Path.Combine(Log.Dir(), "uiscale.txt"); }

        /// <summary>
        /// 系统 DPI / 96。
        ///
        /// 窗口和布局都是按**物理像素**排的，而字体是按**点**给的 —— 点会在当前 DPI 下
        /// 换算成像素。150% DPI（144dpi）下 9pt 的行高是 25px，而按 96dpi 设计的
        /// S(20) 只有 21px：字比框还高，上下直接被切掉。把 DPI 也乘进布局系数，
        /// 两边才会同步放大。
        /// </summary>
        public static float DpiK()
        {
            try
            {
                using (Graphics g = Graphics.FromHwnd(IntPtr.Zero)) return g.DpiY / 96f;
            }
            catch { return 1f; }
        }

        public static int MaxForScreen()
        {
            int avail;
            float k = DpiK();
            try { avail = Screen.PrimaryScreen.WorkingArea.Height - (int)Math.Round(ChromeH * k) - 8; }
            catch { return HardMax; }
            int pct = (int)Math.Floor(avail * 100.0 / (BaseClientH * k));
            if (pct > HardMax) pct = HardMax;
            if (pct < Min) pct = Min;
            return pct;
        }

        public static int Clamp(int pct)
        {
            int hi = MaxForScreen();
            if (pct > hi) pct = hi;
            if (pct < Min) pct = Min;
            return pct;
        }

        public static int Load()
        {
            try
            {
                string p = FilePath();
                if (File.Exists(p))
                {
                    int v;
                    if (int.TryParse(File.ReadAllText(p).Trim(), NumberStyles.Integer,
                                     CultureInfo.InvariantCulture, out v))
                        return Clamp(v);
                }
            }
            catch { }
            return Clamp(Fallback);
        }

        public static void Save(int pct)
        {
            try { File.WriteAllText(FilePath(), pct.ToString(CultureInfo.InvariantCulture)); }
            catch { }
        }

        public static string[] Options()
        {
            List<string> l = new List<string>();
            int hi = MaxForScreen();
            for (int p = Min; p <= hi; p += Step) l.Add(p + "%");
            string top = hi + "%";
            if (l.Count == 0 || l[l.Count - 1] != top) l.Add(top);   // 上限按屏幕算，未必是整档
            return l.ToArray();
        }

        public static string Label(int pct) { return pct + "%"; }

        public static int PercentOf(string s)
        {
            if (string.IsNullOrEmpty(s)) return -1;
            int v;
            return int.TryParse(s.TrimEnd('%'), NumberStyles.Integer, CultureInfo.InvariantCulture, out v) ? v : -1;
        }
    }

    public class MainForm : Form
    {
        // ---- data plumbing ----
        readonly object _lock = new object();
        Snapshot _snap = new Snapshot();
        Thread _thread;
        volatile bool _stop;
        // 风扇读数由后台线程取好后放这里，UI 线程只读它 —— EC 是内核 IOCTL，
        // 放在 UI 线程上读，驱动一旦卡住整个窗口就会"未响应"（实测发生过一次）。
        Ec.FanReadout _fanSnap;
        readonly List<double> _history = new List<double>();
        const int HistoryMax = 180;

        // ---- ui ----
        // 只用两个大卡片：上面「系统监控」全部只读，下面「操作面板」容纳所有可
        // 操作项。原先操作项散落在三个互不相邻的分组里（场景与风扇 / 温度保护 /
        // 详细设置），视线要来回跳；风扇转速这种监控值还被塞进了操作区。
        GroupBox gbMonitor, gbControl;
        Panel pnlZones, pnlGraph, pnlCores, pnlMem;
        Panel sep1, sep2;
        Label lblThrottle, lblCpu, lblMem, lblPresetDesc, lblMaxVal, lblMinVal, lblMaxTitle, lblMinTitle;
        Label lblCoreLegend;
        Label lblGuardStatus, lblFan, lblWallStatus;
        Label lblSec1, lblSec2, lblSec3;
        Button btnPerf, btnBalanced, btnQuiet, btnFanBoost, btnApply, btnElevate, btnHotkey;
        Button btnMin0, btnMin5, btnMin50, btnMin100;
        CheckBox chkTurbo, chkAutoStart, chkGuard, chkWall, chkWallBoost, chkWallTurbo;
        NumericUpDown numTrigger, numRelease, numLimit, numWallTarget, numMax, numMin;

        // ---- 键盘背光颜色 ----
        Panel sep3;
        Label lblSec4, lblLightStatus;
        Button btnSwatch, btnLightDefault;
        PalettePanel paletteLight;
        CheckBox chkLightRemember;
        CheckBox chkHwRainbow;
        CheckBox chkBlink;
        ComboBox cmbBlinkRate;
        System.Windows.Forms.Timer _blinkTimer;
        double _blinkPhase;                      // 0..1，一个完整明暗来回
        DateTime _blinkLast;
        int _blinkRate = 1;                      // 0 慢 / 1 中 / 2 快
        int _lightR = -1, _lightG = -1, _lightB = -1;
        const int LightPaletteCols = 35;   // 两排 35 格 = 70 个颜色
        bool _syncMax, _syncMin;        // 滑块 ↔ 数值框双向同步的重入保护
        ThermalWallConfig _wallCfg = new ThermalWallConfig();
        FanCurveConfig _fanCfg = new FanCurveConfig();
        bool _fanLoading;                  // 用代码回填界面时的重入保护

        // ---- 风扇曲线页 ----
        GroupBox gbFan;
        Label lblSecFan, lblFanStatus, lblFanSafety;
        CheckBox chkFanCurve;
        NumericUpDown numFanHys;
        FanCurvePanel pnlFanCurve;
        Button btnFanApply;
        int _wallApplied = -1;          // 温度墙当前下发的处理器上限（-1 = 未接管）
        int _wallBaseState = -1;        // 用户设定的处理器上限（温度墙要收敛回去的目标）
        bool _wallActive;               // 温度墙是否正在压制
        bool _wallTurboDropped;         // 睿频是否由温度墙关闭
        bool _wallBoostByWall;          // 强冷是否由温度墙开启
        ThermalGuardConfig _guardCfg = new ThermalGuardConfig();
        bool _guardActive;
        bool _guardBlocked;
        PowerState _guardSaved;
        ToolStripMenuItem _trayAuto;
        ToolStripMenuItem _trayFanBoost;
        HotkeyManager _hotkeys;
        HotkeyStore.Config _hotkeyCfg = new HotkeyStore.Config();
        ComboBox cmbMode, cmbCool;
        TrackBar tbMax, tbMin;
        StatusStrip status;
        ToolStripStatusLabel stStatus, stElev, stAuto, stHot;
        NotifyIcon _tray;
        System.Windows.Forms.Timer _timer;
        System.Windows.Forms.Timer _lightTimer;
        bool _startHidden;
        bool _skipTray;
        int _normalW, _normalH;         // last size while not maximized
        bool _restoringState;
        bool _reallyExit;
        bool _loading;
        string _lastPreset = "";

        // 界面缩放：_uiPct 是用户设定（百分比），字体与实际尺寸都按它算
        int _uiPct = UiScaleStore.Load();
        // 静态：嵌套类 FanCurvePanel 要拿它画坐标轴文字（嵌套类没有外层实例）
        static Font fTitle, fBig, fNormal, fSmall, fSect;
        ComboBox cmbScale;

        // ---- 分页外壳 ----
        // 单页版把所有东西塞进一张 1197px 高的长卡片，窗口只能往下长，屏幕矮一点
        // 底部就被切掉。改成分页后每页各自成篇、窗口高度减半，而且以后加功能也不
        // 会再把窗口顶高。导航在左、内容在右，Ctrl+Tab / Ctrl+1..5 切页。
        Panel pnlNav, pnlBody, pnlNavMark;
        Label lblNavFoot;
        Font fMark;                       // 页名水印用的字号
        readonly List<Panel> _pages = new List<Panel>();
        readonly List<Label> _marks = new List<Label>();   // 各页右下角的页名水印
        readonly List<Button> _navBtns = new List<Button>();
        readonly List<string> _pageTitles = new List<string>();
        readonly List<string> _pageSubs = new List<string>();
        int _page;                        // 当前页序号
        GroupBox gbThermal, gbLight, gbSystem;
        Label lblSec5, lblSec6, lblSec7, lblSec8, lblSec9;
        Button btnOpenLog;
        static readonly Color CAccentSoft = Color.FromArgb(232, 242, 252);
        static readonly Color CMark = Color.FromArgb(222, 228, 237);   // 页名水印（低对比）

        static readonly Color CBack = Color.FromArgb(250, 250, 252);
        static readonly Color CCard = Color.White;
        static readonly Color CLine = Color.FromArgb(226, 230, 236);
        static readonly Color CText = Color.FromArgb(32, 36, 44);
        static readonly Color CSub = Color.FromArgb(120, 128, 140);
        static readonly Color CAccent = Color.FromArgb(0, 120, 212);
        static readonly Color CGreen = Color.FromArgb(16, 137, 62);
        static readonly Color CWarn = Color.FromArgb(196, 108, 0);
        static readonly Color CDanger = Color.FromArgb(196, 43, 28);

        public MainForm(bool startHidden) : this(startHidden, false, false) { }
        public MainForm(bool startHidden, bool skipTray) : this(startHidden, skipTray, false) { }

        /// <summary>
        /// skipLoad = 不挂 Load 事件。给 --uishot 用：它要把窗口真的 Show 出来
        /// （没显示过的窗口 DrawToBitmap 只会得到一张空白图），但又绝不能触发
        /// OnLoaded 里的传感器初始化、托盘、全局快捷键和温控线程。
        /// </summary>
        public MainForm(bool startHidden, bool skipTray, bool skipLoad)
        {
            _startHidden = startHidden;
            _skipTray = skipTray;
            BuildUi();
            if (!skipTray) BuildTray();
            if (!skipLoad) Load += OnLoaded;
            FormClosing += OnClosing;
        }

        // ------------------------------------------------------------- layout

        void BuildUi()
        {
            _sPct = _uiPct;
            _dpiK = UiScaleStore.DpiK();
            ApplyScaledFonts();
            Text = "系统控制台  —  机械革命 GM6AR57C";

            // 窗口图标也用原厂素材（拿不到就算了，不致命）
            try
            {
                Icon ic = Assets.GetIcon("Square150x150Logo.scale-200.png", 32);
                if (ic != null) Icon = ic;
            }
            catch { }
            // 先放开 MinimumSize 再设 ClientSize：切换缩放重建时，上一档的最小尺寸
            // 还卡在那里，直接设更小的 ClientSize 会被它顶回去。
            MinimumSize = new Size(0, 0);
            // 分页版的设计尺寸：宽 1092 = 导航 184 + 内容 908；高 640 只够一页，
            // 不用再为"所有分区同时可见"留出 1197px。
            // 高度 576 = 原来的 640 减去顶部那条 64px 标题栏（页名改成右下角水印）
            ClientSize = new Size(S(1092), S(576));
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = CBack;
            Font = fNormal;
            // 缩放全部由 S()/Sf() 手工完成，必须关掉 WinForms 自带的字体自动缩放。
            AutoScaleMode = AutoScaleMode.None;
            DoubleBuffered = true;

            _pages.Clear(); _navBtns.Clear(); _pageTitles.Clear(); _pageSubs.Clear(); _marks.Clear();
            _page = 0;

            // ============================================================
            //  分页式外壳
            //    左：导航栏（LOGO + 页签 + 页脚机型）
            //    右：页面容器（卡片 + 右下角页名水印）
            //    底：状态栏（全局四段，和以前一样）
            //
            //  页名不再占一条独立的标题栏：那块 64px 的白色横幅撤掉，页名改成
            //  右下角的低对比水印，正好落在卡片下方原本空着的区域里。窗口因此矮了
            //  64 设计像素，而页体高度不变（550），所有页面坐标都不用动。
            //
            //  尺寸约定（设计像素，全部过 S()）：
            //    窗口 1092 = 导航 184 + 内容 908
            //    页面内卡片 x=16 宽 876  →  卡片内容区 x=14 宽 848，
            //    与改版前两张卡片的内宽一模一样，所以各页原来的坐标可以整体照搬，
            //    不用重新量一遍文字宽度。
            // ============================================================

            // ---------------- 状态栏（先建：页体高度要扣掉它） ----------------
            status = new StatusStrip();
            status.SizingGrip = false;
            status.AutoSize = false;          // 高度写死，页体的下边距才可预期
            status.Height = S(26);
            stStatus = new ToolStripStatusLabel("正在启动…");
            stAuto = new ToolStripStatusLabel("");
            stHot = new ToolStripStatusLabel("");
            stElev = new ToolStripStatusLabel("");
            stStatus.Spring = true;
            stStatus.TextAlign = ContentAlignment.MiddleLeft;
            status.Items.Add(stStatus);
            status.Items.Add(stAuto);
            status.Items.Add(stHot);
            status.Items.Add(stElev);
            Controls.Add(status);

            int navW = S(184);
            int statusH = status.Height;

            // ---------------- 导航栏 ----------------
            pnlNav = new Panel();
            pnlNav.Name = "pnlNav";
            pnlNav.BackColor = Color.White;
            pnlNav.Bounds = new Rectangle(0, 0, navW, ClientSize.Height - statusH);
            pnlNav.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            Controls.Add(pnlNav);

            PictureBox logo = new PictureBox();
            Image logoImg = Assets.GetSized("LOGO.png", S(24), S(24));
            if (logoImg != null)
            {
                logo.Image = logoImg;
                logo.SizeMode = PictureBoxSizeMode.Zoom;
                logo.BackColor = Color.Transparent;
                logo.Bounds = new Rectangle(S(16), S(18), S(24), S(24));
                pnlNav.Controls.Add(logo);
            }

            Label lblBrand = new Label();
            lblBrand.Text = "系统控制台";
            lblBrand.Font = fSect;
            lblBrand.ForeColor = CText;
            lblBrand.AutoSize = false;
            lblBrand.Bounds = new Rectangle(S(48), S(20), navW - S(60), S(22));
            lblBrand.TextAlign = ContentAlignment.MiddleLeft;
            lblBrand.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            pnlNav.Controls.Add(lblBrand);

            // 左边缘的选中指示条：一页一根，跟着当前页上下走
            pnlNavMark = new Panel();
            pnlNavMark.Name = "pnlNavMark";
            pnlNavMark.BackColor = CAccent;
            pnlNavMark.Bounds = new Rectangle(0, S(72), S(3), S(40));
            pnlNavMark.Visible = false;
            pnlNav.Controls.Add(pnlNavMark);

            // 导航栏右侧那条一像素分隔线
            Panel navLine = new Panel();
            navLine.BackColor = CLine;
            navLine.Bounds = new Rectangle(navW - S(1), 0, S(1), pnlNav.Height);
            navLine.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            pnlNav.Controls.Add(navLine);

            lblNavFoot = new Label();
            lblNavFoot.Text = "GM6AR57C · v1.0";
            lblNavFoot.Font = fSmall;
            lblNavFoot.ForeColor = CSub;
            lblNavFoot.AutoSize = false;
            lblNavFoot.Bounds = new Rectangle(S(16), pnlNav.Height - S(30), navW - S(32), S(20));
            lblNavFoot.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lblNavFoot.TextAlign = ContentAlignment.MiddleLeft;
            pnlNav.Controls.Add(lblNavFoot);

            // ---------------- 页面容器 ----------------
            // （页名水印在五页都建好之后由 AddPageMark 统一添加，挂在各页右下角）
            pnlBody = new Panel();
            pnlBody.Name = "pnlBody";
            pnlBody.BackColor = CBack;
            pnlBody.Bounds = new Rectangle(navW, 0, ClientSize.Width - navW, ClientSize.Height - statusH);
            pnlBody.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Controls.Add(pnlBody);

            int bodyH = pnlBody.Height;

            // ============================================================
            //  第 1 页：系统概览（全部只读）
            // ============================================================
            Panel pageDash = MakePage("系统概览", "温度、频率、内存与风扇的实时读数（全部只读）", "ico-CPU-n.png");

            gbMonitor = MakeGroup("系统监控（只读）", S(16), S(12), S(876), bodyH - S(24));
            pageDash.Controls.Add(gbMonitor);

            pnlZones = MakePanel(S(14), S(32), S(852), S(86));
            pnlZones.Paint += PaintZones;
            lblThrottle = MakeLabel("节流状态: --", S(16), S(128), S(848), S(20), fNormal, CSub);
            // 风扇转速是监控数据，和温度放在一起看
            lblFan = MakeLabel("", S(16), S(158), S(848), S(20), fNormal, CAccent);
            pnlGraph = MakePanel(S(14), S(188), S(852), S(130));
            pnlGraph.Paint += PaintGraph;
            // 初始文字取最宽的取值，好让无界面自检按最坏情况量一次 ——
            // 这行是运行时刷新的，空字符串起不到校验作用。
            lblCpu = MakeLabel("处理器总占用: 100.0%      相对基准性能: 999%      报告频率: 9999 MHz      逻辑核心: 99",
                               S(16), S(320), S(848), S(22), fNormal, CText);
            pnlCores = MakePanel(S(14), S(350), S(848), S(58));
            pnlCores.Paint += PaintCores;
            // 逐核图例挂在柱状图自己身上、占顶上一条，柱子从它下面开始画。
            string coreLegend = "蓝 = P 核 (0-15)    紫 = E 核 (16-23)";
            int legendW = TextW(coreLegend, fSmall) + 8;
            lblCoreLegend = MakeLabel(coreLegend, S(848) - legendW - S(6), S(1), legendW, S(17), fSmall, CSub);
            lblCoreLegend.TextAlign = ContentAlignment.MiddleRight;
            lblCoreLegend.Name = "lblCoreLegend";
            pnlCores.Controls.Add(lblCoreLegend);
            lblMem = MakeLabel("内存: --", S(16), S(418), S(848), S(20), fNormal, CText);
            pnlMem = MakePanel(S(14), S(446), S(848), S(14));
            pnlMem.Paint += PaintMem;

            gbMonitor.Controls.Add(pnlZones);
            gbMonitor.Controls.Add(lblThrottle);
            gbMonitor.Controls.Add(lblFan);
            gbMonitor.Controls.Add(pnlGraph);
            gbMonitor.Controls.Add(lblCpu);
            gbMonitor.Controls.Add(pnlCores);
            gbMonitor.Controls.Add(lblMem);
            gbMonitor.Controls.Add(pnlMem);

            // 监控卡片同时锚 Top+Bottom：曲线图吸收全部纵向余量，卡片长高的部分
            // 全给曲线图；下面三行贴底锚定，跟着一起下移，间距恒定。
            gbMonitor.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            pnlZones.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblThrottle.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblFan.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            pnlGraph.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lblCpu.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lblCoreLegend.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pnlCores.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lblMem.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            pnlMem.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;

            // ============================================================
            //  第 2 页：性能与散热（场景档位 + 精细控制）
            // ============================================================
            Panel pagePerf = MakePage("性能与散热", "场景档位、处理器频率上下限与散热策略", "ico-turbo.png");

            gbControl = MakeGroup("性能与散热", S(16), S(12), S(876), S(460));
            pagePerf.Controls.Add(gbControl);

            // ---- 分区 1：场景与风扇 ----
            lblSec1 = MakeLabel("场景与风扇", S(38), S(30), S(278), S(18), fSect, CText);
            SectionIcon(gbControl, "ico-gaming.png", S(31));
            gbControl.Controls.Add(lblSec1);

            btnPerf = MakeButton("性能模式", S(16), S(56), S(190), S(36), "ico-turbo.png");
            btnBalanced = MakeButton("均衡模式", S(228), S(56), S(190), S(36), "ico-balance.png");
            btnQuiet = MakeButton("静音模式", S(440), S(56), S(190), S(36), "ico-ofice.png");
            btnFanBoost = MakeButton("一键强冷", S(652), S(56), S(190), S(36), "ico-gaming.png");
            btnPerf.Click += delegate { ApplyPresetByKey("performance"); };
            btnBalanced.Click += delegate { ApplyPresetByKey("balanced"); };
            btnQuiet.Click += delegate { ApplyPresetByKey("quiet"); };
            btnFanBoost.Click += OnFanBoostClick;
            lblPresetDesc = MakeLabel("", S(16), S(104), S(848), S(18), fSmall, CSub);
            lblPresetDesc.Name = "lblPresetDesc";

            gbControl.Controls.Add(btnPerf);
            gbControl.Controls.Add(btnBalanced);
            gbControl.Controls.Add(btnQuiet);
            gbControl.Controls.Add(btnFanBoost);
            gbControl.Controls.Add(lblPresetDesc);

            sep1 = MakeSeparator(S(14), S(134), S(848));
            gbControl.Controls.Add(sep1);

            // ---- 分区 2：精细控制 ----
            lblSec3 = MakeLabel("精细控制", S(38), S(148), S(108), S(18), fSect, CText);
            SectionIcon(gbControl, "ico-turbo.png", S(151));
            gbControl.Controls.Add(lblSec3);

            Label lHint = MakeLabel("最小处理器状态 = CPU 频率下限：0% 最凉省电，100% 锁高频最热",
                                    S(190), S(148), S(670), S(18), fSmall, CSub);
            lHint.TextAlign = ContentAlignment.MiddleRight;
            lHint.Name = "lHint";
            gbControl.Controls.Add(lHint);

            // ---- 第 1 行：睿频 / 电源模式 / 散热策略 ----
            Row r1 = new Row(gbControl, S(16), S(184));
            chkTurbo = AutoCheck("睿频加速", fNormal);
            chkTurbo.CheckedChanged += delegate { UpdatePresetLabel(); };
            r1.Add(chkTurbo, S(22));

            Label lm = AutoLabel("电源模式", fNormal, CText);
            r1.Add(lm, S(10));
            cmbMode = AutoCombo(fNormal, new string[] { "平衡", "最佳性能", "最佳能效" });
            r1.Add(cmbMode, S(28));

            Label lc = AutoLabel("散热策略", fNormal, CText);
            r1.Add(lc, S(10));
            cmbCool = AutoCombo(fNormal, new string[] { "被动（先降频）", "主动（先加速风扇）" });
            r1.Add(cmbCool, 0);

            // ---- 第 2 行：最大处理器状态 ----
            lblMaxTitle = AutoLabel("最大处理器状态", fNormal, CText);
            lblMaxTitle.Top = S(230); lblMaxTitle.Left = S(16);
            gbControl.Controls.Add(lblMaxTitle);

            tbMax = new TrackBar();
            tbMax.Minimum = 5; tbMax.Maximum = 100;
            // 关掉刻度线：默认刻度会把 TrackBar 撑到 69px 高，视觉上压到下一行；
            // 精确值交给右边可以直接键入的数值框，滑块只负责快速拖动。
            tbMax.AutoSize = false;
            tbMax.TickStyle = TickStyle.None;
            tbMax.TickFrequency = 1;
            // 滑块从 134 挪到 168：标签实测宽约 153px，左端 134 会压住"最大处理器
            // 状态"这行字（旧版就已经压着，只是隐藏窗口里查不出来）。右端保持 754。
            tbMax.Top = S(226); tbMax.Left = S(168); tbMax.Size = new Size(S(586), S(32));
            tbMax.ValueChanged += delegate
            {
                // 用户改了上限 → 这就是新的基线，温度墙把控制权交还给他重新收敛
                if (!_loading)
                {
                    _wallBaseState = tbMax.Value;
                    if (_wallCfg.Enabled && _wallCfg.BaseState != tbMax.Value)
                    {
                        _wallCfg.BaseState = tbMax.Value;
                        WallStore.Save(_wallCfg);
                    }
                    if (_wallApplied > 0) { _wallApplied = -1; _wallActive = false; }
                }
                // 拖动滑块 → 数值框跟随（_syncMax 防止两边互相触发）
                if (!_syncMax && numMax != null && numMax.Value != tbMax.Value)
                {
                    _syncMax = true;
                    try { numMax.Value = Clamp(tbMax.Value, (int)numMax.Minimum, (int)numMax.Maximum); }
                    finally { _syncMax = false; }
                }
                UpdatePresetLabel();
            };
            gbControl.Controls.Add(tbMax);

            numMax = AutoNum(fNormal, tbMax.Minimum, tbMax.Maximum, 100);
            numMax.Top = S(228); numMax.Left = S(762); numMax.Width = S(60);
            numMax.ValueChanged += delegate
            {
                if (_syncMax) return;
                _syncMax = true;
                try { tbMax.Value = Clamp((int)numMax.Value, tbMax.Minimum, tbMax.Maximum); }
                finally { _syncMax = false; }
            };
            gbControl.Controls.Add(numMax);

            lblMaxVal = AutoLabel("%", fNormal, CSub);
            lblMaxVal.Top = S(230); lblMaxVal.Left = S(830); lblMaxVal.Width = S(38);
            gbControl.Controls.Add(lblMaxVal);

            // ---- 第 3 行：最小处理器状态（与上一行结构完全一致） ----
            lblMinTitle = AutoLabel("最小处理器状态", fNormal, CText);
            lblMinTitle.Top = S(274); lblMinTitle.Left = S(16);
            gbControl.Controls.Add(lblMinTitle);

            tbMin = new TrackBar();
            tbMin.Minimum = 0; tbMin.Maximum = 100;
            tbMin.AutoSize = false;
            tbMin.TickStyle = TickStyle.None;
            tbMin.TickFrequency = 1;
            tbMin.Top = S(270); tbMin.Left = S(168); tbMin.Size = new Size(S(586), S(32));
            tbMin.ValueChanged += delegate
            {
                if (!_syncMin && numMin != null && numMin.Value != tbMin.Value)
                {
                    _syncMin = true;
                    try { numMin.Value = Clamp(tbMin.Value, (int)numMin.Minimum, (int)numMin.Maximum); }
                    finally { _syncMin = false; }
                }
                UpdatePresetLabel();
            };
            gbControl.Controls.Add(tbMin);

            numMin = AutoNum(fNormal, tbMin.Minimum, tbMin.Maximum, 5);
            numMin.Top = S(272); numMin.Left = S(762); numMin.Width = S(60);
            numMin.ValueChanged += delegate
            {
                if (_syncMin) return;
                _syncMin = true;
                try { tbMin.Value = Clamp((int)numMin.Value, tbMin.Minimum, tbMin.Maximum); }
                finally { _syncMin = false; }
            };
            gbControl.Controls.Add(numMin);

            lblMinVal = AutoLabel("%", fNormal, CSub);
            lblMinVal.Top = S(274); lblMinVal.Left = S(830); lblMinVal.Width = S(38);
            gbControl.Controls.Add(lblMinVal);

            // ---- 第 4 行：最小状态的常用档位 ----
            // 0-100 之间慢慢拖很别扭，这四个档位覆盖了实际会用到的全部取值。
            // 点一下立即写入，不必再按「应用设置」。
            Label lq = AutoLabel("常用档位（立即生效）", fSmall, CSub);
            lq.Top = S(320); lq.Left = S(16);
            gbControl.Controls.Add(lq);

            btnMin0 = MakeButton("0%　允许深度降频", S(16), S(346), S(196), S(30));
            btnMin5 = MakeButton("5%　默认均衡", S(232), S(346), S(196), S(30));
            btnMin50 = MakeButton("50%　保底中频", S(448), S(346), S(196), S(30));
            btnMin100 = MakeButton("100%　锁定最高频", S(664), S(346), S(196), S(30));
            btnMin0.Font = fSmall; btnMin5.Font = fSmall;
            btnMin50.Font = fSmall; btnMin100.Font = fSmall;
            btnMin0.Click += delegate { SetMinQuick(0); };
            btnMin5.Click += delegate { SetMinQuick(5); };
            btnMin50.Click += delegate { SetMinQuick(50); };
            btnMin100.Click += delegate { SetMinQuick(100); };
            gbControl.Controls.Add(btnMin0);
            gbControl.Controls.Add(btnMin5);
            gbControl.Controls.Add(btnMin50);
            gbControl.Controls.Add(btnMin100);

            sep2 = MakeSeparator(S(14), S(396), S(848));
            gbControl.Controls.Add(sep2);

            // ---- 第 5 行：应用（唯一的落盘按钮，右对齐） ----
            btnApply = MakeButton("应用设置", S(710), S(414), S(150), S(32));
            btnApply.Click += OnApplyClick;
            gbControl.Controls.Add(btnApply);

            gbControl.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblSec1.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            lblSec3.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            lblPresetDesc.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lHint.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            sep1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            sep2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            tbMax.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            tbMin.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            numMax.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            numMin.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            lblMaxVal.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            lblMinVal.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnApply.Anchor = AnchorStyles.Top | AnchorStyles.Right;

            // ============================================================
            //  第 3 页：温度保护（温度墙闭环 + 超温保护兜底）
            // ============================================================
            Panel pageThermal = MakePage("温度保护", "温度墙做日常收敛，超温保护做最后一道硬保险", "ico-balance.png");

            gbThermal = MakeGroup("温度保护", S(16), S(12), S(876), S(302));
            pageThermal.Controls.Add(gbThermal);

            // 温度墙 = 闭环连续控制：把"最高温度"当目标，按偏差逐步加减处理器上限，
            //          让温度收敛在目标附近，而不是撞上去再退回来。
            lblSec2 = MakeLabel("温度墙（闭环收敛）", S(38), S(30), S(300), S(18), fSect, CText);
            SectionIcon(gbThermal, "ico-balance.png", S(33));
            gbThermal.Controls.Add(lblSec2);

            Row rw = new Row(gbThermal, S(16), S(64));
            chkWall = AutoCheck("温度墙", fNormal);
            chkWall.CheckedChanged += OnWallEnableChanged;
            rw.Add(chkWall, S(22));

            Label wtLbl = AutoLabel("目标", fNormal, CText);
            rw.Add(wtLbl, S(10));
            numWallTarget = AutoNum(fNormal, S(50), S(100), S(85));
            numWallTarget.ValueChanged += OnWallValueChanged;
            rw.Add(numWallTarget, S(10));
            Label wtUnit = AutoLabel("°C", fNormal, CSub);
            rw.Add(wtUnit, S(26));

            chkWallTurbo = AutoCheck("明显超温时关睿频", fNormal);
            chkWallTurbo.CheckedChanged += OnWallValueChanged;
            rw.Add(chkWallTurbo, S(26));

            chkWallBoost = AutoCheck("接近时自动开强冷", fNormal);
            chkWallBoost.CheckedChanged += OnWallValueChanged;
            rw.Add(chkWallBoost, 0);

            lblWallStatus = MakeLabel("", S(16), S(104), S(848), S(18), fSmall, CSub);
            lblWallStatus.Name = "lblWallStatus";
            gbThermal.Controls.Add(lblWallStatus);

            Label lWallHint = MakeLabel("温度墙把最高温度当目标，按偏差逐步加减处理器上限，让温度收敛在目标附近。",
                                        S(16), S(130), S(848), S(18), fSmall, CSub);
            gbThermal.Controls.Add(lWallHint);

            Panel sepWall = MakeSeparator(S(14), S(162), S(848));
            sepWall.Name = "sepWall";
            gbThermal.Controls.Add(sepWall);

            // 超温保护 = 二元兜底：越过触发点才一次性限功耗，回落到解除温度才恢复。
            // 两者可叠加：温度墙管日常收敛，超温保护管最后的硬保险。
            lblSec5 = MakeLabel("超温保护（硬兜底）", S(38), S(180), S(300), S(18), fSect, CText);
            SectionIcon(gbThermal, "ico-SM-n.png", S(183));
            gbThermal.Controls.Add(lblSec5);

            Row rg = new Row(gbThermal, S(16), S(214));
            chkGuard = AutoCheck("超温保护", fNormal);
            chkGuard.CheckedChanged += OnGuardEnableChanged;
            rg.Add(chkGuard, S(20));

            Label gtLbl = AutoLabel("触发", fNormal, CText);
            rg.Add(gtLbl, S(10));
            numTrigger = AutoNum(fNormal, S(55), S(105), S(88));
            numTrigger.ValueChanged += OnGuardValueChanged;
            rg.Add(numTrigger, S(10));
            Label gtUnit = AutoLabel("°C", fNormal, CSub);
            rg.Add(gtUnit, S(16));

            Label grLbl = AutoLabel("解除", fNormal, CText);
            rg.Add(grLbl, S(10));
            numRelease = AutoNum(fNormal, S(50), S(100), S(78));
            numRelease.ValueChanged += OnGuardValueChanged;
            rg.Add(numRelease, S(10));
            Label grUnit = AutoLabel("°C", fNormal, CSub);
            rg.Add(grUnit, S(16));

            Label glLbl = AutoLabel("限功耗至", fNormal, CText);
            rg.Add(glLbl, S(10));
            numLimit = AutoNum(fNormal, S(20), S(100), S(60));
            numLimit.ValueChanged += OnGuardValueChanged;
            rg.Add(numLimit, S(10));
            Label glUnit = AutoLabel("% 上限", fNormal, CSub);
            rg.Add(glUnit, 0);

            // 两路各有一条状态行：以前共用一个 Label，谁后刷新谁覆盖，读不出是谁在动。
            lblGuardStatus = MakeLabel("", S(16), S(252), S(848), S(18), fSmall, CSub);
            lblGuardStatus.Name = "lblGuardStatus";
            gbThermal.Controls.Add(lblGuardStatus);

            Label lGuardHint = MakeLabel("越过触发点才一次性限功耗，回落到解除温度才恢复；与温度墙可叠加，是最后一道保险。",
                                         S(16), S(278), S(848), S(18), fSmall, CSub);
            gbThermal.Controls.Add(lGuardHint);

            gbThermal.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblSec2.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            lblSec5.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            lblWallStatus.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblGuardStatus.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lWallHint.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lGuardHint.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            sepWall.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

            // ============================================================
            //  第 4 页：键盘背光
            // ============================================================
            Panel pageLight = MakePage("键盘背光", "颜色、灯效与恢复出厂色", "ico-KB-n.png");

            gbLight = MakeGroup("键盘背光", S(16), S(12), S(876), S(284));
            pageLight.Controls.Add(gbLight);

            // 颜色协议从原厂 DefaultTool.exe 反汇编还原并实测通过：
            //   写 0x769/0x76A/0x76B 三个"电平"，再把 0x767 的 bit5 置 1 提交。
            // 电平有效范围 1..50，所以界面上给的是常规 0..255 RGB，内部按原厂
            // 公式换算（R/5、G/6、B/6，夹到 1..50）。
            lblSec4 = MakeLabel("颜色", S(38), S(30), S(154), S(18), fSect, CText);
            SectionIcon(gbLight, "ico-LED-n.png", S(33));
            lblSec4.Name = "lblSec4";
            gbLight.Controls.Add(lblSec4);

            // 状态文字用最宽的取值当初始值：无界面自检会照这个宽度校验有没有被裁。
            lblLightStatus = MakeLabel("当前 50/50/50 ≈ RGB(255,255,255)   出厂 50/50/50",
                                       S(16), S(62), S(848), S(16), fSmall, CSub);
            lblLightStatus.AutoEllipsis = true;
            lblLightStatus.Name = "lblLightStatus";
            gbLight.Controls.Add(lblLightStatus);

            chkLightRemember = AutoCheck("记住颜色", fSmall);
            chkLightRemember.Left = S(616); chkLightRemember.Top = S(31);
            chkLightRemember.Name = "chkLightRemember";
            chkLightRemember.CheckedChanged += OnLightRememberChanged;
            gbLight.Controls.Add(chkLightRemember);

            btnLightDefault = MakeButton("恢复出厂色", S(740), S(30), S(120), S(24));
            btnLightDefault.Font = fSmall;
            btnLightDefault.Name = "btnLightDefault";
            btnLightDefault.Click += OnLightDefaultClick;
            gbLight.Controls.Add(btnLightDefault);

            // 左边这块是"当前色"预览，点它打开系统取色器；右边的调色板一点即改。
            btnSwatch = new Button();
            btnSwatch.Left = S(16); btnSwatch.Top = S(94); btnSwatch.Width = S(64); btnSwatch.Height = S(38);
            btnSwatch.FlatStyle = FlatStyle.Flat;
            btnSwatch.FlatAppearance.BorderColor = CLine;
            btnSwatch.BackColor = CBack;
            btnSwatch.Text = "";
            btnSwatch.TabStop = false;
            btnSwatch.Name = "btnSwatch";
            btnSwatch.Click += OnSwatchClick;
            gbLight.Controls.Add(btnSwatch);

            paletteLight = new PalettePanel();
            paletteLight.Left = S(92); paletteLight.Top = S(94);
            paletteLight.Width = S(764); paletteLight.Height = S(38);
            paletteLight.Columns = LightPaletteCols;
            paletteLight.Swatches = BuildLightPalette(LightPaletteCols);
            paletteLight.Name = "paletteLight";
            paletteLight.Pick += delegate(Color c) { ApplyLight(c, chkLightRemember.Checked); };
            gbLight.Controls.Add(paletteLight);

            sep3 = MakeSeparator(S(14), S(154), S(848));
            sep3.Name = "sep3";
            gbLight.Controls.Add(sep3);

            // 只留 EC 固件自带的那一个硬件效果：写 0x767 的 bit7 就完事。
            // 它零 CPU 占用，而且本程序退出后仍然在跑。
            lblSec6 = MakeLabel("灯效", S(38), S(172), S(154), S(18), fSect, CText);
            SectionIcon(gbLight, "ico-gaming.png", S(175));
            gbLight.Controls.Add(lblSec6);

            Row rf = new Row(gbLight, S(16), S(204));
            chkHwRainbow = AutoCheck("硬件彩虹（由键盘固件驱动，关掉程序也在）", fNormal);
            chkHwRainbow.Name = "chkHwRainbow";
            chkHwRainbow.CheckedChanged += OnHwRainbowChanged;
            rf.Add(chkHwRainbow, S(20));

            // 闪烁只能软件做 —— 硬件那边 0x7C5 的闪烁只有四个固定颜色。
            chkBlink = AutoCheck("闪烁", fNormal);
            chkBlink.Name = "chkBlink";
            chkBlink.CheckedChanged += OnBlinkChanged;
            rf.Add(chkBlink, S(10));

            cmbBlinkRate = AutoCombo(fNormal, new string[] { "慢", "中", "快" });
            cmbBlinkRate.Name = "cmbBlinkRate";
            cmbBlinkRate.SelectedIndex = _blinkRate;
            cmbBlinkRate.SelectedIndexChanged += OnBlinkChanged;
            rf.Add(cmbBlinkRate, 0);

            Label lLightHint = MakeLabel("硬件彩虹由键盘固件驱动，程序退出后仍在跑，也不占 CPU；闪烁是软件按频率翻转电平。",
                                         S(16), S(244), S(848), S(18), fSmall, CSub);
            gbLight.Controls.Add(lLightHint);

            gbLight.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblSec4.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            lblSec6.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            lblLightStatus.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lLightHint.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            sep3.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            paletteLight.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            btnLightDefault.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            chkLightRemember.Anchor = AnchorStyles.Top | AnchorStyles.Right;

            // ============================================================
            //  第 5 页：系统与设置（启动 / 权限 / 缩放 / 诊断）
            // ============================================================
            Panel pageSys = MakePage("系统与设置", "开机自启、快捷键、界面缩放与诊断日志", "btn-menu-n.png");

            gbSystem = MakeGroup("系统与设置", S(16), S(12), S(876), S(356));
            pageSys.Controls.Add(gbSystem);

            lblSec7 = MakeLabel("启动与权限", S(38), S(30), S(300), S(18), fSect, CText);
            SectionIcon(gbSystem, "ico-battery-n.png", S(33));
            gbSystem.Controls.Add(lblSec7);

            Row r2 = new Row(gbSystem, S(16), S(64));
            chkAutoStart = AutoCheck("开机自启动", fNormal);
            chkAutoStart.CheckedChanged += OnAutoStartChanged;
            r2.Add(chkAutoStart, 0);

            btnHotkey = MakeButton("快捷键设置…", S(534), S(60), S(150), S(32));
            btnHotkey.Click += OnHotkeySettingsClick;
            gbSystem.Controls.Add(btnHotkey);

            btnElevate = MakeButton("以管理员重启", S(700), S(60), S(160), S(32));
            btnElevate.Click += OnElevateClick;
            gbSystem.Controls.Add(btnElevate);

            Label lSysHint = MakeLabel("自启动、快捷键与硬件类设置（温控、背光）都需要管理员权限才能生效。",
                                       S(16), S(106), S(848), S(18), fSmall, CSub);
            gbSystem.Controls.Add(lSysHint);

            Panel sepSys1 = MakeSeparator(S(14), S(140), S(848));
            sepSys1.Name = "sepSys1";
            gbSystem.Controls.Add(sepSys1);

            // ---- 界面缩放：人工调节全部文字和板块的大小 ----
            lblSec8 = MakeLabel("界面缩放", S(38), S(158), S(300), S(18), fSect, CText);
            SectionIcon(gbSystem, "ico-network-n.png", S(161));
            gbSystem.Controls.Add(lblSec8);

            Row rsc = new Row(gbSystem, S(16), S(194));
            Label lScale = AutoLabel("缩放比例", fNormal, CText);
            rsc.Add(lScale, S(10));
            cmbScale = AutoCombo(fNormal, UiScaleStore.Options());
            cmbScale.Name = "cmbScale";
            cmbScale.SelectedItem = UiScaleStore.Label(_uiPct);
            if (cmbScale.SelectedIndex < 0) cmbScale.SelectedIndex = cmbScale.Items.Count - 1;
            cmbScale.SelectedIndexChanged += OnScaleChanged;
            rsc.Add(cmbScale, S(16));
            Label lScaleHint = AutoLabel("改档会重建整个界面", fSmall, CSub);
            rsc.Add(lScaleHint, 0);

            Panel sepSys2 = MakeSeparator(S(14), S(234), S(848));
            sepSys2.Name = "sepSys2";
            gbSystem.Controls.Add(sepSys2);

            // ---- 诊断与日志 ----
            lblSec9 = MakeLabel("诊断与日志", S(38), S(252), S(300), S(18), fSect, CText);
            SectionIcon(gbSystem, "ico-SM-n.png", S(255));
            gbSystem.Controls.Add(lblSec9);

            btnOpenLog = MakeButton("打开日志目录", S(16), S(284), S(150), S(30));
            btnOpenLog.Name = "btnOpenLog";
            btnOpenLog.Click += OnOpenLogClick;
            gbSystem.Controls.Add(btnOpenLog);

            Label lLogHint = MakeLabel("日志与设置都存在 %LOCALAPPDATA%/SysConsole/ 下（sysconsole.log、ui.txt 与各设置文件）。",
                                       S(16), S(326), S(848), S(18), fSmall, CSub);
            gbSystem.Controls.Add(lLogHint);

            gbSystem.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblSec7.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            lblSec8.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            lblSec9.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            lSysHint.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lLogHint.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            sepSys1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            sepSys2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            btnHotkey.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnElevate.Anchor = AnchorStyles.Top | AnchorStyles.Right;


            // ============================================================
            //  第 6 页：风扇曲线
            // ============================================================
            Panel pageFan = MakePage("风扇曲线", "按温度自动切换 EC 的风扇档位", "ico-turbo.png");

            gbFan = MakeGroup("温度 → 档位", S(16), S(12), S(876), S(408));
            pageFan.Controls.Add(gbFan);

            lblSecFan = MakeLabel("温度 → 档位", S(38), S(30), S(220), S(18), fSect, CText);
            SectionIcon(gbFan, "ico-turbo.png", S(33));
            gbFan.Controls.Add(lblSecFan);

            chkFanCurve = AutoCheck("启用风扇曲线", fNormal);
            chkFanCurve.Name = "chkFanCurve";
            chkFanCurve.Left = S(860) - chkFanCurve.Width;
            chkFanCurve.Top = S(29);
            chkFanCurve.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            chkFanCurve.CheckedChanged += OnFanCurveChanged;
            gbFan.Controls.Add(chkFanCurve);

            Label lHintFan = MakeLabel("拖动圆点改曲线；图上的点是每秒实测（横轴温度、纵轴转速），鼠标移到图上可读数。EC 只有四档，折线是「期望」，点是「实际」。",
                                       S(16), S(58), S(848), S(18), fSmall, CSub);
            lHintFan.Name = "lHintFan";
            gbFan.Controls.Add(lHintFan);

            pnlFanCurve = new FanCurvePanel();
            pnlFanCurve.Name = "pnlFanCurve";
            pnlFanCurve.Left = S(16); pnlFanCurve.Top = S(84);
            pnlFanCurve.Width = S(848); pnlFanCurve.Height = S(206);
            pnlFanCurve.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            pnlFanCurve.SafetyC = FanCurve.MinStandardC;
            pnlFanCurve.Points = _fanCfg.Points;
            pnlFanCurve.Changed += OnFanCurveChanged;
            gbFan.Controls.Add(pnlFanCurve);

            Row frh = new Row(gbFan, S(16), S(302));
            Label fha = AutoLabel("回差", fNormal, CText); frh.Add(fha, S(8));
            numFanHys = AutoNum(fNormal, 0, 15, 3); numFanHys.ValueChanged += OnFanCurveChanged; frh.Add(numFanHys, S(8));
            Label fhb = AutoLabel("°C（降温要低过回差才降档，避免在阈值附近来回抖）", fSmall, CSub); frh.Add(fhb, 0);

            Panel sepFan = MakeSeparator(S(14), S(340), S(848));
            sepFan.Name = "sepFan";
            gbFan.Controls.Add(sepFan);

            lblFanStatus = MakeLabel("当前 --", S(16), S(354), S(660), S(20), fNormal, CText);
            lblFanStatus.Name = "lblFanStatus";
            gbFan.Controls.Add(lblFanStatus);

            lblFanSafety = MakeLabel("安全底线：≥70°C 不允许低于「标准」，≥80°C 强制强冷 —— 这两条优先于上面的曲线，不可关闭。",
                                     S(16), S(380), S(660), S(18), fSmall, CSub);
            lblFanSafety.Name = "lblFanSafety";
            gbFan.Controls.Add(lblFanSafety);

            btnFanApply = MakeButton("立即应用一次", S(710), S(374), S(150), S(30));
            btnFanApply.Name = "btnFanApply";
            btnFanApply.Click += OnFanApplyClick;
            btnFanApply.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            gbFan.Controls.Add(btnFanApply);

            gbFan.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblSecFan.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            lHintFan.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblFanStatus.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblFanSafety.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            sepFan.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

            // ---------------- 名称（供无界面 --uitest 布局校验使用） ----------------
            gbMonitor.Name = "gbMonitor"; pnlZones.Name = "pnlZones"; pnlGraph.Name = "pnlGraph";
            pnlCores.Name = "pnlCores"; pnlMem.Name = "pnlMem"; lblFan.Name = "lblFan";
            lblCpu.Name = "lblCpu"; lblMem.Name = "lblMem";
            gbControl.Name = "gbControl";
            chkGuard.Name = "chkGuard";
            chkWall.Name = "chkWall"; numWallTarget.Name = "numWallTarget";
            chkWallTurbo.Name = "chkWallTurbo"; chkWallBoost.Name = "chkWallBoost";
            numTrigger.Name = "numTrigger"; numRelease.Name = "numRelease"; numLimit.Name = "numLimit";
            tbMax.Name = "tbMax"; tbMin.Name = "tbMin";
            chkTurbo.Name = "chkTurbo";
            lblMaxVal.Name = "lblMaxVal"; lblMinVal.Name = "lblMinVal";
            btnApply.Name = "btnApply"; btnHotkey.Name = "btnHotkey";
            chkAutoStart.Name = "chkAutoStart";
            numMax.Name = "numMax"; numMin.Name = "numMin";
            btnMin0.Name = "btnMin0"; btnMin5.Name = "btnMin5";
            btnMin50.Name = "btnMin50"; btnMin100.Name = "btnMin100";
            sep1.Name = "sep1"; sep2.Name = "sep2";
            lblSec1.Name = "lblSec1"; lblSec2.Name = "lblSec2"; lblSec3.Name = "lblSec3";
            lblSec5.Name = "lblSec5"; lblSec6.Name = "lblSec6"; lblSec7.Name = "lblSec7";
            lblSec8.Name = "lblSec8"; lblSec9.Name = "lblSec9";
            gbThermal.Name = "gbThermal"; gbLight.Name = "gbLight"; gbSystem.Name = "gbSystem";
            gbFan.Name = "gbFan";
            numFanHys.Name = "numFanHys";
            btnPerf.Name = "btnPerf"; btnBalanced.Name = "btnBalanced";
            btnQuiet.Name = "btnQuiet"; btnFanBoost.Name = "btnFanBoost";
            btnElevate.Name = "btnElevate"; cmbMode.Name = "cmbMode"; cmbCool.Name = "cmbCool";
            lblThrottle.Name = "lblThrottle"; lblNavFoot.Name = "lblNavFoot";

            // 页名水印统一在这里加：必须等各页的卡片都加进页面之后再添加，
            // 后加的在 z 序上方 —— 监控页的卡片铺满整页，先加就被盖住了。
            for (int i = 0; i < _pages.Count; i++) AddPageMark(_pages[i], _pageTitles[i]);

            // ---------------- 导航排布 + 首屏 ----------------
            LayoutNav();
            SwitchPage(0);

            // 最小尺寸 = 设计尺寸：页面内的行距是按"刚好放得下"排的，再缩就会挤。
            MinimumSize = new Size(Width, Height);
        }

        // ---------------------------------------------------------- 分页外壳

        // ---------------------------------------------------------- 风扇曲线

        /// <summary>把配置回填到界面控件（不触发保存）。</summary>
        void RefreshFanCurveUi()
        {
            if (chkFanCurve == null) return;
            bool prevLoading = _loading;      // 别把别人的 _loading 清掉
            _fanLoading = true;
            _loading = true;
            try
            {
                chkFanCurve.Checked = _fanCfg.Enabled;
                numFanHys.Value = Clamp(_fanCfg.Hysteresis, 0, 15);
                if (pnlFanCurve != null)
                {
                    pnlFanCurve.Points = _fanCfg.Points;
                    pnlFanCurve.SafetyC = FanCurve.MinStandardC;
                    pnlFanCurve.Invalidate();
                }
            }
            finally { _fanLoading = false; _loading = prevLoading; }
            UpdateFanCurveStatus();
        }

        /// <summary>界面上的任何改动：回写配置 → 存盘 → 立刻按当前温度应用一次。</summary>
        void OnFanCurveChanged(object sender, EventArgs e)
        {
            if (_fanLoading || _loading) return;
            if (pnlFanCurve == null) return;

            // 曲线上的点由画布直接改（拖圆点），这里只做一次规范化：
            // 阈值递增、档位不倒挂，兜底那点固定 LimitC=0。
            List<FanCurvePoint> src = pnlFanCurve.Points;
            List<FanCurvePoint> ps = new List<FanCurvePoint>();
            int tmax = 30, lmax = 0;
            for (int i = 0; i < 4 && i < src.Count; i++)
            {
                int t = Clamp(src[i].LimitC, 30, 100);
                if (i < 3) { if (t <= tmax) t = tmax + 1; tmax = t; }
                else t = 0;
                int lv = Clamp(src[i].Level, lmax, 3);
                lmax = lv;
                ps.Add(new FanCurvePoint(t, lv));
            }
            if (ps.Count == 4) { _fanCfg.Points = ps; pnlFanCurve.Points = ps; }
            _fanCfg.Hysteresis = (int)numFanHys.Value;
            _fanCfg.Enabled = chkFanCurve.Checked;
            FanCurveStore.Save(_fanCfg);

            if (_fanCfg.Enabled)
            {
                double t = 0;
                lock (_lock) { t = _snap != null ? _snap.MaxZoneTemp : 0; }
                string msg = FanCurve.Tick(t, _fanCfg);
                if (msg != null) Log.Write(msg);
            }
            UpdateFanCurveStatus();
        }

        void OnFanApplyClick(object sender, EventArgs e)
        {
            double t = 0;
            lock (_lock) { t = _snap != null ? _snap.MaxZoneTemp : 0; }
            string msg = FanCurve.Tick(t, _fanCfg);
            if (msg != null) Log.Write(msg);
            UpdateFanCurveStatus();
            if (stStatus != null) stStatus.Text = "风扇曲线已按当前温度应用";
        }

        /// <summary>状态行：当前温度、生效档位、曲线开关。</summary>
        void UpdateFanCurveStatus()
        {
            if (lblFanStatus == null) return;
            double t = 0;
            lock (_lock) { t = _snap != null ? _snap.MaxZoneTemp : 0; }
            int lvl = FanCurve.Active ? FanCurve.CurrentLevel : -1;
            if (pnlFanCurve != null)
            {
                pnlFanCurve.LiveTempC = t;
                pnlFanCurve.LiveLevel = lvl;
                // 每秒把（温度，风扇1 转速）落一个点 —— 这就是图上那撮实测点云。
                // 转速取后台线程缓存的读数，UI 线程不碰 EC。
                Ec.FanReadout fr = _fanSnap;
                if (fr != null && fr.Ok) pnlFanCurve.AddSample(t, fr.Fan1Rpm);
                pnlFanCurve.Invalidate();
            }
            lblFanStatus.Text = string.Format(CultureInfo.InvariantCulture,
                "当前最高热区 {0:0.0}°C    {1}    {2}",
                t,
                lvl >= 0 ? ("生效档位 " + FanLevels.Name(lvl)) : "未接管风扇",
                _fanCfg.Enabled ? "曲线已启用" : "曲线已关闭");
            lblFanStatus.ForeColor = _fanCfg.Enabled ? CAccent : CSub;
        }

        /// <summary>
        /// 页面右下角的页名水印：低对比大字，落在卡片下方原本空着的区域里。
        /// 字号用 fMark（24pt 粗体），颜色 CMark（很浅的冷灰）——在白色卡片上和
        /// 浅灰页底上都能看见，但不会跟正文抢注意力。
        /// </summary>
        void AddPageMark(Panel page, string title)
        {
            int idx = _pages.IndexOf(page);
            Label mark = new Label();
            mark.Name = "pageMark" + idx;
            mark.Text = title;
            mark.Font = fMark;
            mark.ForeColor = CMark;
            mark.BackColor = Color.Transparent;
            mark.AutoSize = false;
            // 高宽都留够余量：水印也是文字控件，矮于字体行高就会被裁
            int mw = TextW(title, fMark) + S(16);
            int mh = fMark.Height + S(8);
            mark.Bounds = new Rectangle(page.Width - mw - S(28), page.Height - mh - S(16), mw, mh);
            mark.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            mark.TextAlign = ContentAlignment.MiddleRight;
            page.Controls.Add(mark);
            _marks.Add(mark);
        }


        /// <summary>
        /// 风扇曲线图：X = 温度（30~100°C），Y = 风扇档位（实测稳态占空比 100/120/140/200）。
        ///
        /// 画成一座"山"：台阶下面是填充区域，温度越高台阶越高，一眼就能看出
        /// "温度 → 吹多猛"的对应关系。台阶的四个圆点可以直接拖：
        ///   左右拖 = 改这一段从多少度开始；上下拖 = 改这一段用哪一档（自动吸附到四档）。
        /// 最后一个圆点固定在右端，只改"更高温度用哪一档"。
        /// 拖动时会强制温度递增、档位不下降 —— 风扇曲线不允许反过来。
        /// </summary>
        class FanCurvePanel : BuffPanel
        {
            /// <summary>曲线上四个点：前三个是温度阈值（低于它用这一档），最后一个是兜底档。</summary>
            public List<FanCurvePoint> Points = FanCurveConfig.Defaults();

            /// <summary>实测样本（温度 °C，风扇1 转速 RPM），每秒一个，最多 600 个 ≈ 10 分钟。</summary>
            public readonly List<PointF> Samples = new List<PointF>();
            public const int SampleMax = 600;

            public double LiveTempC = -1;   // 当前最高热区温度
            public int LiveLevel = -1;      // 当前实际生效档位（含安全底线）
            public double SafetyC = 70;     // 安全底线温度（画一条警示线）
            public event EventHandler Changed;

            int _drag = -1;
            int _hover = -1;
            int _mouseX = int.MinValue;     // 悬停读数用；int.MinValue = 鼠标不在图上
            readonly FanCurveConfig _cfgView = new FanCurveConfig();   // 只给悬停读数用，避免每次重绘都 new

            const int TempMin = 30, TempMax = 100;
            const int RpmMin = 1500, RpmMax = 6200;
            /// <summary>
            /// 四档的**满载稳态参考转速**（风扇1，实测；见 docs/FAN-CONTROL-PROTOCOL.md §6.1）。
            /// 注意这是"持续负载下的稳态值"：空载时 EC 自己会给更低的转速，
            /// 所以实测点通常落在参考线下方 —— 那正是要观察的东西。
            /// </summary>
            static readonly int[] LevelRpm = new int[] { 3617, 4114, 4697, 5891 };

            int PL { get { return S(58); } }
            int PR { get { return S(26); } }
            int PT { get { return S(20); } }
            int PB { get { return S(26); } }
            int PlotW { get { return Math.Max(1, ClientSize.Width - PL - PR); } }
            int PlotH { get { return Math.Max(1, ClientSize.Height - PT - PB); } }

            public int XOf(double t)
            {
                if (t < TempMin) t = TempMin;
                if (t > TempMax) t = TempMax;
                return PL + (int)Math.Round((t - TempMin) * PlotW / (double)(TempMax - TempMin));
            }
            public double TempOf(int x)
            {
                double t = TempMin + (x - PL) * (double)(TempMax - TempMin) / PlotW;
                if (t < TempMin) t = TempMin;
                if (t > TempMax) t = TempMax;
                return t;
            }
            int YOfRpm(int rpm)
            {
                if (rpm < RpmMin) rpm = RpmMin;
                if (rpm > RpmMax) rpm = RpmMax;
                return PT + PlotH - (int)Math.Round((rpm - RpmMin) * (double)PlotH / (RpmMax - RpmMin));
            }
            int LevelOfY(int y)
            {
                int best = 0, bd = int.MaxValue;
                for (int i = 0; i < LevelRpm.Length; i++)
                {
                    int d = Math.Abs(YOfRpm(LevelRpm[i]) - y);
                    if (d < bd) { bd = d; best = i; }
                }
                return best;
            }

            /// <summary>每秒喂一个实测样本。UI 线程调用，只做一次入列。</summary>
            public void AddSample(double tempC, int rpm)
            {
                if (tempC <= 0 || rpm <= 0) return;
                Samples.Add(new PointF((float)tempC, rpm));
                if (Samples.Count > SampleMax) Samples.RemoveRange(0, Samples.Count - SampleMax);
            }

            public void ClearSamples() { Samples.Clear(); }

            /// <summary>圆点位置：前三个在各自阈值处，第四个固定在右端（兜底档）。</summary>
            public Point HandleAt(int i)
            {
                if (Points == null || Points.Count < 4) return new Point(PL, PT);
                if (i < 3) return new Point(XOf(Points[i].LimitC), YOfRpm(LevelRpm[Points[i].Level]));
                return new Point(PL + PlotW, YOfRpm(LevelRpm[Points[3].Level]));
            }

            int HitTest(Point p)
            {
                int r = S(16);
                for (int i = 0; i < 4; i++)
                {
                    Point h = HandleAt(i);
                    if (Math.Abs(h.X - p.X) <= r && Math.Abs(h.Y - p.Y) <= r) return i;
                }
                return -1;
            }

            protected override void OnMouseLeave(EventArgs e)
            {
                base.OnMouseLeave(e);
                _mouseX = int.MinValue;
                Invalidate();
            }

            protected override void OnMouseDown(MouseEventArgs e)
            {
                base.OnMouseDown(e);
                _drag = HitTest(e.Location);
                if (_drag >= 0) Capture = true;
            }

            protected override void OnMouseUp(MouseEventArgs e)
            {
                base.OnMouseUp(e);
                if (_drag >= 0)
                {
                    _drag = -1;
                    Capture = false;
                    if (Changed != null) Changed(this, EventArgs.Empty);
                }
            }

            protected override void OnMouseMove(MouseEventArgs e)
            {
                base.OnMouseMove(e);
                _mouseX = e.X;
                if (_drag < 0)
                {
                    int h = HitTest(e.Location);
                    if (h != _hover) { _hover = h; Cursor = h >= 0 ? Cursors.Hand : Cursors.Default; }
                    Invalidate();
                    return;
                }
                if (Points == null || Points.Count < 4) return;

                int lv = LevelOfY(e.Y);
                if (_drag < 3)
                {
                    int t = (int)Math.Round(TempOf(e.X));
                    if (_drag == 0) { if (t > Points[1].LimitC - 2) t = Points[1].LimitC - 2; if (t < TempMin) t = TempMin; }
                    else if (_drag == 1)
                    {
                        if (t < Points[0].LimitC + 2) t = Points[0].LimitC + 2;
                        if (t > Points[2].LimitC - 2) t = Points[2].LimitC - 2;
                    }
                    else
                    {
                        if (t < Points[1].LimitC + 2) t = Points[1].LimitC + 2;
                        if (t > TempMax) t = TempMax;
                    }
                    // 档位不许倒挂：这一档不能低于前一档、也不能高于后一档
                    int lo = _drag == 0 ? 0 : Points[_drag - 1].Level;
                    int hi = _drag == 2 ? 3 : Points[_drag + 1].Level;
                    if (lv < lo) lv = lo;
                    if (lv > hi) lv = hi;
                    Points[_drag].LimitC = t;
                    Points[_drag].Level = lv;
                }
                else
                {
                    int lo = Points[2].Level;
                    if (lv < lo) lv = lo;
                    Points[3].Level = lv;
                }
                Invalidate();
            }

            protected override void OnPaint(PaintEventArgs e)
            {
                base.OnPaint(e);
                Graphics g = e.Graphics;
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
                using (SolidBrush bg = new SolidBrush(CCard)) g.FillRectangle(bg, ClientRectangle);
                if (Points == null || Points.Count < 4) return;

                int x0 = PL, x1 = PL + PlotW, y0 = PT, y1 = PT + PlotH;

                // ---- 网格：竖向每 10°C ----
                using (Pen gp = new Pen(Color.FromArgb(236, 240, 246)))
                    for (int t = TempMin; t <= TempMax; t += 10) { int x = XOf(t); g.DrawLine(gp, x, y0, x, y1); }

                // ---- 四档参考线（按参考转速画）----
                using (Pen gp2 = new Pen(Color.FromArgb(228, 234, 242)))
                    for (int i = 0; i < LevelRpm.Length; i++) { int y = YOfRpm(LevelRpm[i]); g.DrawLine(gp2, x0, y, x1, y); }

                // ---- 坐标轴 ----
                using (Pen ap = new Pen(CLine))
                {
                    g.DrawLine(ap, x0, y1, x1, y1);
                    g.DrawLine(ap, x0, y0, x0, y1);
                }

                // ---- 实测样本云（先画，压在曲线下面）----
                if (Samples.Count > 0)
                {
                    int n = Samples.Count;
                    for (int i = 0; i < n; i++)
                    {
                        // 越新的越深：最老 22% 透明度，最新 78%
                        int a = 22 + (int)(56.0 * i / Math.Max(1, n - 1));
                        int px = XOf(Samples[i].X);
                        int py = YOfRpm((int)Samples[i].Y);
                        using (SolidBrush sb = new SolidBrush(Color.FromArgb(a, 0, 120, 212)))
                            g.FillEllipse(sb, px - S(2), py - S(2), S(5), S(5));
                    }
                }

                // ---- 山形：台阶折线 + 填充（按参考转速画）----
                int[] xs = new int[5];
                int[] ys = new int[5];
                xs[0] = x0; ys[0] = YOfRpm(LevelRpm[Points[0].Level]);
                for (int i = 0; i < 3; i++)
                {
                    xs[i + 1] = XOf(Points[i].LimitC);
                    ys[i + 1] = YOfRpm(LevelRpm[Points[i + 1].Level]);
                }
                List<Point> line = new List<Point>();
                line.Add(new Point(x0, ys[0]));
                line.Add(new Point(xs[1], ys[0]));
                line.Add(new Point(xs[1], ys[1]));
                line.Add(new Point(xs[2], ys[1]));
                line.Add(new Point(xs[2], ys[2]));
                line.Add(new Point(xs[3], ys[2]));
                line.Add(new Point(xs[3], ys[3]));
                line.Add(new Point(x1, ys[3]));
                List<Point> poly = new List<Point>(line);
                poly.Add(new Point(x1, y1));
                poly.Add(new Point(x0, y1));
                using (SolidBrush fill = new SolidBrush(Color.FromArgb(22, CAccent)))
                    g.FillPolygon(fill, poly.ToArray());
                using (Pen lp = new Pen(CAccent, S(2)))
                {
                    lp.LineJoin = LineJoin.Round;
                    g.DrawLines(lp, line.ToArray());
                }

                // ---- 轴标签 ----
                using (SolidBrush sb = new SolidBrush(CSub))
                {
                    // ⚠ 字体是 MainForm 的共享实例：只能借用，绝不能 Dispose ——
                    // 用 using 包住会把 fSmall 释放掉，之后每次 DrawString 都失败，
                    // WinForms 会反复重绘变成满 CPU 的死循环（实测踩过）。
                    Font f = fSmall;
                    for (int t = TempMin; t <= TempMax; t += 10)
                    {
                        string s = t.ToString(CultureInfo.InvariantCulture) + "°";
                        SizeF sz = g.MeasureString(s, f);
                        g.DrawString(s, f, sb, XOf(t) - sz.Width / 2f, y1 + S(4));
                    }
                    for (int i = 0; i < LevelRpm.Length; i++)
                    {
                        int y = YOfRpm(LevelRpm[i]);
                        string s = FanLevels.Name(i);
                        SizeF sz = g.MeasureString(s, f);
                        g.DrawString(s, f, sb, x0 - sz.Width - S(8), y - sz.Height / 2f);
                        string r = LevelRpm[i].ToString(CultureInfo.InvariantCulture);
                        SizeF sz2 = g.MeasureString(r, f);
                        g.DrawString(r, f, sb, x1 + S(4), y - sz2.Height / 2f);
                    }
                    // 图例
                    g.DrawString("● 实测点（每秒 1 个，最多 10 分钟）　　折线 = 你的曲线（按满载参考转速画）",
                                 f, sb, x0 + S(4), y0 - S(2));
                }

                // ---- 安全底线 ----
                if (SafetyC > TempMin && SafetyC < TempMax)
                {
                    int xsafe = XOf(SafetyC);
                    using (Pen sp = new Pen(Color.FromArgb(120, CDanger)))
                    {
                        sp.DashStyle = DashStyle.Dash;
                        g.DrawLine(sp, xsafe, y0, xsafe, y1);
                    }
                    using (SolidBrush db = new SolidBrush(Color.FromArgb(170, CDanger)))
                        g.DrawString("安全底线 " + SafetyC.ToString("0", CultureInfo.InvariantCulture) + "°C",
                                     fSmall, db, xsafe - S(4), y0 + S(14));
                }

                // ---- 悬停读数：该温度会用哪一档 ----
                if (_mouseX != int.MinValue && _mouseX >= x0 && _mouseX <= x1 && _drag < 0)
                {
                    _cfgView.Points = Points;
                    int lvAt = FanCurve.TargetLevel(TempOf(_mouseX), _cfgView);
                    using (Pen mp = new Pen(Color.FromArgb(150, CSub)))
                    {
                        mp.DashStyle = DashStyle.Dot;
                        g.DrawLine(mp, _mouseX, y0, _mouseX, y1);
                    }
                    using (SolidBrush nb = new SolidBrush(CText))
                    using (SolidBrush bg2 = new SolidBrush(Color.FromArgb(235, 245, 250, 255)))
                    {
                        string txt = TempOf(_mouseX).ToString("0", CultureInfo.InvariantCulture) + "°C → " + FanLevels.Name(lvAt) +
                                     "（参考 " + LevelRpm[lvAt].ToString(CultureInfo.InvariantCulture) + " RPM）";
                        SizeF sz = g.MeasureString(txt, fSmall);
                        float bx = _mouseX + S(8);
                        if (bx + sz.Width > x1) bx = _mouseX - sz.Width - S(8);
                        g.FillRectangle(bg2, bx - S(3), y0 + S(2), sz.Width + S(6), sz.Height);
                        g.DrawString(txt, fSmall, nb, bx, y0 + S(3));
                    }
                }

                // ---- 当前工况：竖线 + 交点 ----
                if (LiveTempC > 0)
                {
                    int xl = XOf(LiveTempC);
                    using (Pen vp = new Pen(Color.FromArgb(140, CGreen)))
                    {
                        vp.DashStyle = DashStyle.Dot;
                        g.DrawLine(vp, xl, y0, xl, y1);
                    }
                    using (SolidBrush lb = new SolidBrush(CGreen))
                    {
                        string txt = LiveTempC.ToString("0.0", CultureInfo.InvariantCulture) + "°C";
                        if (LiveLevel >= 0) txt += " → " + FanLevels.Name(LiveLevel);
                        if (Samples.Count > 0) txt += "　实测 " + ((int)Samples[Samples.Count - 1].Y).ToString(CultureInfo.InvariantCulture) + " RPM";
                        SizeF sz = g.MeasureString(txt, fSmall);
                        float tx = xl + S(8);
                        if (tx + sz.Width > x1) tx = xl - sz.Width - S(8);
                        g.DrawString(txt, fSmall, lb, tx, y1 - sz.Height - S(2));
                        int yLast = YOfRpm((int)Samples[Samples.Count - 1].Y);
                        if (Samples.Count > 0) g.FillEllipse(lb, xl - S(4), yLast - S(4), S(9), S(9));
                    }
                }

                // ---- 拖拽圆点（画在最上面）----
                for (int i = 0; i < 4; i++)
                {
                    Point h = HandleAt(i);
                    bool hot = (i == _drag) || (i == _hover);
                    using (SolidBrush hb = new SolidBrush(hot ? CAccent : CCard))
                    using (Pen hp = new Pen(CAccent, S(2)))
                    {
                        g.FillEllipse(hb, h.X - S(7), h.Y - S(7), S(14), S(14));
                        g.DrawEllipse(hp, h.X - S(7), h.Y - S(7), S(14), S(14));
                    }
                }
            }
        }

        /// <summary>
        /// 建一个页面（面板 + 对应的导航按钮），返回页面板本身。
        /// 页面按页体当前大小铺满，任何时刻只有当前页 Visible=true。
        /// </summary>
        Panel MakePage(string title, string sub, string icon)
        {
            int idx = _pages.Count;

            Panel p = new BuffPanel();
            p.Name = "page" + idx;
            // 不用 Dock=Fill：Dock 要等父容器跑完一次布局才生效，而卡片紧接着就
            // 加进来并锚定了 —— 锚定会拿"父容器还是 200x100 默认尺寸"去记边距，
            // 等页面真正撑开时卡片会被撑成 1674px（父容器宽出 737px）。
            // 直接按页体当前大小写死，再四边锚定，结果完全可预期。
            p.Bounds = new Rectangle(0, 0, pnlBody.Width, pnlBody.Height);
            p.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            p.BackColor = CBack;
            p.Visible = false;

            Button b = new Button();
            b.Name = "nav" + idx;
            b.Text = title;
            b.Font = fNormal;
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.FlatAppearance.MouseOverBackColor = CAccentSoft;
            b.FlatAppearance.MouseDownBackColor = CAccentSoft;
            b.BackColor = Color.White;
            b.ForeColor = CText;
            b.TextAlign = ContentAlignment.MiddleLeft;
            b.TextImageRelation = TextImageRelation.ImageBeforeText;
            b.ImageAlign = ContentAlignment.MiddleLeft;
            b.UseVisualStyleBackColor = false;
            b.Cursor = Cursors.Hand;
            b.TabStop = false;
            b.Tag = idx;
            Image img = Assets.GetSized(icon, S(16), S(16));
            if (img != null)
            {
                b.Image = img;
                b.Padding = new Padding(S(12), 0, 0, 0);
            }
            else b.Padding = new Padding(S(30), 0, 0, 0);
            b.Click += delegate { SwitchPage(idx); };

            pnlNav.Controls.Add(b);
            pnlBody.Controls.Add(p);

            _navBtns.Add(b);
            _pages.Add(p);
            _pageTitles.Add(title);
            _pageSubs.Add(sub);
            return p;
        }

        /// <summary>导航按钮竖向排布，并把选中指示条放到当前页那一格上。</summary>
        void LayoutNav()
        {
            int y = S(72);
            for (int i = 0; i < _navBtns.Count; i++)
            {
                _navBtns[i].Bounds = new Rectangle(S(10), y, pnlNav.Width - S(20), S(40));
                _navBtns[i].Anchor = AnchorStyles.Top | AnchorStyles.Left;
                y += S(44);
            }
            if (pnlNavMark != null)
            {
                pnlNavMark.Bounds = new Rectangle(0, S(72), S(3), S(40));
                pnlNavMark.BringToFront();
            }
        }

        /// <summary>
        /// 切换页面：只让目标页可见，同步导航高亮、左侧指示条与页面尺寸。
        /// 隐藏的页面照样在后台收数据（轮询线程不区分页面），切回来就是最新的。
        /// </summary>
        void SwitchPage(int i)
        {
            if (i < 0 || i >= _pages.Count) return;
            _page = i;

            for (int k = 0; k < _pages.Count; k++)
            {
                bool on = (k == i);
                // 必须无条件赋值：Visible 的比较用的是"有效可见性"（窗口没显示时
                // 恒为 false），拿它当条件会永远走不进 false 分支，控件自己的
                // STATE_VISIBLE 位就清不掉，切过的页面会一直留着。
                _pages[k].Visible = on;

                Button b = _navBtns[k];
                b.BackColor = on ? CAccentSoft : Color.White;
                b.ForeColor = on ? CAccent : CText;
                b.Font = on ? fSect : fNormal;
            }

            // 隐藏期间窗口可能已经被拉大过：锚定不会传播到不可见的控件，所以
            // 切回来时先把页面拉到页体的当前大小，再让页内控件按锚定铺开。
            Panel cur = _pages[i];
            cur.Bounds = new Rectangle(0, 0, pnlBody.ClientSize.Width, pnlBody.ClientSize.Height);

            if (pnlNavMark != null && i < _navBtns.Count)
            {
                pnlNavMark.Top = _navBtns[i].Top;
                pnlNavMark.Visible = true;
                pnlNavMark.BringToFront();
            }
            cur.PerformLayout();
        }

        /// <summary>Ctrl+Tab 翻页、Ctrl+1..5 直达 —— 五个页面全都能键盘切。</summary>
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (_pages.Count > 0 && (keyData & Keys.Control) == Keys.Control && (keyData & Keys.Alt) == Keys.None)
            {
                Keys k = keyData & Keys.KeyCode;
                if (k == Keys.Tab)
                {
                    SwitchPage((_page + 1) % _pages.Count);
                    return true;
                }
                int n = (int)k - (int)Keys.D1;
                if (n >= 0 && n < _pages.Count)
                {
                    SwitchPage(n);
                    return true;
                }
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        // ---------------- 按实测文字宽度自动布局 ----------------
        // 手工估算控件宽度在缩放 DPI 下必然出错（文字按实际 DPI 渲染，而坐标是
        // 设计像素）。改为在创建控件时用 TextRenderer 量出真实宽度，从根上避免截断。

        static int TextW(string s, Font f)
        {
            return TextRenderer.MeasureText(s, f).Width;
        }

        static int MaxTextW(string[] ss, Font f)
        {
            int w = 0;
            for (int i = 0; i < ss.Length; i++) { int t = TextW(ss[i], f); if (t > w) w = t; }
            return w;
        }

        class Row
        {
            readonly Control _parent;
            int _x;
            readonly int _baseY;      // >=0：按这个基线把每行控件垂直居中；-1：沿用调用方自己设的 Top
            public Row(Control parent, int startX) { _parent = parent; _x = startX; _baseY = -1; }
            public Row(Control parent, int startX, int baseY) { _parent = parent; _x = startX; _baseY = baseY; }
            public int X { get { return _x; } }
            public T Add<T>(T c, int gap) where T : Control
            {
                c.Left = _x;
                if (_baseY >= 0) c.Top = _baseY + (S(24) - c.Height) / 2;
                _parent.Controls.Add(c);
                _x = c.Right + gap;
                return c;
            }
        }

        /// <summary>
        /// 文字控件的最小高度 = 字体行高 + 上下各 S(4) 的余量。
        /// 高度写死成设计值（S(16)/S(18)/S(20)）在高 DPI 或换字体时会"框比字矮"，
        /// 文字上下直接被切掉 —— 这正是 150% DPI 上的老毛病。这里统一兜底。
        /// </summary>
        int MinTextH(Font f) { return f.Height + S(8); }

        Label AutoLabel(string text, Font f, Color c)
        {
            Label l = new Label();
            l.Text = text; l.Font = f; l.ForeColor = c; l.AutoSize = false;
            l.Size = new Size(TextW(text, f) + S(10), MinTextH(f));
            return l;
        }

        /// <summary>
        /// 复选框。勾选框用原厂控制台的素材（btn-checkbox-checked / unchecked），
        /// 比系统原生的小方框和整体观感更贴。
        ///
        /// 做法：把 CheckBox 设成 Appearance.Button + Flat（这样它不再自己画方框），
        /// 再用 TextImageRelation.ImageBeforeText 让"勾选框素材 + 文字"作为一整块居中排版。
        /// 宽度里已经把勾选框和间距算进去了（pad = S(24)），文字不会被挤到截断。
        /// </summary>
        CheckBox AutoCheck(string text, Font f)
        {
            CheckBox c = new CheckBox();
            c.Text = text; c.Font = f; c.AutoSize = false;
            int box = S(16);
            int pad = S(24);          // 勾选框 + 与文字的间距（由 TextImageRelation 自动排）
            c.Size = new Size(TextW(text, f) + pad + S(12), MinTextH(f) + S(2));

            Image on = Assets.GetSized("btn-checkbox-checked.png", box, box);
            Image off = Assets.GetSized("btn-checkbox-unchecked.png", box, box);
            if (on != null && off != null)
            {
                c.Appearance = Appearance.Button;
                c.FlatStyle = FlatStyle.Flat;
                c.FlatAppearance.BorderSize = 0;
                c.FlatAppearance.CheckedBackColor = Color.Transparent;
                c.FlatAppearance.MouseOverBackColor = Color.Transparent;
                c.FlatAppearance.MouseDownBackColor = Color.Transparent;
                c.BackColor = CCard;
                c.UseVisualStyleBackColor = false;
                // 关键：用 TextImageRelation 让"图 + 文"作为一整块排版。
                // 只设 ImageAlign/TextAlign 的话两者会各自从左边开始画，直接重叠。
                c.TextImageRelation = TextImageRelation.ImageBeforeText;
                c.ImageAlign = ContentAlignment.MiddleCenter;
                c.TextAlign = ContentAlignment.MiddleCenter;
                c.Padding = new Padding(0);
                c.Image = off;
                c.CheckedChanged += delegate { c.Image = c.Checked ? on : off; };
            }
            return c;
        }

        ComboBox AutoCombo(Font f, string[] items)
        {
            ComboBox cb = new ComboBox();
            cb.DropDownStyle = ComboBoxStyle.DropDownList;
            cb.Font = f;
            int w = 0;
            for (int i = 0; i < items.Length; i++)
            {
                cb.Items.Add(items[i]);
                int iw = TextW(items[i], f);
                if (iw > w) w = iw;
            }
            cb.Size = new Size(w + S(32) + 10, S(24));
            return cb;
        }

        NumericUpDown AutoNum(Font f, int min, int max, int val)
        {
            NumericUpDown n = new NumericUpDown();
            n.Font = f;
            n.Minimum = min; n.Maximum = max;
            if (val > max) val = max;
            if (val < min) val = min;
            n.Value = val;
            n.Size = new Size(TextW(max.ToString(), f) + S(36), S(24));
            return n;
        }

        /// <summary>
        /// 分区标题左边的小图标。素材来自原厂控制台（见 Assets.cs）。
        /// 用独立的 PictureBox 而不是 Label.Image —— 后者会和文字抢同一块矩形，
        /// 位置不好控；独立控件配合标题右移最确定。
        /// </summary>
        void SectionIcon(Control parent, string name, int top)
        {
            Image img = Assets.GetSized(name, S(16), S(16));
            if (img == null) return;
            PictureBox p = new PictureBox();
            p.Image = img;
            p.Location = new Point(S(18), top);
            p.Size = new Size(S(16), S(16));
            p.BackColor = Color.Transparent;
            p.SizeMode = PictureBoxSizeMode.Zoom;
            p.Name = "ico_" + name.Replace(".png", "");
            parent.Controls.Add(p);
        }

        /// <summary>
        /// 进度条的底槽。用原厂素材（div-pbar300-*，300x12 的渐变条）。
        /// </summary>
        static void DrawBarTrack(Graphics g, Rectangle r)
        {
            Image img = Assets.Get("div-pbar300-empty.png");
            if (img != null && r.Width > 0 && r.Height > 0) g.DrawImage(img, r);
            else g.FillRectangle(new SolidBrush(Color.FromArgb(238, 240, 244)), r);
        }

        /// <summary>
        /// 进度条的填充段。同样优先用原厂素材，素材拿不到就退回纯色 ——
        /// 贴图失败绝不能把条子变成空白。
        /// </summary>
        static void DrawBarFill(Graphics g, Rectangle r, string asset, Color fallback)
        {
            Image img = string.IsNullOrEmpty(asset) ? null : Assets.Get(asset);
            if (img != null && r.Width > 0 && r.Height > 0) g.DrawImage(img, r);
            else g.FillRectangle(new SolidBrush(fallback), r);
        }

        GroupBox MakeGroup(string text, int x, int y, int w, int h)
        {
            GroupBox g = new GroupBox();
            g.Text = text;
            g.Location = new Point(x, y);
            g.Size = new Size(w, h);
            g.BackColor = CCard;
            g.ForeColor = CText;
            return g;
        }

        Panel MakePanel(int x, int y, int w, int h)
        {
            BuffPanel p = new BuffPanel();
            p.Location = new Point(x, y);
            p.Size = new Size(w, h);
            p.BackColor = Color.Transparent;
            return p;
        }

        // 卡片内的分区分隔线。用一条 1px 的面板而不是在 GroupBox 上自绘，
        // 这样它能跟随卡片宽度锚定拉伸，也不需要额外的绘制代码。
        Panel MakeSeparator(int x, int y, int w)
        {
            Panel p = new Panel();
            p.Location = new Point(x, y);
            p.Size = new Size(w, 1);
            p.BackColor = CLine;
            return p;
        }

        Label MakeLabel(string text, int x, int y, int w, int h, Font f, Color c)
        {
            // 高度兜底：矮于字体行高 + 余量就抬上来，否则文字上下会被裁
            if (h < MinTextH(f)) h = MinTextH(f);
            Label l = new Label();
            l.Text = text;
            l.Location = new Point(x, y);
            l.Size = new Size(w, h);
            l.Font = f;
            l.ForeColor = c;
            l.AutoSize = false;
            return l;
        }

        Button MakeButton(string text, int x, int y, int w, int h)
        {
            return MakeButton(text, x, y, w, h, null);
        }

        /// <summary>
        /// 带图标的按钮。图标取自原厂控制台的素材（见 Assets.cs）。
        ///
        /// 注意：有图标时不能用 FlatStyle.System —— 系统主题样式会忽略 Image 属性，
        /// 所以这几个按钮会退回到 Standard 样式。
        /// </summary>
        Button MakeButton(string text, int x, int y, int w, int h, string icon)
        {
            Button b = new Button();
            b.Text = text;
            b.Location = new Point(x, y);
            b.Size = new Size(w, h);
            b.UseVisualStyleBackColor = true;
            Image img = string.IsNullOrEmpty(icon) ? null : Assets.GetSized(icon, S(18), S(26));
            if (img != null)
            {
                b.FlatStyle = FlatStyle.Standard;
                b.Image = img;
                b.TextImageRelation = TextImageRelation.ImageBeforeText;
                b.ImageAlign = ContentAlignment.MiddleCenter;
                b.TextAlign = ContentAlignment.MiddleCenter;
            }
            else b.FlatStyle = FlatStyle.System;
            return b;
        }

        // ---------------------------------------------------------------- tray

        void BuildTray()
        {
            _tray = new NotifyIcon();
            _tray.Icon = MakeIcon();
            _tray.Text = "系统控制台";
            _tray.Visible = true;
            _tray.DoubleClick += delegate { RestoreWindow(); };
            ContextMenuStrip cm = new ContextMenuStrip();
            cm.Items.Add("显示主界面", null, delegate { RestoreWindow(); });
            cm.Items.Add("-");
            cm.Items.Add("均衡模式", null, delegate { ApplyPresetByKey("balanced"); });
            cm.Items.Add("静音模式", null, delegate { ApplyPresetByKey("quiet"); });
            cm.Items.Add("性能模式", null, delegate { ApplyPresetByKey("performance"); });
            cm.Items.Add("-");
            _trayFanBoost = new ToolStripMenuItem("一键强冷");
            _trayFanBoost.Click += delegate { OnFanBoostClick(null, EventArgs.Empty); };
            cm.Items.Add(_trayFanBoost);
            cm.Items.Add("-");
            _trayAuto = new ToolStripMenuItem("开机自启动");
            _trayAuto.CheckOnClick = false;   // state is owned by the scheduled task, not the menu
            _trayAuto.Click += delegate { ApplyAutoStart(!AutoStart.IsEnabled()); };
            cm.Items.Add(_trayAuto);
            cm.Items.Add("-");
            cm.Items.Add("退出", null, delegate { _reallyExit = true; Close(); });
            // Re-read the real task state each time the menu opens.
            cm.Opening += delegate
            {
                if (_trayAuto != null) _trayAuto.Checked = AutoStart.IsEnabled();
                if (_trayFanBoost != null)
                {
                    bool on = Ec.FanBoost.IsOn();
                    _trayFanBoost.Checked = on;
                    _trayFanBoost.Text = on ? "强冷：已开启" : "一键强冷";
                }
            };
            _tray.ContextMenuStrip = cm;
        }

        static Icon MakeIcon()
        {
            Bitmap bmp = new Bitmap(16, 16);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);
                g.FillEllipse(new SolidBrush(Color.FromArgb(0, 120, 212)), 1, 1, 14, 14);
                g.FillRectangle(new SolidBrush(Color.White), 6, 4, 4, 6);
                g.FillEllipse(new SolidBrush(Color.White), 5, 9, 6, 6);
            }
            IntPtr h = bmp.GetHicon();
            return Icon.FromHandle(h);
        }

        void RestoreWindow()
        {
            Show();
            WindowState = FormWindowState.Normal;
            Activate();
        }

        // -------------------------------------------------------------- startup

        void OnLoaded(object sender, EventArgs e)
        {
            RestoreWindowState();
            Sensors.Init();

            // Global hotkeys must be registered against a live window handle.
            _hotkeys = new HotkeyManager(Handle);
            ApplyHotkeyConfig(HotkeyStore.Load());

            _guardCfg = GuardStore.Load();
            RefreshGuardUi();

            _wallCfg = WallStore.Load();
            _fanCfg = FanCurveStore.Load();
            RefreshFanCurveUi();
            RefreshWallUi();

            // 风扇强冷走原生 EC 通道。设备正常情况下会一直存在；万一被外部
            // 卸载脚本删掉，这里在后台尝试一次 PnP 重新枚举，避免界面一直
            // 显示"EC 不可用"。
            Thread ecInit = new Thread(new ThreadStart(delegate
            {
                if (!Ec.IsOpen)
                {
                    string r = Ec.EnsureDevice();
                    Log.Write("EC 初始化: " + r);
                }

                // 键盘背光：上次勾了"记住颜色"就自动恢复。放在这个后台线程里，
                // 才能等到 EC 设备确实可用之后再写。
                int sr, sg, sb, shw, sbl, srate;
                if (Ec.KbColor.LoadSaved(out sr, out sg, out sb, out shw, out sbl, out srate))
                {
                    // 先复位可能残留的硬件状态，再按配置决定是开彩虹还是写颜色
                    Ec.KbColor.SetHardwareRainbow(false);
                    Ec.KbColor.ClearEffectState();
                    // 硬件彩虹模式下不要去写电平：那会盖掉固件正在跑的效果
                    string err = shw != 0
                        ? Ec.KbColor.SetHardwareRainbow(true)
                        : Ec.KbColor.ApplyRgb(sr, sg, sb, false);
                    Log.Write(string.Format(CultureInfo.InvariantCulture,
                        "键盘背光 启动应用 RGB({0},{1},{2}) 硬件彩虹={3} 闪烁={4}/{5}: {6}",
                        sr, sg, sb, shw != 0 ? "开" : "关", sbl != 0 ? "开" : "关",
                        new string[] { "慢", "中", "快" }[srate], err == null ? "OK" : err));
                    try
                    {
                        BeginInvoke(new MethodInvoker(delegate
                        {
                            chkLightRemember.Checked = true;
                            _loading = true;
                            try { if (chkHwRainbow != null) chkHwRainbow.Checked = shw != 0; }
                            finally { _loading = false; }
                            _lightR = sr; _lightG = sg; _lightB = sb;
                            _blinkRate = srate;
                            _loading = true;
                            try
                            {
                                if (cmbBlinkRate != null) cmbBlinkRate.SelectedIndex = srate;
                                if (chkBlink != null) chkBlink.Checked = sbl != 0;
                            }
                            finally { _loading = false; }
                            if (sbl != 0) StartBlink();
                            RefreshLightUi();
                        }));
                    }
                    catch { }
                }
            }));
            ecInit.IsBackground = true;
            ecInit.Start();

            _thread = new Thread(new ThreadStart(Loop));
            _thread.IsBackground = true;
            _thread.Start();

            _timer = new System.Windows.Forms.Timer();
            _timer.Interval = 1000;
            _timer.Tick += OnTick;
            _timer.Start();

            // 背光状态单独用较慢的节奏刷新，避免每秒都去读 EC
            _lightTimer = new System.Windows.Forms.Timer();
            _lightTimer.Interval = 2000;
            _lightTimer.Tick += delegate { RefreshLightUi(); };
            _lightTimer.Start();

            if (_startHidden)
            {
                WindowState = FormWindowState.Minimized;
                Hide();
            }
            else
            {
                BeginInvoke(new MethodInvoker(delegate
                {
                    RefreshPowerUi();
                }));
            }
            Log.Write("GUI started. elevated=" + Elevation.IsElevated());
        }

        void Loop()
        {
            while (!_stop)
            {
                Snapshot s;
                try { s = Sensors.Read(); }
                catch (Exception ex)
                {
                    s = new Snapshot();
                    s.Error = ex.Message;
                }
                lock (_lock) { _snap = s; }
                try { _fanSnap = Ec.ReadFan(); } catch { }
                Thread.Sleep(1000);
            }
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            // Track the "normal" (non-maximized) client size so it can be restored
            // even if the user closes the window while maximized.
            if (!_restoringState && WindowState == FormWindowState.Normal)
            {
                _normalW = ClientSize.Width;
                _normalH = ClientSize.Height;
            }
        }

        void RestoreWindowState()
        {
            int w, h;
            bool max;
            if (!UiState.LoadWindow(out w, out h, out max)) return;

            Rectangle wa = Screen.FromPoint(new Point(Left, Top)).WorkingArea;
            // 窗口尺寸 = 客户区 + 边框。这里 w/h 是客户区，上限必须按真实边框推算，
            // 否则放大后的界面会比可用高度高出一截、底部被切掉。
            int chromeW = Width - ClientSize.Width;
            int chromeH = Height - ClientSize.Height;
            if (w < MinimumSize.Width) w = MinimumSize.Width;
            if (h < MinimumSize.Height) h = MinimumSize.Height;
            if (w > wa.Width - chromeW - 8) w = wa.Width - chromeW - 8;
            if (h > wa.Height - chromeH - 8) h = wa.Height - chromeH - 8;

            _restoringState = true;
            try
            {
                ClientSize = new Size(w, h);
                if (max) WindowState = FormWindowState.Maximized;
            }
            finally { _restoringState = false; }

            _normalW = w;
            _normalH = h;
        }

        void SaveWindowState()
        {
            int w = _normalW > 0 ? _normalW : ClientSize.Width;
            int h = _normalH > 0 ? _normalH : ClientSize.Height;
            UiState.SaveWindow(w, h, WindowState == FormWindowState.Maximized);
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            _stop = true;
            // Never leave the protective cap applied after the app is gone.
            if (_guardActive)
            {
                try
                {
                    Power.RestoreState(_guardSaved);
                    Log.Write("ThermalGuard restored on exit");
                }
                catch { }
                _guardActive = false;
            }
            // 风扇曲线：退出时把风扇模式还原成接管前的样子，别让用户的风扇停在
            // "程序按温度选的档"上（它会写 0x751，必须交还）。
            if (FanCurve.Active)
            {
                try { Log.Write(FanCurve.Restore()); } catch { }
            }
            try { SaveWindowState(); } catch { }
            if (_hotkeys != null) { _hotkeys.Dispose(); _hotkeys = null; }
            if (_tray != null) { _tray.Visible = false; _tray.Dispose(); }
        }

        // WM_HOTKEY is delivered to the window, so it arrives on the UI thread
        // already - no marshalling needed before touching controls.
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == HotkeyManager.WM_HOTKEY && _hotkeys != null)
            {
                string action = _hotkeys.Resolve(m.WParam.ToInt32());
                if (action != null)
                {
                    OnHotkeyAction(action);
                    return;
                }
            }
            base.WndProc(ref m);
        }

        void OnClosing(object sender, FormClosingEventArgs e)
        {
            if (!_reallyExit && e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
                if (_tray != null)
                {
                    _tray.ShowBalloonTip(1500, "系统控制台", "已最小化到托盘，双击图标可恢复。", ToolTipIcon.Info);
                }
            }
        }

        // ------------------------------------------------------------- refresh

        void OnTick(object sender, EventArgs e)
        {
            Snapshot s;
            lock (_lock) { s = _snap; }

            string hot = "--";
            if (s.Zones.Count > 0)
            {
                double mx = 0; string nm = "";
                for (int i = 0; i < s.Zones.Count; i++)
                {
                    if (s.Zones[i].TempC > mx) { mx = s.Zones[i].TempC; nm = s.Zones[i].Label; }
                }
                hot = string.Format(CultureInfo.InvariantCulture, "{0} {1:0.0}°C", nm, mx);
            }

            _tray.Text = "系统控制台  |  " + hot;
            if (_tray.Text.Length > 62) _tray.Text = _tray.Text.Substring(0, 62);

            // The guard must keep working while hidden in the tray.
            // 温度墙先算（闭环、渐进），超温保护后算（二元兜底）。
            // 超温保护一旦接管，温度墙会在下一个 tick 让位，两者不会互相覆盖。
            WallTick(s.MaxZoneTemp);
            GuardTick(s.MaxZoneTemp);
            // 风扇曲线：读的是同一个最高热区温度，和温度墙/超温保护互不干扰
            // （一个管发热量、一个管散热能力），所以放在同一拍里跑。
            string fanMsg = FanCurve.Tick(s.MaxZoneTemp, _fanCfg);
            if (fanMsg != null) Log.Write(fanMsg);

            if (!Visible) return;

            if (s.Zones.Count > 0)
            {
                double m = s.MaxZoneTemp;
                _history.Add(m);
                while (_history.Count > HistoryMax) _history.RemoveAt(0);
            }

            string thr;
            if (s.ThrottleReasons == 0) thr = "节流状态: 正常（无节流）";
            else thr = string.Format(CultureInfo.InvariantCulture,
                     "节流状态: 触发中  原因标志 = 0x{0:X}", s.ThrottleReasons);
            UpdateFanCurveStatus();
            lblThrottle.Text = thr + "    风扇设备: " + s.FanCount + " 个";
            lblThrottle.ForeColor = s.ThrottleReasons == 0 ? CSub : CDanger;

            lblCpu.Text = string.Format(CultureInfo.InvariantCulture,
                "处理器总占用: {0:0.0}%      相对基准性能: {1:0}%      报告频率: {2:0} MHz      逻辑核心: {3}",
                s.CpuPercent, s.PerfPercent, s.FreqMHz, s.Cores.Length);

            lblMem.Text = string.Format(CultureInfo.InvariantCulture,
                "内存: 已用 {0:0.0} GB / 共 {1:0.0} GB   ({2:0.0}%)",
                (s.MemTotalMB - s.MemAvailMB) / 1024.0, s.MemTotalMB / 1024.0, s.MemUsedPercent);

            UpdateFanUi();

            if (s.Error.Length > 0) stStatus.Text = "读取异常: " + s.Error;

            stElev.Text = s.Elevated ? "权限: 管理员（全部功能可用）" : "权限: 普通用户（仅监控可用）";
            stElev.ForeColor = s.Elevated ? CGreen : CWarn;

            pnlZones.Invalidate();
            pnlGraph.Invalidate();
            pnlCores.Invalidate();
            pnlMem.Invalidate();
        }

        // -------------------------------------------------------------- painting

        void PaintZones(object sender, PaintEventArgs e)
        {
            Snapshot s;
            lock (_lock) { s = _snap; }
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            if (s.Zones.Count == 0)
            {
                g.DrawString("未读取到温度数据", fNormal, new SolidBrush(CSub), 4, 8);
                return;
            }

            for (int i = 0; i < s.Zones.Count && i < 2; i++)
            {
                ZoneReading z = s.Zones[i];
                int y = i * 42;
                double crit = z.HasCritical ? z.CriticalC : 105.0;
                double ratio = z.TempC / crit;
                if (ratio < 0) ratio = 0;
                if (ratio > 1.1) ratio = 1.1;

                Color col = CGreen;
                if (z.TempC >= 85) col = CDanger;
                else if (z.TempC >= 70) col = CWarn;

                g.DrawString(z.Label, fNormal, new SolidBrush(CText), 0, y + 12);
                g.DrawString(string.Format(CultureInfo.InvariantCulture, "{0:0.0}", z.TempC),
                    fBig, new SolidBrush(col), 84, y + 2);
                g.DrawString("°C", fNormal, new SolidBrush(col), 168, y + 18);

                int bx = 210, bh = 18, by = y + 12;
                // 进度条宽度跟随面板宽度伸缩，右侧预留临界温度文字的宽度
                int bw = pnlZones.Width - bx - 150;
                if (bw < 100) bw = 100;
                DrawBarTrack(g, new Rectangle(bx, by, bw, bh));
                int fw = (int)(bw * (ratio > 1 ? 1 : ratio));
                DrawBarFill(g, new Rectangle(bx, by, fw, bh),
                            ratio >= 1 ? "div-pbar300-Red.png" : "div-pbar300-Blue.png", col);
                g.DrawRectangle(new Pen(CLine), bx, by, bw, bh);

                string cs = z.HasCritical
                    ? string.Format(CultureInfo.InvariantCulture, "临界 {0:0.0}°C", z.CriticalC)
                    : "临界点未知";
                g.DrawString(cs, fSmall, new SolidBrush(CSub), bx + bw + 10, by + 2);
            }
        }

        /// <summary>
        /// 曲线图上的标注：右对齐贴在 right 位置，并垫一层浅白底。
        /// 右对齐是算出来的而不是写死偏移，所以任何窗口宽度下都不会被裁掉。
        /// </summary>
        void DrawTag(Graphics g, string text, Font f, Color c, float right, float y)
        {
            int tw = TextW(text, f) + 6;
            int th = f.Height + 2;
            int x = (int)right - tw;
            if (x < 2) x = 2;
            int yy = (int)y;
            int bottom = pnlGraph.Height;
            if (yy + th > bottom) yy = Math.Max(1, bottom - th);
            if (yy < 1) yy = 1;
            using (Brush bg = new SolidBrush(Color.FromArgb(230, 255, 255, 255)))
                g.FillRectangle(bg, x, yy, tw, th);
            g.DrawString(text, f, new SolidBrush(c), x + 3, yy + 1);
        }

        void PaintGraph(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            int w = pnlGraph.Width, h = pnlGraph.Height;
            g.FillRectangle(new SolidBrush(Color.FromArgb(249, 250, 252)), 0, 0, w, h);
            g.DrawRectangle(new Pen(CLine), 0, 0, w - 1, h - 1);

            double lo = 30, hi = 100;
            for (int i = 0; i < _history.Count; i++)
            {
                if (_history[i] > hi - 5) hi = _history[i] + 10;
            }
            if (hi > 110) hi = 110;

            using (Pen gp = new Pen(Color.FromArgb(238, 240, 244)))
            {
                for (int t = (int)lo; t <= (int)hi; t += 10)
                {
                    float y = (float)(h - (t - lo) / (hi - lo) * h);
                    g.DrawLine(gp, 34, y, w - 8, y);
                    // 最上和最下两档刻度正好落在画布边缘，直接画会被裁掉半行，夹一下
                    float ty = y - 8;
                    if (ty < 0) ty = 0;
                    if (ty > h - fSmall.Height) ty = h - fSmall.Height;
                    g.DrawString(t + "°", fSmall, new SolidBrush(CSub), 4, ty);
                }
            }

            // 把温度墙目标与超温保护阈值直接画在曲线上：墙在哪里、离当前温度
            // 还有多远，一眼就能看见，不用去对照数字。
            double wallT = (_wallCfg != null && _wallCfg.Enabled) ? _wallCfg.TargetC : -1;
            double guardT = (_guardCfg != null && _guardCfg.Enabled) ? _guardCfg.TriggerC : -1;

            bool hasWall = (wallT > lo && wallT < hi);
            bool hasGuard = (guardT > lo && guardT < hi);
            float wy = 0, gy = 0;

            if (hasWall)
            {
                wy = (float)(h - (wallT - lo) / (hi - lo) * h);
                using (Brush b = new SolidBrush(Color.FromArgb(26, 214, 64, 64)))
                    g.FillRectangle(b, 34, 0, w - 42, wy);      // 墙上方的"越界区"淡红提示
                using (Pen p = new Pen(CGreen, 1f))
                {
                    p.DashStyle = DashStyle.Dash;
                    g.DrawLine(p, 34, wy, w - 8, wy);
                }
            }

            if (hasGuard)
            {
                gy = (float)(h - (guardT - lo) / (hi - lo) * h);
                using (Pen p = new Pen(CDanger, 1f))
                {
                    p.DashStyle = DashStyle.Dot;
                    g.DrawLine(p, 34, gy, w - 8, gy);
                }
            }

            // 两个标注都右对齐，并且强制错开至少一行的高度 —— 目标温度和触发温度
            // 常常只差几度，两条虚线挨在一起时文字会叠成一团。
            string wallTxt = "温度墙 " + wallT.ToString("0", CultureInfo.InvariantCulture) + "°C";
            string guardTxt = "保护 " + guardT.ToString("0", CultureInfo.InvariantCulture) + "°C";
            float wallTy = wy - 16, guardTy = gy + 3;
            if (hasWall && hasGuard && Math.Abs(guardTy - wallTy) < 15) guardTy = wallTy + 15;
            if (wallTy > h - 15) wallTy = h - 15;
            if (guardTy > h - 15) guardTy = h - 15;
            if (wallTy < 1) wallTy = 1;
            if (guardTy < 1) guardTy = 1;
            if (hasWall) DrawTag(g, wallTxt, fSmall, CGreen, w - 8, wallTy);
            if (hasGuard) DrawTag(g, guardTxt, fSmall, CDanger, w - 8, guardTy);

            if (_history.Count < 2)
            {
                g.DrawString("正在采集温度曲线…", fNormal, new SolidBrush(CSub), 40, h / 2 - 8);
                return;
            }

            PointF[] pts = new PointF[_history.Count];
            for (int i = 0; i < _history.Count; i++)
            {
                float x = 34 + (float)i / (HistoryMax - 1) * (w - 42);
                float y = (float)(h - (_history[i] - lo) / (hi - lo) * h);
                if (y < 0) y = 0;
                if (y > h) y = h;
                pts[i] = new PointF(x, y);
            }
            using (Pen p = new Pen(CAccent, 2f))
            {
                p.LineJoin = LineJoin.Round;
                g.DrawLines(p, pts);
            }
            double last = _history[_history.Count - 1];
            g.DrawString(string.Format(CultureInfo.InvariantCulture, "当前 {0:0.0}°C   最近 {1} 秒", last, _history.Count),
                fSmall, new SolidBrush(CSub), 40, 4);
        }

        void PaintCores(object sender, PaintEventArgs e)
        {
            Snapshot s;
            lock (_lock) { s = _snap; }
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            double[] c = s.Cores;
            int w = pnlCores.Width, h = pnlCores.Height;
            g.FillRectangle(new SolidBrush(Color.FromArgb(249, 250, 252)), 0, 0, w, h);
            g.DrawRectangle(new Pen(CLine), 0, 0, w - 1, h - 1);
            if (c == null || c.Length == 0)
            {
                g.DrawString("未获取到逐核数据", fNormal, new SolidBrush(CSub), 6, h / 2 - 8);
                return;
            }
            int n = c.Length;
            float gap = 3f;
            float bw = (w - 16 - gap * (n - 1)) / n;
            if (bw < 3) { bw = 3; gap = 1; }
            // 图例标签占顶上一条，柱子从它下沿开始、编号贴底。用标签实际下沿
            // 而不是写死数值 —— 整体放大后字号变了它也不会压到柱子。
            float top = (lblCoreLegend != null ? lblCoreLegend.Bottom : 20) + 3f;
            float full = h - top - 16f;
            if (full < 8f) full = 8f;
            for (int i = 0; i < n; i++)
            {
                float x = 8 + i * (bw + gap);
                float v = (float)(c[i] / 100.0);
                if (v < 0) v = 0;
                if (v > 1) v = 1;
                float bh = full * v;
                Color col = i < 16 ? CAccent : Color.FromArgb(120, 90, 200);
                g.FillRectangle(new SolidBrush(Color.FromArgb(232, 236, 242)), x, top, bw, full);
                g.FillRectangle(new SolidBrush(col), x, top + (full - bh), bw, bh);
                if (bw >= 10)
                {
                    string lbl = i.ToString(CultureInfo.InvariantCulture);
                    g.DrawString(lbl, fSmall, new SolidBrush(CSub),
                                 x + bw / 2 - TextW(lbl, fSmall) / 2f, top + full + 2);
                }
            }
        }

        void PaintMem(object sender, PaintEventArgs e)
        {
            Snapshot s;
            lock (_lock) { s = _snap; }
            Graphics g = e.Graphics;
            int w = pnlMem.Width, h = pnlMem.Height;
            double p = s.MemUsedPercent;
            if (p < 0) p = 0; if (p > 100) p = 100;
            DrawBarTrack(g, new Rectangle(0, 0, w, h));
            Color col = p >= 90 ? CDanger : (p >= 75 ? CWarn : CAccent);
            string bar = p >= 90 ? "div-pbar300-Red.png"
                       : (p >= 75 ? "div-pbar300-contrast.png" : "div-pbar300-Blue.png");
            DrawBarFill(g, new Rectangle(0, 0, (int)(w * p / 100.0), h), bar, col);
            g.DrawRectangle(new Pen(CLine), 0, 0, w - 1, h - 1);
        }

        // ---------------------------------------------------------- power logic

        // ------------------------------------------------------------ 键盘背光

        /// <summary>
        /// 按 0..255 的 RGB 设置键盘背光。内部走原厂协议：写 0x769/0x76A/0x76B
        /// 电平，再置 0x767 的 bit5 提交。
        /// </summary>
        void ApplyLight(Color c, bool remember)
        {
            // 选颜色意味着要盖掉硬件彩虹：先关掉它，否则写进去的电平会被固件忽略
            if (chkHwRainbow != null && chkHwRainbow.Checked)
            {
                _loading = true;
                try { chkHwRainbow.Checked = false; }
                finally { _loading = false; }
            }
            Ec.KbColor.SetHardwareRainbow(false);
            Ec.KbColor.ClearEffectState();

            string err = Ec.KbColor.ApplyRgb(c.R, c.G, c.B, true);
            if (err != null)
            {
                lblLightStatus.Text = "设置失败：" + err;
                lblLightStatus.ForeColor = CDanger;
                Log.Write("键盘背光设置失败: " + err);
                return;
            }
            _lightR = c.R; _lightG = c.G; _lightB = c.B;
            if (chkBlink != null && chkBlink.Checked) StartBlink();   // 换色后接着闪
            if (remember) SaveLightConfig();
            RefreshLightUi();
            Log.Write(string.Format(CultureInfo.InvariantCulture,
                "键盘背光 -> RGB({0},{1},{2})  {3}", c.R, c.G, c.B, Ec.KbColor.LevelText(c.R, c.G, c.B)));
        }

        /// <summary>
        /// 生成调色板配色。上排是 24 个全亮度色相 + 11 级灰阶，下排是同样色相的
        /// 压暗版本 + 11 级暗灰阶。
        /// 注意：背光电平只有 1..50，且按 R/5、G/6、B/6 量化，所以极暗的颜色会
        /// 被压到最低档，这里刻意避开纯黑（纯黑相当于"最暗"而不是"关灯"）。
        /// </summary>
        static Color[] BuildLightPalette(int cols)
        {
            int hueCount = cols - 11;
            Color[] list = new Color[cols * 2];
            for (int i = 0; i < hueCount; i++)
            {
                double hue = i * (360.0 / hueCount);
                list[i] = HsvToRgb(hue, 1.0, 1.0);
                list[cols + i] = HsvToRgb(hue, 1.0, 0.55);
            }
            int[] grays = new int[] { 16, 40, 64, 88, 112, 136, 160, 184, 208, 232, 255 };
            for (int i = 0; i < grays.Length && hueCount + i < cols; i++)
            {
                int g = grays[i];
                list[hueCount + i] = Color.FromArgb(g, g, g);
                int d = g * 55 / 100;
                list[cols + hueCount + i] = Color.FromArgb(d, d, d);
            }
            return list;
        }

        static Color HsvToRgb(double h, double s, double v)
        {
            double hh = h / 60.0;
            int i = (int)Math.Floor(hh) % 6;
            if (i < 0) i += 6;
            double f = hh - Math.Floor(hh);
            double p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
            double r, g, b;
            switch (i)
            {
                case 0: r = v; g = t; b = p; break;
                case 1: r = q; g = v; b = p; break;
                case 2: r = p; g = v; b = t; break;
                case 3: r = p; g = q; b = v; break;
                case 4: r = t; g = p; b = v; break;
                default: r = v; g = p; b = q; break;
            }
            return Color.FromArgb((int)Math.Round(r * 255), (int)Math.Round(g * 255), (int)Math.Round(b * 255));
        }

        /// <summary>找出和某个实际颜色最接近的调色板格子（用于高亮当前颜色）。</summary>
        int NearestSwatch(int r, int g, int b)
        {
            if (paletteLight == null || paletteLight.Swatches == null) return -1;
            Color[] sw = paletteLight.Swatches;
            int best = -1;
            long bestD = long.MaxValue;
            for (int i = 0; i < sw.Length; i++)
            {
                long dr = sw[i].R - r, dg = sw[i].G - g, db = sw[i].B - b;
                long d = dr * dr + dg * dg + db * db;
                if (d < bestD) { bestD = d; best = i; }
            }
            return best;
        }

        void OnSwatchClick(object sender, EventArgs e)
        {
            using (ColorDialog d = new ColorDialog())
            {
                d.FullOpen = true;
                d.AnyColor = true;
                if (_lightR >= 0) d.Color = Color.FromArgb(255, _lightR, _lightG, _lightB);
                if (d.ShowDialog(this) == DialogResult.OK)
                    ApplyLight(d.Color, chkLightRemember.Checked);
            }
        }

        /// <summary>恢复出厂色：读 EC 里的 0x76C/0x76D/0x76E（原厂 GetEcDefaultRGB），再写回。</summary>
        void OnLightDefaultClick(object sender, EventArgs e)
        {
            int dr, dg, db;
            if (!Ec.KbColor.ReadDefaults(out dr, out dg, out db))
            {
                lblLightStatus.Text = "读取出厂色失败：" + Ec.LastError;
                lblLightStatus.ForeColor = CDanger;
                return;
            }
            string err = Ec.KbColor.ApplyLevels(dr, dg, db, true);
            if (err != null)
            {
                lblLightStatus.Text = "设置失败：" + err;
                lblLightStatus.ForeColor = CDanger;
                return;
            }
            _lightR = Ec.KbColor.RFromLevel(dr);
            _lightG = Ec.KbColor.GFromLevel(dg);
            _lightB = Ec.KbColor.BFromLevel(db);
            if (chkHwRainbow != null && chkHwRainbow.Checked)
            {
                _loading = true;
                try { chkHwRainbow.Checked = false; }
                finally { _loading = false; }
            }
            Ec.KbColor.SetHardwareRainbow(false);
            Ec.KbColor.ClearEffectState();
            if (chkBlink != null && chkBlink.Checked) StartBlink();
            if (chkLightRemember.Checked) SaveLightConfig();
            RefreshLightUi();
            Log.Write(string.Format(CultureInfo.InvariantCulture,
                "键盘背光 恢复出厂电平 {0}/{1}/{2}", dr, dg, db));
        }

        void OnLightRememberChanged(object sender, EventArgs e)
        {
            if (chkLightRemember.Checked)
            {
                if (_lightR >= 0) SaveLightConfig();
            }
            else
            {
                Ec.KbColor.ClearSaved();
            }
        }

        /// <summary>把 EC 里的真实电平回显到色块和状态文字上（色块显示的是硬件实际会发出的颜色）。</summary>
        void RefreshLightUi()
        {
            if (btnSwatch == null || lblLightStatus == null) return;
            int lr, lg, lb;
            if (!Ec.KbColor.ReadLevels(out lr, out lg, out lb))
            {
                lblLightStatus.Text = "EC 不可用" + (Ec.LastError.Length > 0 ? "：" + Ec.LastError : "");
                lblLightStatus.ForeColor = CSub;
                return;
            }
            int er = Ec.KbColor.RFromLevel(lr);
            int eg = Ec.KbColor.GFromLevel(lg);
            int eb = Ec.KbColor.BFromLevel(lb);
            btnSwatch.BackColor = Color.FromArgb(er, eg, eb);
            int si = NearestSwatch(er, eg, eb);
            if (paletteLight.SelectedIndex != si)
            {
                paletteLight.SelectedIndex = si;
                paletteLight.Invalidate();
            }
            string t = string.Format(CultureInfo.InvariantCulture,
                "当前 {0}/{1}/{2} ≈ RGB({3},{4},{5})", lr, lg, lb, er, eg, eb);
            int dr, dg, db;
            if (Ec.KbColor.ReadDefaults(out dr, out dg, out db))
                t += string.Format(CultureInfo.InvariantCulture, "   出厂 {0}/{1}/{2}", dr, dg, db);
            lblLightStatus.Text = t;
            lblLightStatus.ForeColor = CSub;
        }

        void RefreshPowerUi()
        {
            _loading = true;
            try
            {
                PowerState st = Power.Read();
                chkTurbo.Checked = st.TurboEnabled;
                cmbMode.SelectedIndex = st.Mode >= 0 && st.Mode <= 2 ? st.Mode : 0;
                cmbCool.SelectedIndex = st.CoolingPolicy == Power.COOLING_ACTIVE ? 1 : 0;
                // 温度墙/超温保护正在人为压低上限时，实时值不是用户的设定值，
                // 不能拿它覆盖滑块 —— 否则每刷新一次基线就往下掉一档，形成
                // "越压越低"的棘轮效应。
                if (_wallApplied <= 0 && !_guardActive)
                {
                    tbMax.Value = Clamp(st.MaxState, tbMax.Minimum, tbMax.Maximum);
                    _wallBaseState = tbMax.Value;
                }
                tbMin.Value = Clamp(st.MinState, tbMin.Minimum, tbMin.Maximum);
                // lblMaxVal / lblMinVal 现在是滑块右端的 "%" 单位标签；数值本身由
                // numMax / numMin 显示，并随上面两个赋值自动同步过去。
                btnElevate.Visible = !Elevation.IsElevated();
                btnApply.Enabled = true;
            }
            finally { _loading = false; }
            UpdatePresetLabel();
            RefreshAutoStartUi();
            RefreshLightUi();
        }

        static int Clamp(int v, int lo, int hi)
        {
            if (v < lo) return lo;
            if (v > hi) return hi;
            return v;
        }

        /// <summary>设计坐标系 → 实际像素。界面所有布局数值都写成"设计值"，
        /// 这里统一乘上用户设定的缩放系数。</summary>
        // S()/Sf() 必须是静态的：嵌套类 Row 也要用它按当前缩放换算行高，
        // 而嵌套类拿不到外层实例。缩放比例在 BuildUi 开头同步到 _sPct。
        static int _sPct = 100;
        static float _dpiK = 1f;
        // 设计像素 → 物理像素 = 用户缩放系数 × 系统 DPI 系数。
        // 只乘前者的话，高 DPI 屏上"字按 DPI 放大、框不放大"，文字就会被上下切掉。
        static int S(int v) { return (int)Math.Round(v * (_sPct / 100.0) * _dpiK); }
        static float Sf(float v) { return (float)(v * (_sPct / 100.0) * _dpiK); }

        /// <summary>按当前缩放系数重建这套字体。改系数后必须重新调用。</summary>
        void ApplyScaledFonts()
        {
            float k = _uiPct / 100f;
            fTitle = new Font("Microsoft YaHei UI", 10F * k, FontStyle.Bold);
            fBig = new Font("Microsoft YaHei UI", 20F * k, FontStyle.Bold);
            fNormal = new Font("Microsoft YaHei UI", 9F * k);
            fSmall = new Font("Microsoft YaHei UI", 8F * k);
            fSect = new Font("Microsoft YaHei UI", 9F * k, FontStyle.Bold);   // 卡片内分区小标题
            // 页名水印：右下角那块低对比大字，比正文大一倍多，但不抢视线
            fMark = new Font("Microsoft YaHei UI", 24F * k, FontStyle.Bold);
        }

        void UpdatePresetLabel()
        {
            if (_loading) return;
            List<Power.Preset> ps = Power.Presets();
            string best = "";
            int bestScore = -1;
            for (int i = 0; i < ps.Count; i++)
            {
                Power.Preset p = ps[i];
                int score = 0;
                if (p.Turbo == chkTurbo.Checked) score++;
                if (p.Mode == cmbMode.SelectedIndex) score++;
                if (p.Cooling == (cmbCool.SelectedIndex == 1 ? Power.COOLING_ACTIVE : Power.COOLING_PASSIVE)) score++;
                if (Math.Abs(p.MaxState - tbMax.Value) <= 2) score++;
                if (Math.Abs(p.MinState - tbMin.Value) <= 3) score++;
                if (score > bestScore) { bestScore = score; best = p.Key; }
            }
            _lastPreset = bestScore >= 4 ? best : "";
            string txt = "当前配置接近：--（自定义）";
            for (int i = 0; i < ps.Count; i++)
            {
                if (ps[i].Key == _lastPreset) txt = "当前配置接近：" + ps[i].Name + "   " + ps[i].Desc;
            }
            lblPresetDesc.Text = txt;
            HighlightPresetButtons();
        }

        void HighlightPresetButtons()
        {
            List<Power.Preset> ps = Power.Presets();
            Button[] bs = new Button[] { btnPerf, btnBalanced, btnQuiet };
            for (int i = 0; i < bs.Length; i++)
            {
                bool on = (ps[i].Key == _lastPreset);
                bs[i].FlatStyle = FlatStyle.System;
                bs[i].Font = on ? fTitle : fNormal;
                bs[i].Text = on ? "● " + ps[i].Name : ps[i].Name;
            }
        }

        // ------------------------------------------------------------ autostart

        void OnAutoStartChanged(object sender, EventArgs e)
        {
            if (_loading) return;
            ApplyAutoStart(chkAutoStart.Checked);
        }

        void ApplyAutoStart(bool enable)
        {
            string r = enable
                ? AutoStart.Enable(Application.ExecutablePath)
                : AutoStart.Disable();
            bool ok = (r == "OK");
            Log.Write("AutoStart " + (enable ? "on" : "off") + " -> " + r);

            if (ok)
            {
                stStatus.Text = enable ? "已启用开机自启" : "已关闭开机自启";
            }
            else
            {
                MessageBox.Show(this,
                    (enable ? "启用" : "关闭") + "开机自启失败：\r\n\r\n" + r + "\r\n\r\n" +
                    "该操作会登记一个 Windows 计划任务，需要管理员权限。\r\n" +
                    "请点击「以管理员身份重启」后重试——程序当前仍正常运行，不受影响。",
                    "系统控制台", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            RefreshAutoStartUi();
        }

        // Single source of truth for the autostart UI: the scheduled task itself.
        void RefreshAutoStartUi()
        {
            bool on = AutoStart.IsEnabled();
            bool prev = _loading;
            _loading = true;
            try { if (chkAutoStart != null) chkAutoStart.Checked = on; }
            finally { _loading = prev; }
            if (_trayAuto != null) _trayAuto.Checked = on;
            if (stAuto != null) stAuto.Text = "开机自启: " + (on ? "已启用" : "未启用") + "   ";
        }

        void ApplyPresetByKey(string key)
        {
            Power.Preset p = Power.FindPreset(key);
            if (p == null) return;
            GuardUserOverride();
            WallHandBack("切换场景");
            string rep = Power.ApplyPreset(p);
            Log.Write("ApplyPreset " + key + Environment.NewLine + rep);
            bool ok = rep.IndexOf("OK") >= 0;
            stStatus.Text = "已应用场景: " + p.Name + (Elevation.IsElevated() ? "" : "（部分设置需要管理员权限）");
            RefreshPowerUi();
            if (_tray != null && !Visible) _tray.ShowBalloonTip(1200, "系统控制台", "已切换到 " + p.Name, ToolTipIcon.Info);
            ShowReport("应用场景：" + p.Name, rep);
        }

        void OnApplyClick(object sender, EventArgs e)
        {
            GuardUserOverride();
            WallHandBack("手动应用");
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendLine("TURBO : " + Power.SetTurbo(chkTurbo.Checked));
            sb.AppendLine("MODE  : " + Power.SetMode(cmbMode.SelectedIndex));
            sb.AppendLine("COOL  : " + Power.SetCooling(cmbCool.SelectedIndex == 1 ? Power.COOLING_ACTIVE : Power.COOLING_PASSIVE));
            sb.AppendLine("MAX   : " + Power.SetMaxState(tbMax.Value));
            sb.AppendLine("MIN   : " + Power.SetMinState(tbMin.Value));
            Log.Write("Manual apply" + Environment.NewLine + sb.ToString());
            RefreshPowerUi();
            stStatus.Text = "设置已应用";
            ShowReport("手动应用设置", sb.ToString());
        }

        // 最小处理器状态的常用档位。只写这一个参数，走和「应用设置」里
        // 同一套 Power.SetMinState，所以结果完全一致，而且立即生效。
        void SetMinQuick(int value)
        {
            tbMin.Value = Clamp(value, tbMin.Minimum, tbMin.Maximum);
            string r = Power.SetMinState(tbMin.Value);
            RefreshPowerUi();
            stStatus.Text = "最小处理器状态 → " + tbMin.Value + "%：" + r;
            Log.Write("SetMinQuick " + tbMin.Value + "% -> " + r);
        }

        void ShowReport(string title, string body)
        {
            bool bad = body.IndexOf("ERR") >= 0 || body.IndexOf("EX ") >= 0 || body.IndexOf("TIMEOUT") >= 0;
            if (!bad)
            {
                return; // silent on success
            }
            MessageBox.Show(this,
                body + Environment.NewLine + Environment.NewLine +
                "提示：以管理员身份运行本程序才能修改电源参数。\r\n" +
                "（电源模式切换不需要管理员权限）",
                title + " - 存在问题", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        // ------------------------------------------------------------- hotkeys

        void ApplyHotkeyConfig(HotkeyStore.Config cfg)
        {
            _hotkeyCfg = cfg;
            string rep;
            if (cfg.Enabled)
            {
                rep = _hotkeys.Apply(cfg.Bindings);
            }
            else
            {
                _hotkeys.UnregisterAll();
                rep = "全局快捷键已关闭";
            }
            if (stHot != null)
            {
                stHot.Text = cfg.Enabled
                    ? ("快捷键: " + _hotkeys.ActiveCount + "/" + cfg.Bindings.Count + " 生效   ")
                    : "快捷键: 已关闭   ";
            }
            Log.Write("ApplyHotkeyConfig enabled=" + cfg.Enabled + Environment.NewLine + rep);
        }

        void OnHotkeySettingsClick(object sender, EventArgs e)
        {
            using (HotkeyForm f = new HotkeyForm(_hotkeyCfg))
            {
                if (f.ShowDialog(this) != DialogResult.OK) return;
                HotkeyStore.Save(f.Result);
                ApplyHotkeyConfig(f.Result);
                stStatus.Text = f.Result.Enabled
                    ? "快捷键设置已应用（组合被占用时会注册失败，详见日志）"
                    : "已关闭全局快捷键";
            }
        }

        // ------------------------------------------------------- EC / 风扇强冷

        // 风扇转速与模式来自原生 EC 直读（见 src/Ec.cs），不经过任何 OEM 组件。
        void UpdateFanUi()
        {
            if (lblFan == null) return;
            Ec.FanReadout r = _fanSnap;         // 后台线程每秒刷新一次，这里只显示
            if (r == null)
            {
                lblFan.Text = "风扇: 读取中…";
                lblFan.ForeColor = CSub;
                return;
            }
            if (r.Ok)
            {
                lblFan.Text = string.Format(CultureInfo.InvariantCulture,
                    "风扇 {0} / {1} RPM   占空比 {2}/{3}   模式 {4}",
                    r.Fan1Rpm, r.Fan2Rpm, r.Fan1Duty, r.Fan2Duty, r.ModeName);
                lblFan.ForeColor = r.Boosted ? CDanger : CAccent;
                if (btnFanBoost != null)
                {
                    btnFanBoost.Text = r.Boosted ? "强冷已开启" : "一键强冷";
                    btnFanBoost.ForeColor = r.Boosted ? CDanger : CText;
                }
            }
            else
            {
                lblFan.Text = "风扇: EC 不可用（" + (r.Error.Length > 0 ? r.Error : "设备未就绪") + "）";
                lblFan.ForeColor = CSub;
            }
        }

        void OnFanBoostClick(object sender, EventArgs e)
        {
            string msg = Ec.FanBoost.Toggle();
            // 手动切换后强冷归用户所有，温度墙不再自动接管这一次
            _wallBoostByWall = false;
            Log.Write("FanBoost: " + msg);
            stStatus.Text = msg;
            UpdateFanUi();
        }

        void OnHotkeyAction(string action)
        {
            Log.Write("Hotkey triggered: " + action);
            if (action == "cycle")
            {
                List<Power.Preset> ps = Power.Presets();
                PowerState st = Power.Read();
                int idx = ClosestPresetIndex(st, ps);
                int next = (idx + 1) % ps.Count;
                stStatus.Text = "快捷键循环切换 -> " + ps[next].Name;
                ApplyPresetByKey(ps[next].Key);
                return;
            }
            if (action == "fanboost")
            {
                stStatus.Text = "快捷键 " + Ec.FanBoost.Toggle();
                UpdateFanUi();
                return;
            }
            stStatus.Text = "快捷键触发 -> " + action;
            ApplyPresetByKey(action);
        }

        static int ClosestPresetIndex(PowerState st, List<Power.Preset> ps)
        {
            int best = 0, bestScore = -1;
            for (int i = 0; i < ps.Count; i++)
            {
                int s = 0;
                if (ps[i].Turbo == st.TurboEnabled) s++;
                if (ps[i].Mode == st.Mode) s++;
                if (ps[i].Cooling == st.CoolingPolicy) s++;
                if (Math.Abs(ps[i].MaxState - st.MaxState) <= 2) s++;
                if (Math.Abs(ps[i].MinState - st.MinState) <= 3) s++;
                if (s > bestScore) { bestScore = s; best = i; }
            }
            return best;
        }

        // -------------------------------------------------------- thermal guard

        void OnGuardEnableChanged(object sender, EventArgs e)
        {
            if (_loading) return;
            _guardCfg.Enabled = chkGuard.Checked;
            GuardStore.Save(_guardCfg);
            if (!_guardCfg.Enabled && _guardActive) GuardRelease("保护已关闭");
            _guardBlocked = false;
            UpdateGuardUi();
            stStatus.Text = _guardCfg.Enabled ? "超温保护已启用" : "超温保护已关闭";
        }

        void OnGuardValueChanged(object sender, EventArgs e)
        {
            if (_loading || _guardCfg == null) return;
            double t = (double)numTrigger.Value;
            double r = (double)numRelease.Value;

            // Enforce a gap so the guard cannot flap around a single temperature.
            if (r >= t - 3)
            {
                r = t - 5;
                if (r < (double)numRelease.Minimum) r = (double)numRelease.Minimum;
                bool prev = _loading;
                _loading = true;
                try { numRelease.Value = (decimal)r; }
                finally { _loading = prev; }
            }

            _guardCfg.TriggerC = t;
            _guardCfg.ReleaseC = r;
            _guardCfg.LimitMaxState = (int)numLimit.Value;
            GuardStore.Save(_guardCfg);
            UpdateGuardUi();
        }

        // ------------------------------------------------------------ 温度墙
        //
        // 与超温保护的区别：超温保护是"越过阈值才动手"的二元开关，会在触发点附近
        // 来回震荡；温度墙是闭环连续控制，把"最高温度"当目标，越接近目标越早开始
        // 收力，使温度收敛在目标附近。
        //
        // 安全性：所有分支只做"降低功耗"，任何路径都不会提高处理器的发热；下限由
        // FloorState 兜住，不会把机器压到不可用。

        void OnWallEnableChanged(object sender, EventArgs e)
        {
            if (_loading) return;
            _wallCfg.Enabled = chkWall.Checked;
            WallStore.Save(_wallCfg);
            if (!_wallCfg.Enabled) WallHandBack("温度墙已关闭");
            UpdateWallUi();
            stStatus.Text = _wallCfg.Enabled
                ? "温度墙已启用：目标 " + _wallCfg.TargetC.ToString("0") + "°C"
                : "温度墙已关闭，已恢复你设定的处理器上限";
        }

        void OnWallValueChanged(object sender, EventArgs e)
        {
            if (_loading || _wallCfg == null) return;
            _wallCfg.TargetC = (double)numWallTarget.Value;
            _wallCfg.DropTurbo = chkWallTurbo.Checked;
            _wallCfg.LinkFanBoost = chkWallBoost.Checked;
            WallStore.Save(_wallCfg);
            UpdateWallUi();
        }

        // 把控制权交还给用户设定的值（用户改了滑块 / 切了场景 / 关了温度墙）
        void WallHandBack(string why)
        {
            int baseState = _wallBaseState > 0 ? _wallBaseState : tbMax.Value;
            if (_wallApplied > 0)
            {
                Power.SetMaxState(baseState);
                Log.Write("ThermalWall hand-back (" + why + ") -> max state " + baseState + "%");
                _wallApplied = -1;
            }
            _wallActive = false;
            if (_wallCfg.BaseState != 0) { _wallCfg.BaseState = 0; WallStore.Save(_wallCfg); }
            if (_wallTurboDropped)
            {
                Power.SetTurbo(true);
                _wallTurboDropped = false;
            }
            if (_wallBoostByWall)
            {
                Ec.FanBoost.Disable();
                _wallBoostByWall = false;
                UpdateFanUi();
            }
            RefreshPowerUi();
            UpdateWallUi();
        }

        void WallTick(double tempC)
        {
            if (_wallCfg == null || tempC <= 0 || !_wallCfg.Enabled) return;
            if (_guardActive) return;              // 超温保护接管时让位

            int baseState = _wallBaseState > 0 ? _wallBaseState : tbMax.Value;
            int cur = _wallApplied > 0 ? _wallApplied : baseState;
            int next = cur;

            // 上次运行在压制期间退出时，实时值会是那个被压低的上限。温度已经降
            // 下来就先把用户记录的基线恢复回去，避免"重启一次永久降一档"。
            if (_wallCfg.BaseState > 0 && _wallCfg.BaseState != baseState &&
                tempC <= _wallCfg.TargetC - _wallCfg.HysteresisC && Elevation.IsElevated())
            {
                Power.SetMaxState(_wallCfg.BaseState);
                Log.Write("ThermalWall: 恢复上次被压制的基线 " + _wallCfg.BaseState + "%");
                _wallBaseState = _wallCfg.BaseState;
                _loading = true;
                try { tbMax.Value = Clamp(_wallCfg.BaseState, tbMax.Minimum, tbMax.Maximum); }
                finally { _loading = false; }
                baseState = _wallCfg.BaseState;
                cur = baseState;
                next = cur;
            }

            if (tempC >= _wallCfg.TargetC)
            {
                if (Elevation.IsElevated())
                {
                    double over = tempC - _wallCfg.TargetC;
                    int step = (int)Math.Ceiling(_wallCfg.StepPercent * (1.0 + over / 5.0));
                    next = Math.Max(_wallCfg.FloorState, Math.Min(baseState, cur - step));
                    if (next != cur)
                    {
                        if (_wallCfg.BaseState != baseState)
                        {
                            _wallCfg.BaseState = baseState;   // 记住用户的基线
                            WallStore.Save(_wallCfg);
                        }
                        Power.SetMaxState(next);
                        _wallApplied = next;
                        Log.Write(string.Format(CultureInfo.InvariantCulture,
                            "ThermalWall: {0:0.0}C over target -> max state {1}%", tempC, next));
                    }
                }
                _wallActive = true;
            }
            else if (tempC <= _wallCfg.TargetC - _wallCfg.HysteresisC && cur < baseState)
            {
                if (Elevation.IsElevated())
                {
                    next = Math.Min(baseState, cur + _wallCfg.StepPercent);
                    if (next != cur)
                    {
                        Power.SetMaxState(next);
                        _wallApplied = next;
                        Log.Write(string.Format(CultureInfo.InvariantCulture,
                            "ThermalWall: {0:0.0}C cooled -> max state {1}%", tempC, next));
                    }
                }
                if (next >= baseState) { _wallApplied = -1; _wallActive = false; }
            }
            else
            {
                _wallActive = false;
            }

            // 明显超温时额外关闭睿频（回来再打开）
            if (_wallCfg.DropTurbo && Elevation.IsElevated())
            {
                bool want = tempC > _wallCfg.TargetC + 5;
                if (want && !_wallTurboDropped)
                {
                    Power.SetTurbo(false);
                    _wallTurboDropped = true;
                    RefreshPowerUi();
                }
                else if (!want && _wallTurboDropped && tempC <= _wallCfg.TargetC - _wallCfg.HysteresisC)
                {
                    Power.SetTurbo(true);
                    _wallTurboDropped = false;
                    RefreshPowerUi();
                }
            }

            WallFanLink(tempC);
            UpdateWallUi();
        }

        // 接近目标时自动开强冷（原生 EC）。只关闭"由温度墙自己开的那一次"，
        // 不会覆盖用户手动切换的强冷状态。
        void WallFanLink(double tempC)
        {
            if (_wallCfg == null || !_wallCfg.LinkFanBoost) return;
            if (!Ec.IsOpen && !Ec.Open()) return;

            double on = _wallCfg.TargetC - _wallCfg.LinkMarginC;
            double off = _wallCfg.TargetC - _wallCfg.HysteresisC - 2;

            if (!_wallBoostByWall && tempC >= on)
            {
                string r = Ec.FanBoost.Enable();
                _wallBoostByWall = true;
                Log.Write("ThermalWall: 联动强冷开启 (" +
                          tempC.ToString("0.0", CultureInfo.InvariantCulture) + "C) - " + r);
                UpdateFanUi();
            }
            else if (_wallBoostByWall && tempC <= off)
            {
                Ec.FanBoost.Disable();
                _wallBoostByWall = false;
                Log.Write("ThermalWall: 联动强冷关闭");
                UpdateFanUi();
            }
        }

        void UpdateWallUi()
        {
            if (chkWall == null) return;
            if (!_wallCfg.Enabled) chkWall.ForeColor = CText;
            else if (_wallActive) chkWall.ForeColor = CDanger;
            else chkWall.ForeColor = CGreen;
            UpdateGuardUi();       // 状态行由两套机制合并显示
        }

        void RefreshWallUi()
        {
            bool prev = _loading;
            _loading = true;
            try
            {
                chkWall.Checked = _wallCfg.Enabled;
                numWallTarget.Value = Clamp((int)Math.Round(_wallCfg.TargetC),
                                            (int)numWallTarget.Minimum, (int)numWallTarget.Maximum);
                chkWallTurbo.Checked = _wallCfg.DropTurbo;
                chkWallBoost.Checked = _wallCfg.LinkFanBoost;
            }
            finally { _loading = prev; }
            UpdateWallUi();
        }

        // Runs on every tick, including while hidden in the tray.
        void GuardTick(double tempC)
        {
            if (_guardCfg == null || tempC <= 0) return;

            if (!_guardCfg.Enabled)
            {
                if (_guardActive) GuardRelease("保护已关闭");
                return;
            }
            if (_guardActive)
            {
                if (tempC <= _guardCfg.ReleaseC) GuardRelease("温度已回落");
                return;
            }
            if (_guardBlocked)
            {
                if (tempC < _guardCfg.ReleaseC - 3) { _guardBlocked = false; UpdateGuardUi(); }
                return;
            }
            if (!Elevation.IsElevated()) return;      // cannot write power settings
            if (tempC >= _guardCfg.TriggerC) GuardEngage(tempC);
        }

        void GuardEngage(double tempC)
        {
            _guardSaved = Power.Read();
            _guardActive = true;
            string rep = Power.ApplyLimits(_guardCfg);
            Log.Write("ThermalGuard ENGAGED at " + tempC.ToString("0.0", CultureInfo.InvariantCulture) +
                      " C" + Environment.NewLine + rep);
            stStatus.Text = "超温保护已触发：限功耗降温中（" + tempC.ToString("0.0") + "°C）";
            if (_tray != null)
            {
                _tray.ShowBalloonTip(2500, "系统控制台 · 超温保护",
                    "温度 " + tempC.ToString("0.0") + "°C 超过阈值，已自动把处理器上限降到 " +
                    _guardCfg.LimitMaxState + "% 以降低发热。", ToolTipIcon.Warning);
            }
            RefreshPowerUi();
            UpdateGuardUi();
        }

        void GuardRelease(string why)
        {
            if (!_guardActive) return;
            _guardActive = false;
            string rep = Power.RestoreState(_guardSaved);
            _guardSaved = null;
            Log.Write("ThermalGuard RELEASED (" + why + ")" + Environment.NewLine + rep);
            stStatus.Text = "超温保护已解除：" + why + "，已恢复原设置";
            if (_tray != null)
            {
                _tray.ShowBalloonTip(2000, "系统控制台 · 超温保护",
                    "温度已回落，已恢复原有性能设置。", ToolTipIcon.Info);
            }
            RefreshPowerUi();
            UpdateGuardUi();
        }

        // The user changed the mode by hand: stop overriding them, and re-arm only
        // after the machine has actually cooled down.
        void GuardUserOverride()
        {
            if (!_guardActive) return;
            _guardActive = false;
            _guardBlocked = true;
            _guardSaved = null;
            Log.Write("ThermalGuard paused by user override");
            UpdateGuardUi();
        }

        void UpdateGuardUi()
        {
            if (chkGuard == null) return;
            // The checkbox caption stays short so it always fits; state is carried
            // by colour plus the status line underneath.
            if (_guardActive) chkGuard.ForeColor = CDanger;
            else if (_guardBlocked) chkGuard.ForeColor = CWarn;
            else chkGuard.ForeColor = CText;

            if (lblWallStatus == null && lblGuardStatus == null) return;

            // ---- 温度墙 ----
            string w;
            if (!_wallCfg.Enabled) w = "温度墙 关闭";
            else if (!Elevation.IsElevated()) w = "温度墙 需管理员权限";
            else if (_wallActive) w = "温度墙 压制中 → 上限 " + (_wallApplied > 0 ? _wallApplied : tbMax.Value) + "%";
            else w = "温度墙 监控中（目标 " + _wallCfg.TargetC.ToString("0") + "°C）";
            if (_wallCfg.Enabled && _wallBoostByWall) w += " · 强冷已联动";

            // ---- 超温保护 ----
            string g;
            if (!_guardCfg.Enabled) g = "超温保护 关闭";
            else if (_guardActive) g = "超温保护 已触发 → 上限 " + _guardCfg.LimitMaxState + "%";
            else if (_guardBlocked) g = "超温保护 已暂停（手动改过模式）";
            else if (!Elevation.IsElevated()) g = "超温保护 需管理员权限";
            else g = "超温保护 待命（" + _guardCfg.TriggerC.ToString("0") + "°C）";

            if (lblWallStatus != null)
            {
                lblWallStatus.Text = w;
                lblWallStatus.ForeColor = _wallActive ? CDanger : CSub;
            }
            if (lblGuardStatus != null)
            {
                lblGuardStatus.Text = g;
                lblGuardStatus.ForeColor = _guardActive ? CDanger : (_guardBlocked ? CWarn : CSub);
            }
        }

        void RefreshGuardUi()
        {
            bool prev = _loading;
            _loading = true;
            try
            {
                chkGuard.Checked = _guardCfg.Enabled;
                numTrigger.Value = Clamp((int)Math.Round(_guardCfg.TriggerC), (int)numTrigger.Minimum, (int)numTrigger.Maximum);
                numRelease.Value = Clamp((int)Math.Round(_guardCfg.ReleaseC), (int)numRelease.Minimum, (int)numRelease.Maximum);
                numLimit.Value = Clamp(_guardCfg.LimitMaxState, (int)numLimit.Minimum, (int)numLimit.Maximum);
            }
            finally { _loading = prev; }
            UpdateGuardUi();
        }

        // ------------------------------------------------------------ 键盘灯效

        /// <summary>把当前的 颜色 + 硬件彩虹 + 闪烁 一起存盘（只在勾了「记住颜色」时）。</summary>
        void SaveLightConfig()
        {
            if (chkLightRemember == null || !chkLightRemember.Checked || _lightR < 0) return;
            Ec.KbColor.SaveSaved(_lightR, _lightG, _lightB,
                chkHwRainbow != null && chkHwRainbow.Checked ? 1 : 0,
                chkBlink != null && chkBlink.Checked ? 1 : 0,
                _blinkRate);
        }

        void OnBlinkChanged(object sender, EventArgs e)
        {
            if (_loading || chkBlink == null) return;
            if (cmbBlinkRate != null) _blinkRate = Math.Max(0, Math.Min(2, cmbBlinkRate.SelectedIndex));

            if (chkBlink.Checked)
            {
                // 与硬件彩虹互斥：彩虹会盖掉写进去的颜色，闪了也看不见
                if (chkHwRainbow != null && chkHwRainbow.Checked)
                {
                    _loading = true;
                    try { chkHwRainbow.Checked = false; }
                    finally { _loading = false; }
                    Ec.KbColor.SetHardwareRainbow(false);
                }
                StartBlink();
            }
            else StopBlink();

            SaveLightConfig();
            Log.Write("闪烁 -> " + (chkBlink.Checked
                ? "开 / " + new string[] { "慢", "中", "快" }[_blinkRate] : "关"));
        }

        /// <summary>一个完整明暗来回的秒数：慢 1.8 / 中 1.2 / 快 0.7。</summary>
        double BlinkPeriod()
        {
            return _blinkRate == 0 ? 1.8 : (_blinkRate == 1 ? 1.2 : 0.7);
        }

        /// <summary>
        /// 闪烁包络：亮段保持 → 短过渡 → 暗段保持 → 短过渡回来，全程同一个颜色。
        ///
        /// 暗段保留 20% 亮度而不是打到 0 —— 这样看过去是"这个颜色在闪"，
        /// 而不是"灯一会儿断电一会儿通电"。电平下限是 1，所以再暗也不会变成全黑。
        /// </summary>
        static double BlinkEnvelope(double p)
        {
            const double low = 0.20;
            p -= Math.Floor(p);
            double v;
            if (p < 0.35) v = 1.0;
            else if (p < 0.50) { double x = (p - 0.35) / 0.15; v = 1.0 - x * x * (3 - 2 * x); }
            else if (p < 0.85) v = 0.0;
            else { double x = (p - 0.85) / 0.15; v = x * x * (3 - 2 * x); }
            return low + (1.0 - low) * v;
        }

        void BlinkApply(double f)
        {
            Ec.KbColor.ApplyRgbFast((int)Math.Round(_lightR * f),
                                    (int)Math.Round(_lightG * f),
                                    (int)Math.Round(_lightB * f));
        }

        void StartBlink()
        {
            if (_lightR < 0) return;
            Ec.KbColor.ClearEffectState();
            Ec.KbColor.SetHardwareRainbow(false);
            if (_blinkTimer == null)
            {
                _blinkTimer = new System.Windows.Forms.Timer();
                _blinkTimer.Interval = 30;      // 30ms 一帧，过渡才看得出是渐变的
                _blinkTimer.Tick += BlinkTick;
            }
            _blinkPhase = 0;
            _blinkLast = DateTime.UtcNow;
            BlinkApply(1.0);
            _blinkTimer.Start();
        }

        void StopBlink()
        {
            if (_blinkTimer != null) _blinkTimer.Stop();
            if (_lightR >= 0)
            {
                Ec.KbColor.SetHardwareRainbow(false);
                Ec.KbColor.ClearEffectState();
                Ec.KbColor.ApplyRgb(_lightR, _lightG, _lightB, false);
            }
        }

        void BlinkTick(object sender, EventArgs e)
        {
            if (_lightR < 0) return;
            DateTime now = DateTime.UtcNow;
            double dt = (now - _blinkLast).TotalSeconds;
            _blinkLast = now;
            if (dt <= 0 || dt > 0.5) dt = 0.03;
            _blinkPhase += dt / BlinkPeriod();
            if (_blinkPhase >= 1) _blinkPhase -= Math.Floor(_blinkPhase);
            BlinkApply(BlinkEnvelope(_blinkPhase));
        }

        // ------------------------------------------------------------ 硬件彩虹

        /// <summary>
        /// 硬件彩虹开关。它来自原厂 StartRainbowMode：往 0x767 的 bit7 写 1 就开，
        /// 清 0 就关 —— EC 固件自己跑动画，本程序零 CPU 占用，退出后也仍在跑。
        ///
        /// ⚠️ 0x767 只翻转 bit7，其它位按读回值原样保留：实测 bit0~3 与风扇有关。
        /// </summary>
        void OnHwRainbowChanged(object sender, EventArgs e)
        {
            if (_loading || chkHwRainbow == null) return;
            bool want = chkHwRainbow.Checked;
            // 与闪烁互斥
            if (want && chkBlink != null && chkBlink.Checked)
            {
                _loading = true;
                try { chkBlink.Checked = false; }
                finally { _loading = false; }
                if (_blinkTimer != null) _blinkTimer.Stop();
            }

            // 起效果前先按原厂 RunEffctEC 的做法复位掉可能残留的硬件状态，
            // 否则 0x7C5 的状态指示位会盖掉我们写的颜色
            Ec.KbColor.ClearEffectState();

            string err;
            if (want) err = Ec.KbColor.SetHardwareRainbow(true);
            else
            {
                err = Ec.KbColor.SetHardwareRainbow(false);
                if (err == null && _lightR >= 0)
                    err = Ec.KbColor.ApplyRgb(_lightR, _lightG, _lightB, false);
            }

            if (err != null)
            {
                lblLightStatus.Text = "切换硬件彩虹失败：" + err;
                lblLightStatus.ForeColor = CDanger;
                Log.Write("硬件彩虹切换失败: " + err);
                return;
            }

            SaveLightConfig();
            RefreshLightUi();
            Log.Write("硬件彩虹 -> " + (want ? "开（由 EC 固件驱动）" : "关"));
        }


        // ------------------------------------------------------------ 界面缩放

        /// <summary>
        /// 用户改了缩放：存盘后整界面重建一遍。布局数值都是「设计值 × 系数」，
        /// 只在 BuildUi() 里算一次，所以必须重建才能重新排版 —— 运行时的
        /// Control.Scale() 只缩窗体自身，手工改 Bounds 又会被锚定引擎弹回。
        /// </summary>
        void OnScaleChanged(object sender, EventArgs e)
        {
            if (_loading || cmbScale == null) return;
            int pct = UiScaleStore.PercentOf(cmbScale.SelectedItem as string);
            if (pct <= 0 || pct == _uiPct) return;

            UiScaleStore.Save(pct);
            _uiPct = pct;
            Log.Write("界面缩放 -> " + pct + "%");
            // 用 BeginInvoke 推迟一拍：重建会把下拉框自己一起 Dispose，
            // 直接在它自己的 SelectedIndexChanged 里做会崩。
            BeginInvoke(new MethodInvoker(delegate
            {
                RebuildUi();
                if (stStatus != null) stStatus.Text = "界面缩放已调整为 " + _uiPct + "%";
            }));
        }

        void RebuildUi()
        {
            int keepPage = _page;      // 重建（换缩放档）后停在原来那一页
            SuspendLayout();
            try
            {
                List<Control> old = new List<Control>();
                foreach (Control c in Controls) old.Add(c);
                Controls.Clear();
                for (int i = 0; i < old.Count; i++) old[i].Dispose();

                BuildUi();

                // 重建后把运行状态重新贴回新控件上
                _guardCfg = GuardStore.Load(); RefreshGuardUi();
                _wallCfg = WallStore.Load();
            _fanCfg = FanCurveStore.Load();
            RefreshFanCurveUi();
            RefreshWallUi();
                RefreshPowerUi();
                RefreshAutoStartUi();
                UpdatePresetLabel();
                RefreshLightUi();

                SwitchPage(keepPage);
            }
            catch (Exception ex)
            {
                Log.Write("界面重建失败: " + ex.Message);
                if (stStatus != null) stStatus.Text = "界面重建失败，请重启程序";
            }
            finally
            {
                ResumeLayout(true);
                PerformLayout();
            }
        }

        /// <summary>打开日志/配置目录（诊断时最常要的东西都在里面）。</summary>
        void OnOpenLogClick(object sender, EventArgs e)
        {
            try
            {
                string d = Log.Dir();
                if (!Directory.Exists(d)) Directory.CreateDirectory(d);
                ProcessStartInfo psi = new ProcessStartInfo(d);
                psi.UseShellExecute = true;
                Process.Start(psi);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "打开日志目录失败：" + ex.Message, "系统控制台",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        void OnElevateClick(object sender, EventArgs e)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo(Application.ExecutablePath);
                psi.UseShellExecute = true;
                psi.Verb = "runas";
                Process.Start(psi);
                _reallyExit = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "提权启动失败：" + ex.Message, "系统控制台",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
