# 自定义风扇曲线（MyFan）EC 写协议 —— 逆向分析报告

> 目标：从原厂控制中心的 .NET 程序里逆向出「自定义风扇曲线（MyFan）」的 EC 写协议。
> 方法：**纯静态分析**。自写 Python PE/元数据/IL 解析器读取程序集，未运行任何 OEM 程序，
> 未向 EC 写入任何值，未修改 `D:\deep.1\SystemConsole` 下的任何源码或既有文档。
> 分析工具：`D:\deep.1\tmp\fanre\`（`pedump2.py` 元数据+IL 反汇编、`dump.py`/`around.py`/`ndump.py` 反汇编、
> `bodies.py`/`sum.py` 方法体恢复、`cst.py`/`q3.py` 常量与枚举提取）。

---

## 0. 先说三个会改变后续工作的前置结论

### 0.1 分析对象被任务描述写错了：`ecwork\GCUService.exe` 不是 .NET 程序

| 文件 | 大小 | 真实身份 |
|---|---|---|
| **`D:\deep.1\ecwork\GCUService.exe`** | 15 148 544 | **原生 Rust/Tauri PE**，无 CLR 头（`DataDirectory[14]=0`）、无 BSJB。里面有 `../public/gamingcenter_STD.ico`、`http://localhost:3000/src-tauri/src/main.rs`、`/ _next/static/chunks/...`、brotli 静态字典、WebView2/EdgeUpdate 组件 GUID、`SOFTWARE\OEM\GamingCenter2`。**不含 `MyFan`/`MYFAN`/`FanCurve`/`Mechrevo`/`Uniwill`/`ACPIDriver`/`SystrayExtensionPipe` 任何一个字符串**（UTF-8 与 UTF-16 都查过）。 |
| **`D:\deep.1\ref\inno\files\GCUService.exe`** | 18 002 992 | **真正的 OEM .NET 程序集**（CLR 头 `0xA92BA8/0x48`，BSJB @ 0x97ECC0，9574 个方法）。**本文所有 GCUService 结论都来自这个文件。** |
| `D:\deep.1\ecwork\ACPIDriverDll.dll` | 4 102 144 | 原生 DLL（无 CLR 头），与既有文档结论一致。 |

> 所以：**主力分析对象应为 `D:\deep.1\ref\inno\files\GCUService.exe`**。`ecwork` 里那个同名文件与本任务无关。

### 0.2 `GCUService.exe` 被加壳/保护，MethodDef → 方法体的映射被打断

- 9574 个 MethodDef 里，**5771 个的 RVA 被改写成同一个地址 `0x970FF8`**，那里是一段 11 字节的
  `throw new Exception(ldstr "Runtime exception")`（对应的字符串确实存在于 #US 堆）。
- 只有 1708 个行保留「看起来真实」的 RVA，其中相当一部分也是共享桩（`0x15EAA`（135 个方法，正文仅 `ret`）、
  `0x12A56`（26 个，正文 `ldc.i4.0; ret`）等）。
- **但这些方法真正的 IL 还在文件里**：`.text` 里能顺序走出一万多个自洽的方法体（解码到 `bodySize` 精确结束），
  例如 `file 0x6AA58` 那段就是完整的「把 5 个 PWM 写进 0x743–0x747」。
- 因此本文的 IL 证据分两类：
  1. **锚定在常量表 / 枚举上的证据**（最可靠，与方法体无关）；
  2. **从文件里恢复出来的孤立方法体**（给了文件偏移，不给方法名，因为名字无法对应）。
- 另外发现 IL 里的 `call/callvirt` **MethodDef token 与名称表差 1 行**：`真实方法 = methodname[token行 + 1]`。
  用三个独立例子验证（都靠签名或语义）：
  - token 行 1577 → 真 1578 `Read  instance void(string, ushort, ref byte)`（IL 里是 `ldloca.s` 取值）
  - token 行 1578 → 真 1579 `Write instance void(string, ushort, byte)`（IL 里是压值写回）
  - token 行 3391 → 真 3392 `GetBitFromByte`（IL 里 `(byte, bit)`）
  - token 行 3445 → 真 3446 `SetFanTableThread`（风扇表提交线程）
  本文引用 IL 时用 **「真名 [原始token行=N]」** 标注。

### 0.3 两个交叉验证用的「干净」程序集

| 文件 | 状态 | 用途 |
|---|---|---|
| `D:\deep.1\ref\inno\files\DefaultTool.exe` | 未保护，IL 完整可读 | 注册表键名、`ADDR_*` 常量一致性的对照 |
| `D:\deep.1\ref\ccu\CCUWinUI.dll` | 未保护，IL 完整可读 | UI 侧曲线模型、字符串键名 |
| `D:\deep.1\ref\inno\files\GCUServicePlugin.dll` | 未保护 | 无风扇逻辑 |

两份程序集的 `ADDR_*` 常量值**完全一致**，互相印证。

---

## 1. 结论摘要表

| # | 问题 | 结论 | 置信度 |
|---|---|---|---|
| 1 | 曲线点数 | **5 个点（L1–L5）**，每点**只有一个 PWM 值**，温度不是用户可写的 | **已证实**（类型 `FanOfficeAdvLvPwms{T1_PWM..T5_PWM}`、5 个寄存器、IL 写 5 条） |
| 1b | 另有 16 点表格曲线 | `0xF00–0xFEF` 有 3 张 **16 点**表（CPU 升温/降温 + Duty + GPU 升温/降温），那是 `FanTable1p5` 功能，不是 MyFan 的 5 点曲线 | **已证实** |
| 2 | PWM 编码 | **EC 值 = 2 × 百分比**，范围 **0–200**（LSB = 0.5%）。UI 侧是 0–100 | **已证实**（IL 里 `*2` / `conv.u1`；读回时 `/2`；枚举 `MyFan2SpeedByteFlag`） |
| 3 | 温度编码 | 5 点曲线**没有**温度寄存器写入（用户只管 PWM）。温度由 EC 固件固定；`0xF00` 那套 16 点表才有温度数组 | **强推断** |
| 4 | 写哪些寄存器 | `0x743–0x747` = L1–L5 PWM（写入口）。`0x748/0x74A/0x74B` **不是风扇**，是 LIGHTBAR/GREENBAR/BLUEBAR 灯条；`0x7A5/0x7A6` 是 AP/OEM 字节；`0x7A7–0x7AA` 是电池模式 PL 默认值；`0x7AB` bits5-7 = 模式档位索引；`0x79E/0x7A0` 本版本代码**未引用** | **已证实**（常量表对照） |
| 5 | 使能/提交 | **写 `0x751` 就是使能**：`0x751 = 0x80 | level`（level 0–5）。没有找到类似键盘背光 `0x767 bit5` 那样的独立「提交位」；16 点表由 `SetFanTableThread` 提交 | **已证实**（枚举 + IL） |
| 5b | 先写 PWM 还是先写模式 | 必须先写 `0x743–0x747`，再写 `0x751` | **强推断**（两件事在不同方法里，未找到同一个方法内的顺序） |
| 6 | 范围/合法性校验 | 有。5 个值分别按 `DefaultPWM[0]`（下限）/`DefaultPWM[4]`（上限）夹取，越界回退默认值；**没有单调性校验** | **已证实**（IL）+ 未发现（单调性） |
| 6b | 默认曲线 | `{60, 70, 80, 90, 100}`（EC 单位）= **30% / 35% / 40% / 45% / 50%** | **已证实**（`CheckFanTablePWMDefault` 正文） |
| 7 | `0x79E = 44` 是什么单位 | **推不出来**。本版本 GCUService 的 IL 里没有任何 `ldc.i4 0x79E/0x79F/0x7A0` 站点（常量 `ADDR_MYFANI_*` 只是声明），无法判断单位 | **推不出来** |
| 8 | 退出/还原 | `0x751` 写回基础模式（`0x00` 安静 / `0x10` 标准 / `0xA0` 高级静音）；PWM 写回默认 60/70/80/90/100。原厂 `-ClearUserFanTables` **只删注册表**，不写 EC | **强推断** |

---

## 2. 完整使能序列（可直接照着写代码）

约定：`P1..P5` 是用户曲线 5 个点的百分比（0–100，整数）；
`EC(x) = (byte)(x * 2)`；`level` 是档位（0 = 自动/基础档，1–5 = 用户档位）。

### 2.1 写入自定义曲线并启用

```c
// 1) 先校验（原厂 AddPwms 校验逻辑，见 §5.1）
//    def[0] = 下限, def[4] = 上限, def[1..3] = L2..L4 的默认回退值
//    本机默认 def = {60, 70, 80, 90, 100}（EC 单位 = 30/35/40/45/50%）
if (P1 < def[0])                  P1 = def[0];
if (P2 >= def[0] && P2 > def[4])  P2 = def[1];
if (P3 >= def[0] && P3 > def[4])  P3 = def[2];
if (P4 >= def[0] && P4 > def[4])  P4 = def[3];
if (P5 > def[4])                  P5 = def[4];

// 2) 写 5 个 PWM（顺序 L1 → L5；IL 里就是顺序写）
WriteEC(0x743, (byte)(P1 * 2));   // ADDR_MYFAN2_L1_PWM
WriteEC(0x744, (byte)(P2 * 2));   // ADDR_MYFAN2_L2_PWM
WriteEC(0x745, (byte)(P3 * 2));   // ADDR_MYFAN2_L3_PWM
WriteEC(0x746, (byte)(P4 * 2));   // ADDR_MYFAN2_L4_PWM
WriteEC(0x747, (byte)(P5 * 2));   // ADDR_MYFAN2_L5_PWM

// 3) 使能：切到「用户模式 / 用户档位」（关键一步）
WriteEC(0x751, (byte)(0x80 + level));   // 0x80=User_Fan_Mode, 0x81..0x85=User_Fan_Level1..5
```

### 2.2 叠加「强冷」（不要破坏自定义档位）

原厂是**读改写**，不是直接写 0x40：

```c
byte v = ReadEC(0x751);
v = (arg == on) ? (byte)(v | 0x40) : (byte)(v & 0xBF);
WriteEC(0x751, v);
```

> 既有文档 `FAN-CONTROL-PROTOCOL.md` §6.2 说「开启时应写 `base | 0x40`」，这一点被原厂 IL 完全证实。

### 2.3 退出 / 还原

```c
// A. 回到原厂基础模式（推荐，原厂 SetFanMode 走的就是这条路）
WriteEC(0x751, 0x00);   // 安静 Normal_Mode
// 或
WriteEC(0x751, 0x10);   // 标准 Turbo_Mode
// 或
WriteEC(0x751, 0xA0);   // 高级静音 User_Fan_HiMode

// B. 顺手把 5 个 PWM 写回出厂默认（可选）
WriteEC(0x743, 60); WriteEC(0x744, 70); WriteEC(0x745, 80);
WriteEC(0x746, 90); WriteEC(0x747, 100);
```

### 2.4 进入自定义曲线前必须记住的原始值

- `0x751` 原值（本机 `0x30`）——用于还原。注意 `0x30 = 0x10 | 0x20`，而 `0x20` 位**不在**原厂枚举里（见 §5.3），语义未知。
- 不要假定「写 0x00/0x10 就等于还原」，因为原值可能是 `0x20`/`0x30` 这些枚举外的组合。

---

## 3. 寄存器地图（0x700–0x7FF 与本功能相关部分）

下表「名称」一列**直接来自原厂 .NET 程序集 Constant 表**（`GCUService.exe` 与 `DefaultTool.exe` 两处取值一致），
不是推测。

| 地址 | 原厂常量名 | 含义 | 本机实测值 | 本版本代码引用情况 |
|---|---|---|---|---|
| **0x743–0x747** | `ADDR_MYFAN2_L1_PWM` … `ADDR_MYFAN2_L5_PWM` | **自定义曲线 5 个点的 PWM（写入口）** | 全 `0x00` | **写 18 处**（3 套 Manager 各 6 处） |
| 0x743–0x746 | `ADDR_ConfigurableTGP_DynamicBoost_CTRL_BYTE` / `_VALUE` / `TotalProcessingPowerTarget` / `MaxinumTGP` | **同一地址在别的项目上是可配置 TGP / Dynamic Boost** | — | 项目相关，需按 0x740 项目 ID 判定 |
| 0x748 / 0x74A / 0x74B | `ADDR_LIGHTBAR_CONTROL_BYTE` / `ADDR_GREENBAR_…` / `ADDR_BLUEBAR_…` | **灯条控制字节，不是风扇**（这就是既有文档里「0x748–0x74B 风扇曲线点，被引用 63 处」的真相：那是灯效代码） | `0x80 00 00 00` | 各 11–13 处 |
| 0x749 | （无独立常量名，与 0x740 同组使用） | 未解析 | — | 11 处 |
| 0x738 | `ADDR_MYFAN3_CPU_TAU` | MyFan3 的 CPU 时间常数；**只读**，为 0 时软件回退 0x38(56) | — | 读 8 处 |
| 0x78B | `ADDR_MYFAN3_GPU_SETTING`（同值还有 `ADDR_L3_PWM_DEFAULT_MYFAN2`） | MyFan3 GPU 设置：**低 3 位有效**，读改写掩码 `0xF8`，写值 1/2 | — | 14 处 |
| 0x786–0x78A | `ADDR_L1..L5_PWM_DEFAULT_MYFAN3` | MyFan3 的**出厂默认 PWM**（只读参考） | — | 读（`int[5]`） |
| 0x789–0x78D | `ADDR_L1..L5_PWM_DEFAULT_MYFAN2` | MyFan2 的出厂默认 PWM（与上一行**地址重叠**，项目相关） | — | 读 |
| **0x751** | `ADDR_MAFAN_CONTROL_BYTE` | **风扇模式位域**（见 §5.3） | `0x30` | **36 个方法体引用** |
| 0x79E / 0x79F / 0x7A0 | `ADDR_MYFANI_MIN_SPEED` / `_MIN_TEMP` / `_EXTRA_SPEED` | 原厂注释「MYFANI 最低转速 / 最低温度 / 附加转速」 | `44 / 0 / 0` | **本版本 IL 里 0 处引用**（只在常量表里声明） |
| 0x7A5 / 0x7A6 | `ADDR_AP_OEM_BYTE3` / `ADDR_AP_OEM_BYTE4` | 灯光/AP 子系统字节 | `00 01` | 33 / 24 处（全是灯光路径） |
| 0x7A7 / 0x7A8 / 0x7A9 / 0x7AA | `ADDR_BATTERYSAVER_PL1/PL2/PL4/D_DEFAULT_VALUE` | **电池模式 PL 默认值**，不是 MyFan 参数组 | `0x82 0x82 0xC8 0x01` | 5 组方法体（每组 4 个地址） |
| **0x7AB** | `ADDR_MyFanCCI_Mode_Index`（同值另有 `ADDR_AP_EC_LOGO`） | **bits 5–7 = 模式档位索引 0–4**（读改写掩码 `0x1F`，写入 `0x00/0x20/0x40/0x60/0x80`）；同一地址在灯效代码里当「Logo 控制字节」用 | `0` | 24 处（**两种用途混在一起，需按调用链区分**） |
| 0x7B0 / 0x7B1 / 0x7B2 | `ADDR_MyFanCCI_Mode_Profile1/2/3` | 三种模式配置 | — | 本版本仅 0x7B2 被引用 1 处 |
| 0xF00–0xFEF | `ADDR_TABLE_F1/F2/F3_*` | **3 张 16 点风扇表**，每张 `0x50` 字节 = CPU_UpT[16] / CPU_DownT[16] / Duty[16] / GPU_UpT[16] / GPU_DownT[16] | — | 15 个地址被同一方法体引用 |
| 0xF5D/0xF5E/0xF5F | `ADDR_RAMFAN1P5_TABLE_STATUS1/2` / `_CTRL` | 内存风扇 1.5 表控制（与 0xF50 段重叠，项目相关） | — | 多处 |

**本机 `0x7A5–0x7AA` 的实测值用原厂名字解释才对得上**（`0x82 0x82 0xC8` 更像 PL 默认值），
既有文档把它标成「MyFan 参数组」是误标。

---

## 4. 数据结构（问题 1 的展开）

### 4.1 UI / 业务模型（来自未保护的元数据）

| 类型 | 定义 | 来源 |
|---|---|---|
| `FanOfficeAdvLvPwms.MyControlCenter` | `{ T1_PWM, T2_PWM, T3_PWM, T4_PWM, T5_PWM }` | GCUService.exe 字段表 |
| `<AdvL1_T1_PWM>i__Field` … `<AdvL4_T5_PWM>i__Field` | **4 组高级档位 × 每组 5 个 PWM**（匿名类型） | GCUService.exe 字段表 |
| `Table.MyControlCenter.MyFan.FanTable` | `{ <ID>, <UpT>, <DownT>, <Duty> }` | GCUService.exe 字段表 |
| `FanTable2Buffer.MyControlCenter.MyFan.FanTable` | `{ ID, CpuUpT, CpuDownT, Duty, GpuUpT, GpuDownT }` | GCUService.exe 字段表 |
| `FanTable1p5Buffer...` | `{ ID, UpT, DownT, Duty }` | GCUService.exe 字段表 |
| `MainOption.MyControlCenter.MyFan` | `{ GamingProfileIndex, OfficeProfileIndex, TurboProfileIndex, CustomProfileIndex, FanBoostEnable, FanSafetyProtectNotify, ... }` | GCUService.exe 字段表 |
| `MyFanManager_Intel` / `MyFanManager_QC` / `MyFanManager` / `MyFanManager_RamFan1p5*` | 各含 `SetFanMode / SetFanBoost / SetBasicFanLevel / SetFan_L1_PWM..SetFan_L5_PWM / SetFan_Optimized_PWM / PWM2Byte / SetModeProfileIndex / SetFanTableThread / UserSet_FanSpeedCurveSetting …` | GCUService.exe 方法表（名称可靠，方法体被壳破坏） |

注意 `SetFan_L1_PWM`…`SetFan_L5_PWM` 的签名都是 `instance void(uint)`，`SetBasicFanLevel` 也是 `instance void(uint)`，
`PWM2Byte(uint) -> ulong`、`Level2Pwm(uint) -> ulong` 就是那个 ×2 换算器。

### 4.2 字符串键名（来自 CCUWinUI.dll / DefaultTool.exe / GCUService.exe 的 #Strings 堆）

`FAN_OFFICE_MODE_ADVANCED_T1_PWM` … `T5_PWM`、`FAN_OFFICE_MODE_ADV_LV1_PWMS` … `LV4_PWMS`、
`FAN_OFFICE_MODE_ADV_MIN_TEMP`、`GET_FAN_SPEED_CURVE_SETTING`、`SET_FAN_SPEED_CURVE_SETTING`、
`RESTORE_FAN_SPEED_CURVE_SETTING`（CCUWinUI 里还有 `RESTORE_FAN_SPEED_CURVE_SETTING_ALL`）、
`BasicFanLevel`、`AdvanceFanLevel`、`Default_Min_PWM`、`Default_Max_PWM`、`DefaultTemperature`、
`MyFanTable`、`FanTable1p5`、`FanTable1p5Buffer`。

注册表位置（DefaultTool.exe 字符串 + `FanTable.DefaultTool::ClearUserFanTables` 的 IL）：

```
HKLM\SOFTWARE\OEM\GamingCenter2\MyFanTable        ← 用户自定义曲线的持久化位置
...\AiStoneService\MyControlCenter\UserFanTables\
DefaultFanTable_Gaming / DefaultFanTable_Office / DefaultFanTable_Turbo
```

> 结论：**用户曲线只存注册表**；EC 只保存「当前生效值」。原厂 `-ClearUserFanTables`
> 的实现只是遍历文件名列表 `File.Delete()` 把 `MyFanTable` 相关文件删掉，**没有任何 EC 写操作**
> （证据：`FanTable.DefaultTool::ClearUserFanTables` RVA 0x3798 全文只有
> `RegistrySoftwareKeyRead` + `File.Exists/Delete` + 日志）。

### 4.3 MyFan 曲线的点数和「温度」问题

- **点数 = 5**，**每点只有 PWM**。证据链：
  1. `ADDR_MYFAN2_L1_PWM..L5_PWM` 恰好 5 个地址；
  2. 类型 `FanOfficeAdvLvPwms` 恰好 5 个字段 `T1_PWM..T5_PWM`（**只有 PWM，没有 T*_TEMP**）；
  3. 写 EC 的方法体只写 5 个字节，且**参数就是 5 个 PWM**；
  4. 字符串键名只有 `..._T1..T5_PWM`，没有对应的温度键。
- 5 个点的**温度阈值不在用户可写范围内**（EC 固件固定）。若将来要验证：读 0xF00 段的表即可看到 16 点表的温度，
  但 5 点曲线的温度没有对应的 EC 地址出现在原厂常量表里。
- 「T1..T5」里的 **T 是「阈值/档位」编号**，不是「用户输入的温度」。

---

## 5. 证据（问题 2/3/4 的展开）

> IL 标注约定：`[原始token行=N]` 表示文件里 token 指向第 N 行，按 §0.2 的 +1 规则真名是第 N+1 行。
> 地址标注 `<== 名称` 来自原厂常量表。

### 5.1 写 5 个 PWM（`MyFan2 曲线 L1–L5`）—— 两段 IL

**(a) 直接写：`file 0x6AA58`（rva 0x6C858，181 字节，61 条指令）**

```il
IL_0000 ldarg.0
IL_0001 ldfld      EcCtrl
IL_0006 ldarg.0
IL_0007 call       Select      [MR]        ; 见 §7 关于这两个 token 的说明
IL_000C callvirt   Reverse     [MR]
IL_0011 ldc.i4     1859 (0x743)            <== MYFAN2_L1_PWM
IL_0016 ldarg.1
IL_0017 ldfld      T1_PWM
IL_001C ldc.i4.2   2
IL_001D mul
IL_001E conv.u1
IL_001F callvirt   Write  [原始token行=1578，表中名为 Read]
...
IL_0035 ldc.i4     1860 (0x744)            <== MYFAN2_L2_PWM
IL_003A ldarg.1 / ldfld T2_PWM / ldc.i4.2 / mul / conv.u1
IL_0043 callvirt   Write
...
IL_0059 ldc.i4     1861 (0x745)
IL_007D ldc.i4     1862 (0x746)
IL_00A1 ldc.i4     1863 (0x747)
IL_00AF callvirt   Write
IL_00B4 ret
```

**读法：`0x743+i = (byte)(T(i+1)_PWM * 2)`，顺序 L1→L5。**

**(b) 带区间夹取：`file 0x6A928`（rva 0x6C728，289 字节，119 条指令）**

```il
; 参数：this, byte L1, byte L2, byte L3, byte L4, byte L5
IL_0000 ldarg.1
IL_0001 ldarg.0
IL_0002 ldfld      DefaultPWM
IL_0007 ldc.i4.0   0
IL_0008 ldelem.i4
IL_0009 bge.s      +11                     ; if (L1 < DefaultPWM[0]) L1 = DefaultPWM[0];
...
IL_0016 ldarg.2 ; DefaultPWM[0] ; blt.s    
IL_0021 ldarg.2 ; DefaultPWM[4] ; ble.s    ; if (L2 >= min && L2 > max) L2 = DefaultPWM[1];
IL_0037 ... L3 → DefaultPWM[2]
IL_0058 ... L4 → DefaultPWM[3]
IL_007B ldarg.s 5 ; DefaultPWM[4] ; ble.s  ; if (L5 > max) L5 = DefaultPWM[4];
; 然后用与 (a) 完全相同的顺序把 L1..L5 写进 0x743..0x747
```

**这段就是原厂的合法性校验**（问题 4 的答案）。**没有任何单调递增检查。**

同一段代码在文件里出现 **3 份**（`0x6A928/0x6AA58`、`0x6FC28/0x6FE7C`、`0x84224/0x84478`），
对应 `MyFanManager_Intel` / `MyFanManager_QC` / `MyFanManager` 三套实现。

### 5.2 默认值表 `CheckFanTablePWMDefault`

**方法体完整可读**：`MethodDef row 3391 = CheckFanTablePWMDefault`，RVA **0x6B421**（签名 `int[] (int[])`）。

```il
IL_0000 ldarg.1 / ldc.i4.0 / ldelem.i4 / brfalse.s        ; if (pwm[0]==0 ||
IL_0005 ... pwm[1]==0 || pwm[2]==0 || pwm[3]==0 || pwm[4]==0) {
IL_0019 ldarg.1 ; ldc.i4.0 ; ldc.i4.s 60   ; 0x3C   stelem.i4
IL_001E ldarg.1 ; ldc.i4.1 ; ldc.i4.s 70   ; 0x46   stelem.i4
IL_0023 ldarg.1 ; ldc.i4.2 ; ldc.i4.s 80   ; 0x50   stelem.i4
IL_0028 ldarg.1 ; ldc.i4.3 ; ldc.i4.s 90   ; 0x5A   stelem.i4
IL_002D ldarg.1 ; ldc.i4.4 ; ldc.i4.s 100  ; 0x64   stelem.i4
IL_0032 ldarg.1 ; ret
```

→ **默认曲线 EC 值 = {60, 70, 80, 90, 100} = 30% / 35% / 40% / 45% / 50%**。
这 5 个数还与枚举 `MyFan2SpeedByteFlag` 的 `Speed30/35/40/45/50` 逐个对齐（见 §5.3）。

### 5.3 模式字节 `0x751` 的权威定义：`MyFanCTLByteFlag` 枚举

从 `Constant` 表 + `Field` 表读出（**这是原厂自己写的枚举，比实测表更权威**）：

| 枚举成员 | 值 | 含义 |
|---|---|---|
| `Normal_Mode` | **0x00** | 安静/普通 |
| `Turbo_Mode` | **0x10** | 性能/标准 |
| `FanBoost_Mode` | **0x40** | 强冷**位** |
| `User_Fan_Mode` | **0x80** | **用户自定义模式（MyFan）** |
| `User_Fan_Level1` | **0x81** | 自定义档位 1 |
| `User_Fan_Level2` | **0x82** | 自定义档位 2 |
| `User_Fan_Level3` | **0x83** | 自定义档位 3 |
| `User_Fan_Level4` | **0x84** | 自定义档位 4 |
| `User_Fan_Level5` | **0x85** | 自定义档位 5 |
| `User_Fan_HiMode` | **0xA0** | 高级静音（本机实测 duty≈100） |

> 枚举里**没有** `0x20` 和 `0x30`。本机原始值 `0x30 = 0x10 | 0x20`，那个 `0x20` 位在
> `MyFanManager` 的 IL 里对应字段 `g_FanEnhanced`（`if (g_FanEnhanced==1) … 0x40 else 0x00`），
> 语义未完全确认。

**`MyFan2SpeedByteFlag` 枚举（PWM 编码的权威证据）**：

| 成员 | 值 | = 2 × |
|---|---|---|
| `Speed00` | 0 | 0% |
| `Speed30` | 0x3C = 60 | 30% |
| `Speed35` | 0x46 = 70 | 35% |
| `Speed40` | 0x50 = 80 | 40% |
| `Speed45` | 0x5A = 90 | 45% |
| `Speed50` | 0x64 = 100 | 50% |
| `Speed55` | 0x6E = 110 | 55% |
| `Speed60` | 0x78 = 120 | 60% |
| `Speed70` | 0x8C = 140 | 70% |

→ **EC 值 = 2 × 百分比，1 LSB = 0.5%**。既有文档实测的「占空比 100/120/140/200」正好落在这条轴上。

### 5.4 使能序列的关键 IL

**(a) 写 `0x751 = 0x80 + level`** —— `file 0x6A848`（rva 0x6C648，36 字节，12 条指令）

```il
IL_0011 ldc.i4  1873 (0x751)   <== MAFAN_CONTROL_BYTE
IL_0016 ldc.i4  128 (0x80)     ; User_Fan_Mode
IL_001B ldarg.1                ; level (0..5)
IL_001C add
IL_001D conv.u1
IL_001E callvirt Write  [原始token行=1578]
IL_0023 ret
```

**这是整个自定义风扇曲线的「使能指令」。** 同样的 36 字节代码在文件里有 3 份
（`0x6A848` / `0x6DEC8` 附近 / `0x84268`），且都带常量 `0x80`。

**(b) 强冷 = 0x751 的读改写** —— `file 0x6969C`（89 字节）

```il
IL_0013 ldc.i4 1873 (0x751) ; ldloca.s 0 ; callvirt Read   ; 读回原值
IL_0027 ldarg.1 ; ldc.i4.1 ; bne.un.s
IL_002B ldloc.1 ; ldc.i4.s 64 (0x40) ; or                 ; ON : |0x40
IL_0033 ldloc.1 ; ldc.i4 191 (0xBF) ; and                 ; OFF: &~0x40
IL_004D ldc.i4 1873 (0x751) ; ldloc.1 ; callvirt Write
```

**(c) 从 `0x751` 反解三态** —— `file 0x69704`（134 字节）

```il
IL_0015 ldc.i4 1873 (0x751) ; ldloca.s 1 ; callvirt Read
IL_0029 ldarg.0 ; ldloc.2 ; ldc.i4.4 ; call GetBitFromByte   ; bit4
IL_0032 ldarg.0 ; ldloc.2 ; ldc.i4.7 ; call GetBitFromByte   ; bit7
; bit4=0,bit7=0 -> 0
; bit4=0,bit7=1 -> 1
; bit4=1,bit7=0 -> 2
; bit4=1,bit7=1 -> 0（落到默认分支）
```

→ **bit4 (0x10) 与 bit7 (0x80) 是「主导模式」的两位**，与 §5.3 的枚举自洽。
`GetBitFromByte` 的方法体也完整可读（`MethodDef row 3392`，RVA **0x6B456**，只有 9 字节）：

```il
ldarg.1 ; ldarg.2 ; ldc.i4.s 31 ; and ; shr ; ldc.i4.1 ; and ; ret   ; (v >> (bit & 0x1F)) & 1
```

**(d) 完整的 `SetFanMode` 分发** —— `file 0x68D7C`（rva 0x6AB7C，683 字节，247 条指令）

```il
; switch (mode)
case 1: SetPowerLedStatus(0); SetFanQuietModeEnable(1);
        if (g_FanEnhanced == 1) Write(0x751, 0x40);   // FanBoost_Mode
        else                    Write(0x751, 0x00);   // Normal_Mode
        break;
case 2: SetPowerLedStatus(0); SetFanQuietModeEnable(1); Write(0x751, 0xA0); break;
case 3: SetPowerLedStatus(1); SetFanQuietModeEnable(1); Write(0x751, 0xA0); break;
case 4: Write(0x751, 0x40); break;
; 收尾：
IL_0292 ldarg.0 ; ldfld m_FanTableDelayTime ; call get_CounterName
IL_02A5 call SetFanTableThread   [原始token行=3445，表中名为 SetNVPStateThread]
IL_02AA ret
```

> `SetFanTableThread` 就是「让 EC 采用新曲线」的**异步提交线程**（`SetFanTableThread(uint, int)`），
> 16 点表（0xF00 段）正是由它落盘的。对 5 点 MyFan 曲线来说，IL 里**看不到**这样一个显式提交，
> **`0x751` 自身就是切换点**。

**(e) `0x7AB` 的模式档位索引** —— `file 0x336EC`（222 字节）与 `0xC8A3C`（139 字节）

```il
; arg1 = 档位 0..4
IL_000C ldc.i4.s 64 (0x40)              ; 默认值
IL_0011 ldarg.1 ; switch 5
      → 0 → 0x00, 1 → 0x20, 2 → 0x40, 3 → 0x60, 4 → 0x80
IL_0056 ldc.i4 1963 (0x7AB) ; ldloca.s 1 ; callvirt Read
IL_0063 ldloc.1 ; ldc.i4.s 31 (0x1F) ; and     ; 保留低 5 位
IL_006A ldloc.1 ; ldloc.0 ; or ; conv.u1
IL_007D ldc.i4 1963 (0x7AB) ; ldloc.1 ; callvirt Write
```

→ **`0x7AB = (0x7AB & 0x1F) | (index << 5)`，index 0..4。**
（注意：`0x7AB` 在灯光代码里是 `ADDR_AP_EC_LOGO`；另一处灯效方法 `file 0xC8A3C` 紧接着还做了
`Read(0x78C) | 0x10` 然后写回。所以引用 `0x7AB` 的方法**必须先判定它属于风扇路径还是灯光路径**。）

**(f) `0x78B`（MyFan3 GPU 设置）** —— `file 0x69798`（110 字节）与 `0x69814`（144 字节）

```il
IL_0013 ldc.i4 1931 (0x78B) ; ldloca.s 0 ; callvirt Read
IL_0027 ldc.i4 248 (0xF8) ; and        ; 清低 3 位
IL_0031 ldarg.1 ; or                   ; 写入设置值
IL_0045 ldc.i4 1931 (0x78B) ; ldloc.1 ; callvirt Write
```

**(g) `0x738`（MyFan3 CPU TAU）只读 + 默认 0x38**

```il
IL_0015 ldc.i4 1848 (0x738) ; ldloca.s 1 ; callvirt Read
IL_0030 ldloc.0 ; brtrue.s
IL_0033 ldc.i4.s 56 (0x38) ; stloc.0    ; 读到 0 时用 56
```

**(h) 16 点表读回（`FanTable1p5`）** —— `file 0xEE1C0`（rva 0xEFFC0，526 字节）

```il
for (i = 0; i <= 15; i++) {
    if (i == 0) CPU[i].UpT = 0;
    else { Read(0xF00 + i - 1, out b); CPU[i].UpT = b; }        ; ADDR_TABLE_F1_CPU_TEMP_UP0
    if (i < 15) { Read(0xF10 + i + 1, out b); CPU[i].DownT = b; }
    else        { Read(0xF10 + i,     out b); CPU[i].DownT = b; }
    Read(0xF20 + i, out b); CPU[i].Duty = (byte)(b / 2);        ; ← EC 值 / 2 = 百分比
}
if (m_IsNvGpu) { ... 同样的循环读 0xF30/0xF40 给 GPU ... }
```

→ 这张表**同时证明了 ×2 编码**（写 ×2、读 ÷2），并且给出 3 张表 16 点的布局。

### 5.5 字符串（#US 堆）说明

`GCUService.exe` 的 `#US` 堆**被壳部分加密**：可以读出 `"Runtime exception"`（壳的异常桩用的），
但 IL 里 `ldstr` 指向的多数字符串解出来是乱码。**所以本报告不依赖字符串做方法定位**，
方法定位全部靠：常量表 / 枚举表 / 方法签名 / 方法名表（这四张表都完好）。

---

## 6. 尚未验证、需要实测确认的点

> 以下全部是**静态推断**，上真机前请当作假设。建议顺序：先只读 0x740–0x751 / 0x743–0x747 / 0xF00 段，
> 确认现值与本文一致，再做最小写入实验。

1. **写入顺序是否真的必须「先 PWM 后 0x751」。** 未找到同时包含两类写入的方法；
   两件事分别在不同方法里（`0x743–0x747` 一处，`0x751` 一处）。**强推断，未证实。**
2. **写 `0x743–0x747` 时 EC 会不会立刻接管风扇**，还是必须等 `0x751` 切到 `0x80+n`。
3. **`level`（0x80 vs 0x81–0x85）到底选哪一档**：`SetBasicFanLevel(uint)` 的 UI 语义
   （BasicFanLevel / AdvanceFanLevel 两个字段）未完全还原。建议实测：写 `0x80`、`0x81`、
   `0x82`…分别观察 `0x75B/0x75C`（占空比）是否不同。
4. **PWM 百分比范围到底是 0–100 还是 25–100。** IL 里的夹取用的是 `DefaultPWM[0]=60（=30%）`
   作为下限——**这可能意味着原厂不允许低于 30%**。盲写小于 30% 的值的后果未知（见 §7）。
5. **`0x79E=44 / 0x79F=0 / 0x7A0=0` 的含义与单位。** 本版本 IL 里 **0 处引用**，
   推不出来。需要：① 在 **`MyFanManager_Intel` 的 108 个方法的 IL** 里找 `SetOfficeModeAdv_MinSpeed/MinTemp/ExtraSpeed`
   （这三个方法存在，签名 `instance void(uint)`，但方法体在壳里）；
   ② 或真机上写一次 0x79E 观察最低转速变化。**做之前必须知道风险。**
6. **`0x7AB` 在本机（GM6AR57C）到底是 MyFan 模式索引还是 Logo 字节。**
   两个原厂常量同名同址，必须用真机读回 + 观察灯效来判定。
7. **`0x20` 位（本机 0x751 原值 0x30 的组成之一）** 的语义未确认（推测与 `g_FanEnhanced` 有关）。
8. **`0x7B0/0x7B1/0x7B2`（MyFanCCI_Mode_Profile1/2/3）** 本版本几乎没被引用，
   不知道格式；如果它们真是三种配置档，写入协议未知。
9. **退出后 EC 是否立刻回落**：写回 `0x751 = 0x00/0x10` 之后风扇行为是否立即恢复，
   以及 `0x743–0x747` 残留值会不会在下次切到用户模式时被再次采用。
10. **`0xF00` 段的写权限**：本文只看到**读**该段（`ADDR_TABLE_Fx_*_TEMP_UP0/DOWN0` 与 `DUTY0`），
    没找到写该段的方法体（可能在被壳遮住的 `SetFanTableThread` 里）。**盲写温度表风险极高。**
11. **卡在哪里 / 还需要什么**：
    - 需要一个**能正确读 IL 的商用反编译器**（ILSpy / dnSpy / de4dot）来处理壳；
      本文自写的 Python 解析器只能恢复出「孤立方法体」，**无法给出方法名与调用图**，
      因此「谁调用 `SetFan_L1_PWM`／谁调用 `SetBasicFanLevel`」这条链没能还原。
    - 或者拿到**未被壳保护的 GCUService.exe 版本**（例如从 OEM 安装包的另一个 `exe_*.bin` 里）——
      那样上面 11 条里有 8 条能立刻定论。目前 `ref\inno\files` 里只有这一个 .NET GCUService。

---

## 7. 风险（如果 blind-write 这些寄存器，最坏会发生什么）

> 前提：**本文没有做任何 EC 写入**，以下都是静态推断的风险评估。

| 操作 | 可能后果 | 严重度 | 可逆性 |
|---|---|---|---|
| 写 `0x743–0x747 = 0` 或很小的值 | **风扇可能降到极低转速甚至停转**。EC 把这 5 个字节当成用户曲线的占空比表；0 = 0%。CPU/GPU 高负载时可能过热降频、掉盘、关机 | 高 | 写回大值即可，但如果已经过热，来不及 |
| 写超过 200（界面 100%）的值 | 超出 0.5%/LSB 的线性区间，EC 行为未知（夹取？回绕？忽略？） | 中 | 写回合法值 |
| 写 `0x751 = 0x90`（bit4+bit7 同时置） | §5.4(c) 的代码把它归到「0 = Normal」，但 EC 侧未定义；可能进入未文档化模式 | 中 | 写回 `0x00/0x10/0x30` |
| 直接写 `0x751 = 0x40`（而不是读改写） | **会清掉自定义档位**（`0x80+n` 丢失），强冷关掉后回不到用户模式 | 低 | 重新写 `0x80+n` |
| 写 `0x7AB` | 若本机该项目把它当 `AP_EC_LOGO`，**键盘/Logo 灯效会被改**（`(v&0x1F)|index<<5` 会破坏低 5 位以外的语义） | 中 | 需要知道原值；建议先记录 |
| 写 `0xF00–0xFEF`（16 点表） | **最危险**：这是完整的「温度→占空比」曲线表，含升/降温双阈值。写错 = 风扇在错误温度下不加速，或降不下速 | 很高 | 需要原表备份；EC 表在断电后可能不持久，但**不确定** |
| 反复快速写 `0x751` | EC 可能忽略写入（既有文档已记录 `0x75B/0x75C` 写入被 EC 覆盖的现象），或在切换瞬间出现转速抖动 | 低 | — |
| 所有 EC 写入 | **EC 由待机电源供电，重启不一定复位**；最坏情况需要关机拔电源（或长按电源键）才能恢复 OEM 状态。因此**动手前必须先把 0x751 / 0x743–0x747 / 0x7AB / 0xF00–0xFEF 全部读出来存盘** | — | 视情况 |

**安全建议（如果以后要实测）**

1. 先只读：`0x740 0x741 0x743–0x747 0x751 0x75B 0x75C 0x79E–0x7A0 0x7A5–0x7AB 0x7B0–0x7B2 0xF00–0xFEF`，
   逐字节存档。
2. **只做第一个实验：写 `0x751 = 0x81`**（不碰 PWM），观察 `0x75B/0x75C` 与转速是否变化。
   这能同时验证「0x751 就是使能」和「EC 是否会自己接管」。
3. 第二个实验：写 `0x743 = 100`（50%）后立刻读回，确认是否被 EC 保留（既有文档已知
   `0x75B/0x75C` 会被覆盖，但 `0x743–0x747` 是设定点，预期会保留）。
4. 只有在 1–3 都确认后再做完整曲线写入，且一次只改一个点、改完立刻盯温度。
5. 任何时候保留「一键还原」：`0x751 = 记录的原值`。

---

## 8. 复现方法（只读）

本文的全部结论都可用 `D:\deep.1\tmp\fanre\` 里的脚本复现（纯 Python 3.14，无第三方依赖）：

```powershell
cd D:\deep.1\tmp\fanre

# 1) 元数据结构 + 表偏移自校验（tablesEnd 必须等于 #~ 流长度）
python -c "import pedump2; p=pedump2.PE(r'D:\deep.1\ref\inno\files\GCUService.exe'); print(p.tablesEnd-p.tabHdr, p.streams['#~'][1])"

# 2) 原厂 EC 地址常量表（ADDR_* 的真实值）
python cst.py

# 3) 枚举 MyFanCTLByteFlag / MyFan2SpeedByteFlag 的成员值
python q3.py

# 4) 恢复 GCUService 的孤立方法体并建索引
python sum.py          # 输出 bodies_full.pkl
python mine2.py        # 输出引用 MyFan 各寄存器的方法体索引

# 5) 反汇编指定方法体（参数是 mine2.py 打印的 #编号）
python dump.py 1968 1967 1963 1936 1937

# 6) 反汇编未被保护的程序集里指定名字的方法
python ndump.py "D:\deep.1\ref\inno\files\DefaultTool.exe" ClearUserFanTables
```

**自校验说明**：解析器用两种方式验证正确性——① `#~` 表区总长度与流长度逐字节相等；
② IL 解码必须精确落在 `bodySize` 上。另外用 `ImplMap` 表（P/Invoke 导入名 + DLL 名）
逐一核对 `CreateFile`/`CloseHandle`/`DeviceIoControl`/`SMAPCTable → ACPIDriverDll.dll`，
确认 MethodDef 名称表本身没有被改动。
`CCUWinUI.dll`（13594 个方法体、1.01 MB IL）与 `GCUServicePlugin.dll` 解析结果完全正常，
反证解析器没有系统性问题、只有 `GCUService.exe` 被壳破坏。

---

## 9. 与原文档的关系（勘误）

对既有 `FAN-CONTROL-PROTOCOL.md` 的补充/更正：

| 原文档 | 本文结论 |
|---|---|
| `0x748–0x74B` = 「风扇曲线点」，被引用 63 处 | **错**。原厂常量表是 `LIGHTBAR/GREENBAR/BLUEBAR_CONTROL_BYTE`（灯条）。63 处引用来自灯效代码 |
| `0x7A5–0x7AA` = 「MyFan 参数组」 | **错**。是 `AP_OEM_BYTE3/4` + `BATTERYSAVER_PL1/PL2/PL4/D_DEFAULT_VALUE` |
| `0x743–0x747` = 「MYFAN2 曲线 L1-L5 PWM」 | **对**，且已确定编码 = 2×百分比，以及对应的写方法与校验逻辑 |
| `0x751` 强冷位 = 0x40，应按位判断 | **对**，且原厂 IL 用的就是 `Read | 0x40` / `Read & ~0x40` 的读改写 |
| `0x06000629 = ReadEC，0x0600062A = WriteEC` | **数值对，名字差一行**。文件里 token 行 1577 的名字是 `UnloadDrv`、1578 是 `Read`、1579 是 `Write`；按 +1 规则真实目标是 1578 `Read(string, ushort, ref byte)` 与 1579 `Write(string, ushort, byte)` |

新增结论：**`0x751 = 0x80 + level`（0x80 与 0x81–0x85）就是自定义风扇曲线的使能**，
这条信息原文档没有。

---

*报告生成：纯静态分析，未运行 OEM 程序、未写入任何 EC 寄存器、未修改任何既有文件。*
