﻿#Requires -RunAsAdministrator
<#
    install.ps1 —— 系统控制台（SysConsole）安装 / 升级脚本

    用法：
        powershell -NoProfile -ExecutionPolicy Bypass -File install.ps1

    流程：
        [1] 确认管理员权限
        [2] 停掉正在运行的 SysConsole（等到进程真正退出为止）
        [3] 把 bin\SysConsole.exe 复制到 %ProgramFiles%\SysConsole\
        [4] 顺带复制 docs\使用手册.md 和 README.md（存在才复制）
        [5] 用 --autostart on 注册开机自启（计划任务 SysConsoleAutostart）
        [6] 在开始菜单创建快捷方式
        [7] 逐项校验并汇总

    可以重复执行：已经装过就是覆盖升级，不会报错。

    编码说明：本文件必须保存为 UTF-8 带 BOM。Windows PowerShell 5.1 会把不带 BOM
    的 UTF-8 当成 GBK 解码，中文会全部乱码，甚至直接解析失败。
#>

$ErrorActionPreference = 'Stop'

# ------------------------------------------------------------------ 路径

$here = $PSScriptRoot
if ([string]::IsNullOrEmpty($here)) { $here = Split-Path -Parent $MyInvocation.MyCommand.Path }
$srcRoot = Split-Path -Parent $here                                  # installer\ 的上一级 = 项目根目录
$srcExe  = Join-Path $srcRoot 'bin\SysConsole.exe'

$dstRoot  = Join-Path $env:ProgramFiles 'SysConsole'
$dstExe   = Join-Path $dstRoot 'SysConsole.exe'
$taskName = 'SysConsoleAutostart'
$menuName = '系统控制台.lnk'
$lnkPath  = Join-Path $env:ProgramData ('Microsoft\Windows\Start Menu\Programs\' + $menuName)

# ------------------------------------------------------------------ 输出助手

function Say  ($t) { Write-Host $t }
function Step ($n, $t) { Write-Host ('  [' + $n + '] ' + $t) -ForegroundColor Cyan }
function Ok   ($t) { Write-Host ('      ' + $t) -ForegroundColor Gray }
function Warn ($t) { Write-Host ('      ' + $t) -ForegroundColor Yellow }
function Die  ($t) {
    Write-Host ''
    Write-Host ('安装失败：' + $t) -ForegroundColor Red
    Write-Host ''
    exit 1
}

Say ''
Write-Host '============================================================' -ForegroundColor Cyan
Write-Host '   系统控制台 SysConsole  -  安装 / 升级' -ForegroundColor Cyan
Write-Host '============================================================' -ForegroundColor Cyan

# ------------------------------------------------------------------ [1] 权限

Step 1 '检查管理员权限'
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Die '需要管理员权限。请右键选择“以管理员身份运行”，或直接双击 setup.cmd（它会自动提权）。'
}
Ok '已具备管理员权限'

# ------------------------------------------------------------------ [2] 停旧实例

Step 2 '停止正在运行的 SysConsole'
$procs = @(Get-Process -Name 'SysConsole' -ErrorAction SilentlyContinue)
if ($procs.Count -eq 0) {
    Ok '当前没有正在运行的实例'
} else {
    foreach ($p in $procs) {
        Ok ('结束进程 PID ' + $p.Id)
        try { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue } catch { }
    }
    # 必须等它真的退出：进程没走干净时复制 exe 会因为文件被占用而失败
    $gone = $false
    for ($i = 0; $i -lt 24; $i++) {
        Start-Sleep -Milliseconds 500
        if (@(Get-Process -Name 'SysConsole' -ErrorAction SilentlyContinue).Count -eq 0) { $gone = $true; break }
    }
    if ($gone) { Ok '进程已全部退出' }
    else { Die 'SysConsole 仍在运行，无法替换程序文件。请手动结束它（任务管理器或托盘右键退出）后重试。' }
}

# ------------------------------------------------------------------ [3] 复制主程序

Step 3 '复制程序文件到 ' + $dstRoot
if (-not (Test-Path -LiteralPath $srcExe)) {
    Die ('找不到 ' + $srcExe + '。请先在项目根目录运行 build.ps1 编译出 bin\SysConsole.exe。')
}
if (Test-Path -LiteralPath $dstExe) {
    Ok '检测到已安装，执行覆盖升级（脚本是幂等的，可以反复运行）'
}
try {
    if (-not (Test-Path -LiteralPath $dstRoot)) { New-Item -ItemType Directory -Path $dstRoot -Force | Out-Null }
    Copy-Item -LiteralPath $srcExe -Destination $dstExe -Force
} catch {
    Die ('复制失败：' + $_.Exception.Message + '（目标目录 ' + $dstRoot + '）')
}
if (-not (Test-Path -LiteralPath $dstExe)) { Die '复制后仍找不到目标文件，请检查磁盘权限。' }
Ok ($dstExe + '  (' + (Get-Item -LiteralPath $dstExe).Length + ' 字节)')

# ------------------------------------------------------------------ [4] 文档

Step 4 '复制说明文档'
$docs = @(
    (Join-Path $srcRoot 'docs\使用手册.md'),
    (Join-Path $srcRoot 'README.md')
)
$docCount = 0
foreach ($d in $docs) {
    if (Test-Path -LiteralPath $d) {
        try {
            Copy-Item -LiteralPath $d -Destination $dstRoot -Force
            Ok ('已复制 ' + (Split-Path -Leaf $d))
            $docCount++
        } catch {
            Warn ('复制 ' + (Split-Path -Leaf $d) + ' 失败：' + $_.Exception.Message)
        }
    } else {
        Warn ('跳过（源文件不存在）：' + $d)
    }
}
if ($docCount -eq 0) { Warn '没有任何文档被复制，安装仍然可以继续。' }

# ------------------------------------------------------------------ [5] 开机自启

Step 5 '注册开机自启（计划任务 ' + $taskName + '）'
try {
    $out = & $dstExe --autostart on 2>&1
    $text = (($out | Out-String).Trim()) -replace "`r?`n", '  |  '
    if ([string]::IsNullOrEmpty($text)) { Warn '程序没有返回任何信息' } else { Ok $text }
} catch {
    Warn ('注册自启时出错：' + $_.Exception.Message)
    Warn '可以稍后手动执行： "' + $dstExe + '" --autostart on'
}

# ------------------------------------------------------------------ [6] 快捷方式

Step 6 '创建开始菜单快捷方式'
$deskLnk = Join-Path ([Environment]::GetFolderPath('Desktop')) $menuName
try {
    $shell = New-Object -ComObject WScript.Shell

    # 开始菜单
    $sc = $shell.CreateShortcut($lnkPath)
    $sc.TargetPath = $dstExe
    $sc.WorkingDirectory = $dstRoot
    $sc.Description = '系统控制台 - 机械革命 GM6AR57C 温度 / 风扇 / 键盘背光控制'
    $sc.IconLocation = $dstExe + ',0'
    $sc.Save()
    Ok $lnkPath

    # 桌面（勾上「以管理员身份运行」：控件要改电源和风扇，非管理员时功能是残的）
    $sc2 = $shell.CreateShortcut($deskLnk)
    $sc2.TargetPath = $dstExe
    $sc2.WorkingDirectory = $dstRoot
    $sc2.Description = '系统控制台 - 机械革命 GM6AR57C 温度 / 风扇 / 键盘背光控制'
    $sc2.IconLocation = $dstExe + ',0'
    $sc2.Save()
    $b = [IO.File]::ReadAllBytes($deskLnk)
    $b[0x15] = $b[0x15] -bor 0x20
    [IO.File]::WriteAllBytes($deskLnk, $b)
    Ok ($deskLnk + '  （已勾选以管理员身份运行）')
} catch {
    Warn ('创建快捷方式失败：' + $_.Exception.Message)
    Warn '不影响使用，可以直接运行 ' + $dstExe
}

# ------------------------------------------------------------------ [7] 校验

Step 7 '校验安装结果'
$problems = 0

if (Test-Path -LiteralPath $dstExe) {
    Ok ('程序     : ' + $dstExe)
} else {
    Warn '程序     : 未就位'
    $problems++
}

$task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
if ($task) {
    Ok ('开机自启 : ' + $task.State + '，运行级别 ' + $task.Principal.RunLevel)
    Ok ('启动命令 : ' + $task.Actions[0].Execute + ' ' + $task.Actions[0].Arguments)
} else {
    Warn '开机自启 : 计划任务未注册'
    $problems++
}

if (Test-Path -LiteralPath $deskLnk) {
    Ok ('桌面快捷方式 : ' + $deskLnk)
} else {
    Warn '桌面快捷方式 : 缺失'
}
if (Test-Path -LiteralPath $lnkPath) {
    Ok ('快捷方式 : ' + $lnkPath)
} else {
    Warn '快捷方式 : 缺失'
    $problems++
}

$cfgDir = Join-Path $env:LOCALAPPDATA 'SysConsole'
Ok ('配置日志 : ' + $cfgDir + '（首次运行后生成）')

# ------------------------------------------------------------------ 汇总

Say ''
if ($problems -eq 0) {
    Write-Host '安装完成。' -ForegroundColor Green
} else {
    Write-Host ('安装完成，但有 ' + $problems + ' 项需要留意（见上面的黄色提示）。') -ForegroundColor Yellow
}
Say ''
Write-Host '  安装位置 : ' -NoNewline; Say $dstRoot
Write-Host '  卸载方法 : ' -NoNewline; Say ('以管理员身份运行 installer\uninstall.ps1，或双击 setup.cmd 所在目录的卸载脚本')
Write-Host '  关掉自启 : ' -NoNewline; Say ('"' + $dstExe + '" --autostart off')
Say ''
Write-Host '  如果托盘图标没有出现：' -ForegroundColor Yellow
Say        '    开机自启是「登录时触发」的计划任务，注销重新登录一次即可；'
Say        '    也可以立刻手动跑一次：'
Say        ('      schtasks /Run /TN ' + $taskName)
Say        ('    或者直接双击：' + $dstExe)
Say ''
Write-Host '  源码目录可以保留，也可以自行删除，不影响已安装的程序。'
Say ''
exit 0
