// ============================================================================
//  SysConsole — MainForm.cs
//  主窗口，也是整个界面的唯一实现文件（布局、自绘、交互、闭环控制都在这）。
//
//  主要内容：
//    PalettePanel          键盘背光调色板控件（自绘网格，点击取色）
//    UiScaleStore          界面缩放设置的持久化
//    MainForm.BuildUi()    全部布局；数值写成"设计值"，由 S()/Sf() 按缩放系数换算
//    MainForm.PaintXxx()   温度区/曲线图/逐核条/内存条的自绘
//    WallTick/GuardTick    温度墙（闭环）与超温保护（二元兜底）的控制逻辑
//    RebuildUi()           改缩放系数后整界面重建
//
//  界面约定：只有两张顶层卡片（系统监控 / 操作面板），分区标题只锚 Left（锚成
//  Left|Right 会横向拉长并盖住右边的标签），同一容器内不允许控件矩形相交。
//
//    · 编译：系统自带 csc.exe（.NET Framework 4.8），无 SDK / 无网络 / 无第三方库
//    · 语法：C# 5，不用 async/await、字符串插值、nameof 等新语法
//    · 编码：UTF-8；.ps1 脚本另需纯 ASCII 或带 BOM，否则 PS 5.1 会按 GBK 解码
//    · 硬件寄存器地址来自原厂文件反汇编 + 本机实测，出处见 docs/ 下的协议文档
// ============================================================================

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace SysConsole
{
    // Panel that paints without flicker. Control.DoubleBuffered is protected,
    // so the flag has to be set from inside a subclass.
    public class BuffPanel : Panel
    {
        public BuffPanel()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.UserPaint |
                     ControlStyles.ResizeRedraw, true);
        }
    }

    /// <summary>
    /// 调色板：按网格铺一堆色块，点哪块就把那块的颜色交给回调。
    /// 用自绘而不是几十个 Button —— 控件数量不涨、窗口拉宽时格子自动重新排布，
    /// 看起来也更像"调色板"而不是一排按钮。
    /// </summary>
    public class PalettePanel : BuffPanel
    {
        public Color[] Swatches;
        public int Columns = 1;
        public int SelectedIndex = -1;
        public event Action<Color> Pick;

        ToolTip _tip = new ToolTip();

        public PalettePanel()
        {
            // 露出来的 1 像素背景色就是格子线
            BackColor = Color.FromArgb(226, 230, 236);
            _tip.InitialDelay = 250;
        }

        int Rows
        {
            get
            {
                if (Swatches == null || Swatches.Length == 0) return 1;
                return Math.Max(1, (Swatches.Length + Columns - 1) / Columns);
            }
        }
        int CellW { get { return Math.Max(1, ClientSize.Width / Math.Max(1, Columns)); } }
        int CellH { get { return Math.Max(1, ClientSize.Height / Rows); } }

        int IndexAt(int x, int y)
        {
            if (Swatches == null || Swatches.Length == 0) return -1;
            int c = x / CellW, r = y / CellH;
            if (c < 0 || c >= Columns || r < 0 || r >= Rows) return -1;
            int i = r * Columns + c;
            return (i >= 0 && i < Swatches.Length) ? i : -1;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if (Swatches == null) return;
            int cw = CellW, ch = CellH;
            for (int i = 0; i < Swatches.Length; i++)
            {
                int r = i / Columns, c = i % Columns;
                int x = c * cw + 1, y = r * ch + 1;
                int w = Math.Min(cw - 2, ClientSize.Width - x);
                int h = Math.Min(ch - 2, ClientSize.Height - y);
                if (w <= 2 || h <= 2) continue;
                w -= 1; h -= 1;
                using (SolidBrush br = new SolidBrush(Swatches[i]))
                    e.Graphics.FillRectangle(br, x, y, w, h);
                if (i == SelectedIndex && w > 3 && h > 3)
                {
                    e.Graphics.DrawRectangle(Pens.Black, x, y, w - 1, h - 1);
                    e.Graphics.DrawRectangle(Pens.White, x + 1, y + 1, w - 3, h - 3);
                }
            }
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            int i = IndexAt(e.X, e.Y);
            if (i < 0) return;
            SelectedIndex = i;
            Invalidate();
            if (Pick != null) Pick(Swatches[i]);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            int i = IndexAt(e.X, e.Y);
            if (i < 0) { _tip.SetToolTip(this, "点一个色块即可改键盘背光颜色"); return; }
            Color c = Swatches[i];
            _tip.SetToolTip(this, string.Format(CultureInfo.InvariantCulture,
                "RGB({0}, {1}, {2})  —  点击应用", c.R, c.G, c.B));
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && _tip != null) { _tip.Dispose(); _tip = null; }
            base.Dispose(disposing);
        }
    }

    /// <summary>
    /// 界面缩放设置的持久化。窗口总高 = 设计客户区高 × 系数 + 边框，所以上限由
    /// 屏幕可用高度决定 —— 超了窗口底部会被切掉，这里直接算出来并夹住。
    /// </summary>
    public static class UiScaleStore
    {
        public const int Min = 80;
        public const int HardMax = 125;
        public const int Step = 5;
        public const int Fallback = 120;

        const int BaseClientH = 1174;   // 100% 时的客户区高度
        const int ChromeH = 56;         // 标题栏 + 边框

        public static string FilePath() { return Path.Combine(Log.Dir(), "uiscale.txt"); }

        public static int MaxForScreen()
        {
            int avail;
            try { avail = Screen.PrimaryScreen.WorkingArea.Height - ChromeH - 8; }
            catch { return HardMax; }
            int pct = (int)Math.Floor(avail * 100.0 / BaseClientH);
            if (pct > HardMax) pct = HardMax;
            if (pct < Min) pct = Min;
            return pct;
        }

        public static int Clamp(int pct)
        {
            int hi = MaxForScreen();
            if (pct > hi) pct = hi;
            if (pct < Min) pct = Min;
            return pct;
        }

        public static int Load()
        {
            try
            {
                string p = FilePath();
                if (File.Exists(p))
                {
                    int v;
                    if (int.TryParse(File.ReadAllText(p).Trim(), NumberStyles.Integer,
                                     CultureInfo.InvariantCulture, out v))
                        return Clamp(v);
                }
            }
            catch { }
            return Clamp(Fallback);
        }

        public static void Save(int pct)
        {
            try { File.WriteAllText(FilePath(), pct.ToString(CultureInfo.InvariantCulture)); }
            catch { }
        }

        public static string[] Options()
        {
            List<string> l = new List<string>();
            int hi = MaxForScreen();
            for (int p = Min; p <= hi; p += Step) l.Add(p + "%");
            string top = hi + "%";
            if (l.Count == 0 || l[l.Count - 1] != top) l.Add(top);   // 上限按屏幕算，未必是整档
            return l.ToArray();
        }

        public static string Label(int pct) { return pct + "%"; }

        public static int PercentOf(string s)
        {
            if (string.IsNullOrEmpty(s)) return -1;
            int v;
            return int.TryParse(s.TrimEnd('%'), NumberStyles.Integer, CultureInfo.InvariantCulture, out v) ? v : -1;
        }
    }

    public class MainForm : Form
    {
        // ---- data plumbing ----
        readonly object _lock = new object();
        Snapshot _snap = new Snapshot();
        Thread _thread;
        volatile bool _stop;
        readonly List<double> _history = new List<double>();
        const int HistoryMax = 180;

        // ---- ui ----
        // 只用两个大卡片：上面「系统监控」全部只读，下面「操作面板」容纳所有可
        // 操作项。原先操作项散落在三个互不相邻的分组里（场景与风扇 / 温度保护 /
        // 详细设置），视线要来回跳；风扇转速这种监控值还被塞进了操作区。
        GroupBox gbMonitor, gbControl;
        Panel pnlZones, pnlGraph, pnlCores, pnlMem;
        Panel sep1, sep2;
        Label lblThrottle, lblCpu, lblMem, lblPresetDesc, lblMaxVal, lblMinVal, lblMaxTitle, lblMinTitle;
        Label lblCoreLegend;
        Label lblGuardStatus, lblFan, lblWallStatus;
        Label lblSec1, lblSec2, lblSec3;
        Button btnPerf, btnBalanced, btnQuiet, btnFanBoost, btnApply, btnElevate, btnHotkey;
        Button btnMin0, btnMin5, btnMin50, btnMin100;
        CheckBox chkTurbo, chkAutoStart, chkGuard, chkWall, chkWallBoost, chkWallTurbo;
        NumericUpDown numTrigger, numRelease, numLimit, numWallTarget, numMax, numMin;

        // ---- 键盘背光颜色 ----
        Panel sep3;
        Label lblSec4, lblLightStatus;
        Button btnSwatch, btnLightDefault;
        PalettePanel paletteLight;
        CheckBox chkLightRemember;
        int _lightR = -1, _lightG = -1, _lightB = -1;
        const int LightPaletteCols = 35;   // 两排 35 格 = 70 个颜色
        bool _syncMax, _syncMin;        // 滑块 ↔ 数值框双向同步的重入保护
        ThermalWallConfig _wallCfg = new ThermalWallConfig();
        int _wallApplied = -1;          // 温度墙当前下发的处理器上限（-1 = 未接管）
        int _wallBaseState = -1;        // 用户设定的处理器上限（温度墙要收敛回去的目标）
        bool _wallActive;               // 温度墙是否正在压制
        bool _wallTurboDropped;         // 睿频是否由温度墙关闭
        bool _wallBoostByWall;          // 强冷是否由温度墙开启
        ThermalGuardConfig _guardCfg = new ThermalGuardConfig();
        bool _guardActive;
        bool _guardBlocked;
        PowerState _guardSaved;
        ToolStripMenuItem _trayAuto;
        ToolStripMenuItem _trayFanBoost;
        HotkeyManager _hotkeys;
        HotkeyStore.Config _hotkeyCfg = new HotkeyStore.Config();
        ComboBox cmbMode, cmbCool;
        TrackBar tbMax, tbMin;
        StatusStrip status;
        ToolStripStatusLabel stStatus, stElev, stAuto, stHot;
        NotifyIcon _tray;
        System.Windows.Forms.Timer _timer;
        System.Windows.Forms.Timer _lightTimer;
        bool _startHidden;
        bool _skipTray;
        int _normalW, _normalH;         // last size while not maximized
        bool _restoringState;
        bool _reallyExit;
        bool _loading;
        string _lastPreset = "";

        // 界面缩放：_uiPct 是用户设定（百分比），字体与实际尺寸都按它算
        int _uiPct = UiScaleStore.Load();
        Font fTitle, fBig, fNormal, fSmall, fSect;
        ComboBox cmbScale;

        static readonly Color CBack = Color.FromArgb(250, 250, 252);
        static readonly Color CCard = Color.White;
        static readonly Color CLine = Color.FromArgb(226, 230, 236);
        static readonly Color CText = Color.FromArgb(32, 36, 44);
        static readonly Color CSub = Color.FromArgb(120, 128, 140);
        static readonly Color CAccent = Color.FromArgb(0, 120, 212);
        static readonly Color CGreen = Color.FromArgb(16, 137, 62);
        static readonly Color CWarn = Color.FromArgb(196, 108, 0);
        static readonly Color CDanger = Color.FromArgb(196, 43, 28);

        public MainForm(bool startHidden) : this(startHidden, false) { }

        public MainForm(bool startHidden, bool skipTray)
        {
            _startHidden = startHidden;
            _skipTray = skipTray;
            BuildUi();
            if (!skipTray) BuildTray();
            Load += OnLoaded;
            FormClosing += OnClosing;
        }

        // ------------------------------------------------------------- layout

        void BuildUi()
        {
            ApplyScaledFonts();
            Text = "系统控制台  —  机械革命 GM6AR57C";
            // 先放开 MinimumSize 再设 ClientSize：切换缩放重建时，上一档的最小尺寸
            // 还卡在那里，直接设更小的 ClientSize 会被它顶回去，窗口根本缩不下来。
            // 真正的最小尺寸在锚定那段之后按本档算好再设。
            MinimumSize = new Size(0, 0);
            ClientSize = new Size(S(900), S(1174));
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = CBack;
            Font = fNormal;
            // 缩放全部由 S()/Sf() 手工完成，必须关掉 WinForms 自带的字体自动缩放 ——
            // 否则每次重建界面（换字体）它都会再叠一层，窗口会越缩越大。
            AutoScaleMode = AutoScaleMode.None;
            DoubleBuffered = true;

            // ============================================================
            //  布局原则：只保留两个大卡片，操作项不再割裂
            //    「系统监控」= 温度 + 曲线 + 处理器 + 内存 + 风扇转速（全只读）
            //    「操作面板」= 场景与风扇 / 温度保护 / 精细控制（分区标题+分隔线）
            // ============================================================

            // ---------------- 卡片一：系统监控（全部只读） ----------------
            gbMonitor = MakeGroup("系统监控（只读）", S(12), S(8), S(876), S(474));

            pnlZones = MakePanel(S(14), S(30), S(852), S(86));
            pnlZones.Paint += PaintZones;
            lblThrottle = MakeLabel("节流状态: --", S(16), S(124), S(848), S(20), fNormal, CSub);
            // 风扇转速是监控数据，从操作区移到这里，和温度放在一起看
            lblFan = MakeLabel("", S(16), S(152), S(848), S(20), fNormal, CAccent);
            pnlGraph = MakePanel(S(14), S(180), S(852), S(130));
            pnlGraph.Paint += PaintGraph;
            // 初始文字取最宽的取值，好让无界面自检按最坏情况量一次 ——
            // 这行是运行时刷新的，空字符串起不到校验作用。
            lblCpu = MakeLabel("处理器总占用: 100.0%      相对基准性能: 999%      报告频率: 9999 MHz      逻辑核心: 99",
                               S(16), S(320), S(848), S(22), fNormal, CText);
            pnlCores = MakePanel(S(14), S(350), S(848), S(58));
            pnlCores.Paint += PaintCores;
            // 逐核图例挂在柱状图自己身上、占顶上一条，柱子从它下面开始画：
            // 既不压柱子，也不跟「处理器」那行抢横向空间。
            string coreLegend = "蓝 = P 核 (0-15)    紫 = E 核 (16-23)";
            int legendW = TextW(coreLegend, fSmall) + 8;
            lblCoreLegend = MakeLabel(coreLegend, S(848) - legendW - S(6), S(1), legendW, S(17), fSmall, CSub);
            lblCoreLegend.TextAlign = ContentAlignment.MiddleRight;
            lblCoreLegend.Name = "lblCoreLegend";
            pnlCores.Controls.Add(lblCoreLegend);
            lblMem = MakeLabel("内存: --", S(16), S(418), S(848), S(20), fNormal, CText);
            pnlMem = MakePanel(S(14), S(446), S(848), S(14));
            pnlMem.Paint += PaintMem;

            gbMonitor.Controls.Add(pnlZones);
            gbMonitor.Controls.Add(lblThrottle);
            gbMonitor.Controls.Add(lblFan);
            gbMonitor.Controls.Add(pnlGraph);
            gbMonitor.Controls.Add(lblCpu);
            gbMonitor.Controls.Add(pnlCores);
            gbMonitor.Controls.Add(lblMem);
            gbMonitor.Controls.Add(pnlMem);

            // ---------------- 卡片二：操作面板 ----------------
            gbControl = MakeGroup("操作面板", S(12), S(496), S(876), S(636));

            // ---- 分区 1：场景与风扇 ----
            lblSec1 = MakeLabel("场景与风扇", S(16), S(30), S(300), S(18), fSect, CText);
            gbControl.Controls.Add(lblSec1);

            btnPerf = MakeButton("性能模式", S(16), S(50), S(190), S(36));
            btnBalanced = MakeButton("均衡模式", S(228), S(50), S(190), S(36));
            btnQuiet = MakeButton("静音模式", S(440), S(50), S(190), S(36));
            btnFanBoost = MakeButton("一键强冷", S(652), S(50), S(190), S(36));
            btnPerf.Click += delegate { ApplyPresetByKey("performance"); };
            btnBalanced.Click += delegate { ApplyPresetByKey("balanced"); };
            btnQuiet.Click += delegate { ApplyPresetByKey("quiet"); };
            btnFanBoost.Click += OnFanBoostClick;
            lblPresetDesc = MakeLabel("", S(16), S(98), S(848), S(18), fSmall, CSub);

            gbControl.Controls.Add(btnPerf);
            gbControl.Controls.Add(btnBalanced);
            gbControl.Controls.Add(btnQuiet);
            gbControl.Controls.Add(btnFanBoost);
            gbControl.Controls.Add(lblPresetDesc);

            sep1 = MakeSeparator(S(14), S(120), S(848));
            gbControl.Controls.Add(sep1);

            // ---- 分区 2：温度保护 ----
            // 温度墙 = 闭环连续控制：把"最高温度"当目标，按偏差逐步加减处理器上限，
            //          让温度收敛在目标附近，而不是撞上去再退回来。
            // 超温保护 = 二元兜底：越过触发点才一次性限功耗，回落到解除温度才恢复。
            // 两者可叠加：温度墙管日常收敛，超温保护管最后的硬保险。
            lblSec2 = MakeLabel("温度保护", S(16), S(128), S(300), S(18), fSect, CText);
            gbControl.Controls.Add(lblSec2);

            // ---- 温度墙 ----
            Row rw = new Row(gbControl, S(16));

            chkWall = AutoCheck("温度墙", fNormal);
            chkWall.Top = S(150);
            chkWall.CheckedChanged += OnWallEnableChanged;
            rw.Add(chkWall, S(22));

            Label wtLbl = AutoLabel("目标", fNormal, CText); wtLbl.Top = S(152);
            rw.Add(wtLbl, S(10));
            numWallTarget = AutoNum(fNormal, S(50), S(100), S(85)); numWallTarget.Top = S(150);
            numWallTarget.ValueChanged += OnWallValueChanged;
            rw.Add(numWallTarget, S(10));
            Label wtUnit = AutoLabel("°C", fNormal, CSub); wtUnit.Top = S(152);
            rw.Add(wtUnit, S(26));

            chkWallTurbo = AutoCheck("明显超温时关睿频", fNormal);
            chkWallTurbo.Top = S(150);
            chkWallTurbo.CheckedChanged += OnWallValueChanged;
            rw.Add(chkWallTurbo, S(26));

            chkWallBoost = AutoCheck("接近时自动开强冷", fNormal);
            chkWallBoost.Top = S(150);
            chkWallBoost.CheckedChanged += OnWallValueChanged;
            rw.Add(chkWallBoost, S(0));

            // ---- 超温保护（兜底） ----
            Row rg = new Row(gbControl, S(16));

            chkGuard = AutoCheck("超温保护", fNormal);
            chkGuard.Top = S(184);
            chkGuard.CheckedChanged += OnGuardEnableChanged;
            rg.Add(chkGuard, S(20));

            Label gtLbl = AutoLabel("触发", fNormal, CText); gtLbl.Top = S(186);
            rg.Add(gtLbl, S(10));
            numTrigger = AutoNum(fNormal, S(55), S(105), S(88)); numTrigger.Top = S(184);
            numTrigger.ValueChanged += OnGuardValueChanged;
            rg.Add(numTrigger, S(10));
            Label gtUnit = AutoLabel("°C", fNormal, CSub); gtUnit.Top = S(186);
            rg.Add(gtUnit, S(16));

            Label grLbl = AutoLabel("解除", fNormal, CText); grLbl.Top = S(186);
            rg.Add(grLbl, S(10));
            numRelease = AutoNum(fNormal, S(50), S(100), S(78)); numRelease.Top = S(184);
            numRelease.ValueChanged += OnGuardValueChanged;
            rg.Add(numRelease, S(10));
            Label grUnit = AutoLabel("°C", fNormal, CSub); grUnit.Top = S(186);
            rg.Add(grUnit, S(16));

            Label glLbl = AutoLabel("限功耗至", fNormal, CText); glLbl.Top = S(186);
            rg.Add(glLbl, S(10));
            numLimit = AutoNum(fNormal, S(20), S(100), S(60)); numLimit.Top = S(184);
            numLimit.ValueChanged += OnGuardValueChanged;
            rg.Add(numLimit, S(10));
            Label glUnit = AutoLabel("% 上限", fNormal, CSub); glUnit.Top = S(186);
            rg.Add(glUnit, S(0));

            // ---- 合并状态 ----
            lblGuardStatus = MakeLabel("", S(16), S(212), S(848), S(18), fSmall, CSub);
            gbControl.Controls.Add(lblGuardStatus);
            lblWallStatus = lblGuardStatus;   // 兼容既有刷新逻辑

            sep2 = MakeSeparator(S(14), S(242), S(848));
            gbControl.Controls.Add(sep2);

            // ---- 分区 3：精细控制 ----
            // 两条滑块结构完全一致：标签 + 可拉伸的滑块 + 可直接键入的数值框 + 单位，
            // 左右两端对齐、宽度随窗口一起变。以前滑块只有 280px 却要覆盖 0-100，
            // 只能靠拖，现在既能拖也能敲确切数字。
            lblSec3 = MakeLabel("精细控制", S(16), S(254), S(160), S(18), fSect, CText);
            gbControl.Controls.Add(lblSec3);

            Label lHint = MakeLabel("最小处理器状态 = CPU 频率下限：0% 最凉省电，100% 锁高频最热",
                                    S(190), S(254), S(670), S(18), fSmall, CSub);
            lHint.TextAlign = ContentAlignment.MiddleRight;
            lHint.Name = "lHint";
            gbControl.Controls.Add(lHint);

            // ---- 第 1 行：睿频 / 电源模式 / 散热策略 / 开机自启 ----
            Row r1 = new Row(gbControl, S(16));
            chkTurbo = AutoCheck("睿频加速", fNormal);
            chkTurbo.Top = S(282);
            chkTurbo.CheckedChanged += delegate { UpdatePresetLabel(); };
            r1.Add(chkTurbo, S(22));

            Label lm = AutoLabel("电源模式", fNormal, CText); lm.Top = S(284);
            r1.Add(lm, S(10));
            cmbMode = AutoCombo(fNormal, new string[] { "平衡", "最佳性能", "最佳能效" });
            cmbMode.Top = S(280);
            r1.Add(cmbMode, S(28));

            Label lc = AutoLabel("散热策略", fNormal, CText); lc.Top = S(284);
            r1.Add(lc, S(10));
            cmbCool = AutoCombo(fNormal, new string[] { "被动（先降频）", "主动（先加速风扇）" });
            cmbCool.Top = S(280);
            r1.Add(cmbCool, S(28));

            chkAutoStart = AutoCheck("开机自启动", fNormal);
            chkAutoStart.Top = S(282);
            chkAutoStart.CheckedChanged += OnAutoStartChanged;
            chkAutoStart.Left = S(860) - chkAutoStart.Width;   // 贴右
            gbControl.Controls.Add(chkAutoStart);

            // ---- 第 2 行：最大处理器状态 ----
            lblMaxTitle = AutoLabel("最大处理器状态", fNormal, CText);
            lblMaxTitle.Top = S(324); lblMaxTitle.Left = S(16);
            gbControl.Controls.Add(lblMaxTitle);

            tbMax = new TrackBar();
            tbMax.Minimum = 5; tbMax.Maximum = 100;
            // 关掉刻度线：默认刻度会把 TrackBar 撑到 69px 高，视觉上压到下一行；
            // 精确值交给右边可以直接键入的数值框，滑块只负责快速拖动。
            tbMax.AutoSize = false;
            tbMax.TickStyle = TickStyle.None;
            tbMax.TickFrequency = 1;
            tbMax.Top = S(320); tbMax.Left = S(134); tbMax.Size = new Size(S(620), S(32));
            tbMax.ValueChanged += delegate
            {
                // 用户改了上限 → 这就是新的基线，温度墙把控制权交还给他重新收敛
                if (!_loading)
                {
                    _wallBaseState = tbMax.Value;
                    if (_wallCfg.Enabled && _wallCfg.BaseState != tbMax.Value)
                    {
                        _wallCfg.BaseState = tbMax.Value;
                        WallStore.Save(_wallCfg);
                    }
                    if (_wallApplied > 0) { _wallApplied = -1; _wallActive = false; }
                }
                // 拖动滑块 → 数值框跟随（_syncMax 防止两边互相触发）
                if (!_syncMax && numMax != null && numMax.Value != tbMax.Value)
                {
                    _syncMax = true;
                    try { numMax.Value = Clamp(tbMax.Value, (int)numMax.Minimum, (int)numMax.Maximum); }
                    finally { _syncMax = false; }
                }
                UpdatePresetLabel();
            };
            gbControl.Controls.Add(tbMax);

            numMax = AutoNum(fNormal, tbMax.Minimum, tbMax.Maximum, 100);
            numMax.Top = S(322); numMax.Left = S(762); numMax.Width = S(60);
            numMax.ValueChanged += delegate
            {
                if (_syncMax) return;
                _syncMax = true;
                try { tbMax.Value = Clamp((int)numMax.Value, tbMax.Minimum, tbMax.Maximum); }
                finally { _syncMax = false; }
            };
            gbControl.Controls.Add(numMax);

            lblMaxVal = AutoLabel("%", fNormal, CSub);
            lblMaxVal.Top = S(324); lblMaxVal.Left = S(830); lblMaxVal.Width = S(38);
            gbControl.Controls.Add(lblMaxVal);

            // ---- 第 3 行：最小处理器状态（与上一行结构完全一致） ----
            lblMinTitle = AutoLabel("最小处理器状态", fNormal, CText);
            lblMinTitle.Top = S(364); lblMinTitle.Left = S(16);
            gbControl.Controls.Add(lblMinTitle);

            tbMin = new TrackBar();
            tbMin.Minimum = 0; tbMin.Maximum = 100;
            tbMin.AutoSize = false;
            tbMin.TickStyle = TickStyle.None;
            tbMin.TickFrequency = 1;
            tbMin.Top = S(360); tbMin.Left = S(134); tbMin.Size = new Size(S(620), S(32));
            tbMin.ValueChanged += delegate
            {
                if (!_syncMin && numMin != null && numMin.Value != tbMin.Value)
                {
                    _syncMin = true;
                    try { numMin.Value = Clamp(tbMin.Value, (int)numMin.Minimum, (int)numMin.Maximum); }
                    finally { _syncMin = false; }
                }
                UpdatePresetLabel();
            };
            gbControl.Controls.Add(tbMin);

            numMin = AutoNum(fNormal, tbMin.Minimum, tbMin.Maximum, 5);
            numMin.Top = S(362); numMin.Left = S(762); numMin.Width = S(60);
            numMin.ValueChanged += delegate
            {
                if (_syncMin) return;
                _syncMin = true;
                try { tbMin.Value = Clamp((int)numMin.Value, tbMin.Minimum, tbMin.Maximum); }
                finally { _syncMin = false; }
            };
            gbControl.Controls.Add(numMin);

            lblMinVal = AutoLabel("%", fNormal, CSub);
            lblMinVal.Top = S(364); lblMinVal.Left = S(830); lblMinVal.Width = S(38);
            gbControl.Controls.Add(lblMinVal);

            // ---- 第 4 行：最小状态的常用档位 ----
            // 0-100 之间慢慢拖很别扭，这四个档位覆盖了实际会用到的全部取值。
            // 点一下立即写入，不必再按「应用设置」。
            Label lq = AutoLabel("常用档位（立即生效）", fSmall, CSub);
            lq.Top = S(406); lq.Left = S(16);
            gbControl.Controls.Add(lq);

            btnMin0 = MakeButton("0%　允许深度降频", S(16), S(432), S(196), S(30));
            btnMin5 = MakeButton("5%　默认均衡", S(232), S(432), S(196), S(30));
            btnMin50 = MakeButton("50%　保底中频", S(448), S(432), S(196), S(30));
            btnMin100 = MakeButton("100%　锁定最高频", S(664), S(432), S(196), S(30));
            btnMin0.Font = fSmall; btnMin5.Font = fSmall;
            btnMin50.Font = fSmall; btnMin100.Font = fSmall;
            btnMin0.Click += delegate { SetMinQuick(0); };
            btnMin5.Click += delegate { SetMinQuick(5); };
            btnMin50.Click += delegate { SetMinQuick(50); };
            btnMin100.Click += delegate { SetMinQuick(100); };
            gbControl.Controls.Add(btnMin0);
            gbControl.Controls.Add(btnMin5);
            gbControl.Controls.Add(btnMin50);
            gbControl.Controls.Add(btnMin100);

            // ---- 第 5 行：统一的操作按钮簇 ----
            // 「应用设置 / 快捷键设置 / 以管理员重启」以前分散在第 1 行和第 3 行，
            // 还会跟最小状态挤在一起。现在集中成一行并右对齐，与上面的参数区明确分开。
            // ---- 界面缩放：人工调节全部文字和板块的大小 ----
            Row rsc = new Row(gbControl, S(16));
            Label lScale = AutoLabel("界面缩放", fNormal, CText); lScale.Top = S(485);
            rsc.Add(lScale, S(10));
            cmbScale = AutoCombo(fNormal, UiScaleStore.Options());
            cmbScale.Top = S(479);
            cmbScale.Name = "cmbScale";
            cmbScale.SelectedItem = UiScaleStore.Label(_uiPct);
            if (cmbScale.SelectedIndex < 0) cmbScale.SelectedIndex = cmbScale.Items.Count - 1;
            cmbScale.SelectedIndexChanged += OnScaleChanged;
            rsc.Add(cmbScale, 0);

            btnApply = MakeButton("应用设置", S(368), S(480), S(150), S(32));
            btnApply.Click += OnApplyClick;
            gbControl.Controls.Add(btnApply);

            btnHotkey = MakeButton("快捷键设置…", S(534), S(480), S(150), S(32));
            btnHotkey.Click += OnHotkeySettingsClick;
            gbControl.Controls.Add(btnHotkey);

            btnElevate = MakeButton("以管理员重启", S(700), S(480), S(160), S(32));
            btnElevate.Click += OnElevateClick;
            gbControl.Controls.Add(btnElevate);

            // ---- 分区 4：键盘背光颜色 ----
            // 颜色协议从原厂 DefaultTool.exe 反汇编还原并实测通过：
            //   写 0x769/0x76A/0x76B 三个"电平"，再把 0x767 的 bit5 置 1 提交。
            // 电平有效范围 1..50，所以界面上给的是常规 0..255 RGB，内部按原厂
            // 公式换算（R/5、G/6、B/6，夹到 1..50）。直接把 0..255 写进寄存器
            // 会超范围，EC 会把背光关掉——这正是之前踩过的坑。
            sep3 = MakeSeparator(S(14), S(534), S(848));
            sep3.Name = "sep3";
            gbControl.Controls.Add(sep3);

            lblSec4 = MakeLabel("键盘背光颜色", S(16), S(542), S(176), S(18), fSect, CText);
            lblSec4.Name = "lblSec4";
            gbControl.Controls.Add(lblSec4);

            // 状态文字用最宽的取值当初始值：无界面自检会照这个宽度校验有没有被裁，
            // 运行时的实际数值只会更短。
            lblLightStatus = MakeLabel("当前 50/50/50 ≈ RGB(255,255,255)   出厂 50/50/50",
                                       S(200), S(544), S(424), S(16), fSmall, CSub);
            lblLightStatus.AutoEllipsis = true;
            lblLightStatus.Name = "lblLightStatus";
            gbControl.Controls.Add(lblLightStatus);

            // 左边这块是"当前色"预览，点它打开系统取色器，可以选调色板里没有的
            // 精确颜色；右边的调色板负责常用色一点即改。
            btnSwatch = new Button();
            btnSwatch.Left = S(16); btnSwatch.Top = S(574); btnSwatch.Width = S(64); btnSwatch.Height = S(38);
            btnSwatch.FlatStyle = FlatStyle.Flat;
            btnSwatch.FlatAppearance.BorderColor = CLine;
            btnSwatch.BackColor = CBack;
            btnSwatch.Text = "";
            btnSwatch.TabStop = false;
            btnSwatch.Name = "btnSwatch";
            btnSwatch.Click += OnSwatchClick;
            gbControl.Controls.Add(btnSwatch);

            paletteLight = new PalettePanel();
            paletteLight.Left = S(92); paletteLight.Top = S(574);
            paletteLight.Width = S(764); paletteLight.Height = S(38);
            paletteLight.Columns = LightPaletteCols;
            paletteLight.Swatches = BuildLightPalette(LightPaletteCols);
            paletteLight.Name = "paletteLight";
            paletteLight.Pick += delegate(Color c) { ApplyLight(c, chkLightRemember.Checked); };
            gbControl.Controls.Add(paletteLight);

            chkLightRemember = AutoCheck("记住颜色", fSmall);
            chkLightRemember.Left = S(636); chkLightRemember.Top = S(541);
            chkLightRemember.Name = "chkLightRemember";
            chkLightRemember.CheckedChanged += OnLightRememberChanged;
            gbControl.Controls.Add(chkLightRemember);

            btnLightDefault = MakeButton("恢复出厂色", S(740), S(540), S(120), S(24));
            btnLightDefault.Font = fSmall;
            btnLightDefault.Name = "btnLightDefault";
            btnLightDefault.Click += OnLightDefaultClick;
            gbControl.Controls.Add(btnLightDefault);

            // ---------------- 自适应布局 ----------------
            // gbMonitor 同时锚定 Top+Bottom，吸收全部纵向余量（曲线图跟着变高）；
            // gbControl 锚定 Bottom，与底边的距离恒定。效果：无论窗口多大，两个
            // 卡片之间的间距都不变，只有监控区在纵向伸缩。
            // 最小高度取当前设计高度（客户区 1112 + 边框 56 = 1168）：曲线图和下面的
            // 三行是按"间距恒定"排的，窗口再往下缩就会把它们挤在一起，所以只许放大。
            MinimumSize = new Size(S(918), S(1220));

            gbMonitor.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
            pnlZones.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblThrottle.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblFan.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            pnlGraph.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
            // 曲线图下方的「处理器 / 逐核 / 内存」必须锚定 Bottom —— 它们原来锚的是
            // Top，窗口一拉高曲线图就向下长，直接把这三行盖住。改成贴底锚定后：
            // 卡片长高 Δ，曲线图长高 Δ（底边跟着走），下面三行也下移 Δ，
            // 彼此之间的间距完全不变。
            lblCpu.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lblCoreLegend.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pnlCores.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lblMem.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            pnlMem.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;

            gbControl.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            // 分区标题只锚 Left：它们本来就是短标题，锚成 Left|Right 会跟着卡片横向
            // 拉长，把右边同一行的标签整段盖住（后加入的控件在 z 序更下层）。
            // 之前 lblSec3 盖住 lHint、lblSec4 盖住背光状态文字就是这个问题。
            lblSec1.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            lblSec2.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            lblSec3.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            lblSec4.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            lblLightStatus.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblPresetDesc.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblGuardStatus.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            // 这条右对齐提示原本没锚定，窗口放大后它停在原地、不跟卡片右边缘走
            lHint.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            // 分隔线跟随卡片宽度拉伸，卡片内分区在任何窗口尺寸下都保持完整
            sep1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            sep2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            sep3.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

            // 右侧按钮簇统一锚定 Right，滑块锚定 Left+Right 以便拉长，
            // 数值标签也锚定 Right，于是它始终紧跟在滑块右端。
            btnApply.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnElevate.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnHotkey.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnLightDefault.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            chkLightRemember.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            paletteLight.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            chkAutoStart.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            tbMax.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            tbMin.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblMaxVal.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            lblMinVal.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            numMax.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            numMin.Anchor = AnchorStyles.Top | AnchorStyles.Right;

            // 整体放大已在源头完成：上面这些布局数值和字体尺寸都乘过 UiScale，
            // 运行时不再二次缩放（Scale() 只缩窗体自身，手工改 Bounds 会被锚定弹回）。

            // 名称供无界面 --uitest 布局校验使用
            gbMonitor.Name = "gbMonitor"; pnlZones.Name = "pnlZones"; pnlGraph.Name = "pnlGraph";
            pnlCores.Name = "pnlCores"; pnlMem.Name = "pnlMem"; lblFan.Name = "lblFan";
            lblCpu.Name = "lblCpu"; lblMem.Name = "lblMem";
            gbControl.Name = "gbControl"; lblPresetDesc.Name = "lblPresetDesc";
            chkGuard.Name = "chkGuard";
            chkWall.Name = "chkWall"; numWallTarget.Name = "numWallTarget";
            chkWallTurbo.Name = "chkWallTurbo"; chkWallBoost.Name = "chkWallBoost";
            numTrigger.Name = "numTrigger"; numRelease.Name = "numRelease"; numLimit.Name = "numLimit";
            lblWallStatus.Name = "lblWallStatus";
            tbMax.Name = "tbMax"; tbMin.Name = "tbMin";
            chkTurbo.Name = "chkTurbo";
            lblMaxVal.Name = "lblMaxVal"; lblMinVal.Name = "lblMinVal";
            btnApply.Name = "btnApply"; btnHotkey.Name = "btnHotkey";
            chkAutoStart.Name = "chkAutoStart";
            numMax.Name = "numMax"; numMin.Name = "numMin";
            btnMin0.Name = "btnMin0"; btnMin5.Name = "btnMin5";
            btnMin50.Name = "btnMin50"; btnMin100.Name = "btnMin100";
            sep1.Name = "sep1"; sep2.Name = "sep2";
            lblSec1.Name = "lblSec1"; lblSec2.Name = "lblSec2"; lblSec3.Name = "lblSec3";

            Controls.Add(gbMonitor);
            Controls.Add(gbControl);

            // ---------------- status bar ----------------
            status = new StatusStrip();
            status.SizingGrip = false;
            stStatus = new ToolStripStatusLabel("正在启动…");
            stAuto = new ToolStripStatusLabel("");
            stHot = new ToolStripStatusLabel("");
            stElev = new ToolStripStatusLabel("");
            stStatus.Spring = true;
            stStatus.TextAlign = ContentAlignment.MiddleLeft;
            status.Items.Add(stStatus);
            status.Items.Add(stAuto);
            status.Items.Add(stHot);
            status.Items.Add(stElev);
            Controls.Add(status);
        }

        // ---------------- 按实测文字宽度自动布局 ----------------
        // 手工估算控件宽度在缩放 DPI 下必然出错（文字按实际 DPI 渲染，而坐标是
        // 设计像素）。改为在创建控件时用 TextRenderer 量出真实宽度，从根上避免截断。

        static int TextW(string s, Font f)
        {
            return TextRenderer.MeasureText(s, f).Width;
        }

        static int MaxTextW(string[] ss, Font f)
        {
            int w = 0;
            for (int i = 0; i < ss.Length; i++) { int t = TextW(ss[i], f); if (t > w) w = t; }
            return w;
        }

        class Row
        {
            readonly Control _parent;
            int _x;
            public Row(Control parent, int startX) { _parent = parent; _x = startX; }
            public int X { get { return _x; } }
            public T Add<T>(T c, int gap) where T : Control
            {
                c.Left = _x;
                _parent.Controls.Add(c);
                _x = c.Right + gap;
                return c;
            }
        }

        Label AutoLabel(string text, Font f, Color c)
        {
            Label l = new Label();
            l.Text = text; l.Font = f; l.ForeColor = c; l.AutoSize = false;
            l.Size = new Size(TextW(text, f) + S(8), S(20));
            return l;
        }

        CheckBox AutoCheck(string text, Font f)
        {
            CheckBox c = new CheckBox();
            c.Text = text; c.Font = f; c.AutoSize = false;
            c.Size = new Size(TextW(text, f) + S(28) + 6, S(22));
            return c;
        }

        ComboBox AutoCombo(Font f, string[] items)
        {
            ComboBox cb = new ComboBox();
            cb.DropDownStyle = ComboBoxStyle.DropDownList;
            cb.Font = f;
            int w = 0;
            for (int i = 0; i < items.Length; i++)
            {
                cb.Items.Add(items[i]);
                int iw = TextW(items[i], f);
                if (iw > w) w = iw;
            }
            cb.Size = new Size(w + S(32) + 10, S(24));
            return cb;
        }

        NumericUpDown AutoNum(Font f, int min, int max, int val)
        {
            NumericUpDown n = new NumericUpDown();
            n.Font = f;
            n.Minimum = min; n.Maximum = max;
            if (val > max) val = max;
            if (val < min) val = min;
            n.Value = val;
            n.Size = new Size(TextW(max.ToString(), f) + S(36), S(24));
            return n;
        }

        GroupBox MakeGroup(string text, int x, int y, int w, int h)
        {
            GroupBox g = new GroupBox();
            g.Text = text;
            g.Location = new Point(x, y);
            g.Size = new Size(w, h);
            g.BackColor = CCard;
            g.ForeColor = CText;
            return g;
        }

        Panel MakePanel(int x, int y, int w, int h)
        {
            BuffPanel p = new BuffPanel();
            p.Location = new Point(x, y);
            p.Size = new Size(w, h);
            p.BackColor = Color.Transparent;
            return p;
        }

        // 卡片内的分区分隔线。用一条 1px 的面板而不是在 GroupBox 上自绘，
        // 这样它能跟随卡片宽度锚定拉伸，也不需要额外的绘制代码。
        Panel MakeSeparator(int x, int y, int w)
        {
            Panel p = new Panel();
            p.Location = new Point(x, y);
            p.Size = new Size(w, 1);
            p.BackColor = CLine;
            return p;
        }

        Label MakeLabel(string text, int x, int y, int w, int h, Font f, Color c)
        {
            Label l = new Label();
            l.Text = text;
            l.Location = new Point(x, y);
            l.Size = new Size(w, h);
            l.Font = f;
            l.ForeColor = c;
            l.AutoSize = false;
            return l;
        }

        Button MakeButton(string text, int x, int y, int w, int h)
        {
            Button b = new Button();
            b.Text = text;
            b.Location = new Point(x, y);
            b.Size = new Size(w, h);
            b.FlatStyle = FlatStyle.System;
            b.UseVisualStyleBackColor = true;
            return b;
        }

        // ---------------------------------------------------------------- tray

        void BuildTray()
        {
            _tray = new NotifyIcon();
            _tray.Icon = MakeIcon();
            _tray.Text = "系统控制台";
            _tray.Visible = true;
            _tray.DoubleClick += delegate { RestoreWindow(); };
            ContextMenuStrip cm = new ContextMenuStrip();
            cm.Items.Add("显示主界面", null, delegate { RestoreWindow(); });
            cm.Items.Add("-");
            cm.Items.Add("均衡模式", null, delegate { ApplyPresetByKey("balanced"); });
            cm.Items.Add("静音模式", null, delegate { ApplyPresetByKey("quiet"); });
            cm.Items.Add("性能模式", null, delegate { ApplyPresetByKey("performance"); });
            cm.Items.Add("-");
            _trayFanBoost = new ToolStripMenuItem("一键强冷");
            _trayFanBoost.Click += delegate { OnFanBoostClick(null, EventArgs.Empty); };
            cm.Items.Add(_trayFanBoost);
            cm.Items.Add("-");
            _trayAuto = new ToolStripMenuItem("开机自启动");
            _trayAuto.CheckOnClick = false;   // state is owned by the scheduled task, not the menu
            _trayAuto.Click += delegate { ApplyAutoStart(!AutoStart.IsEnabled()); };
            cm.Items.Add(_trayAuto);
            cm.Items.Add("-");
            cm.Items.Add("退出", null, delegate { _reallyExit = true; Close(); });
            // Re-read the real task state each time the menu opens.
            cm.Opening += delegate
            {
                if (_trayAuto != null) _trayAuto.Checked = AutoStart.IsEnabled();
                if (_trayFanBoost != null)
                {
                    bool on = Ec.FanBoost.IsOn();
                    _trayFanBoost.Checked = on;
                    _trayFanBoost.Text = on ? "强冷：已开启" : "一键强冷";
                }
            };
            _tray.ContextMenuStrip = cm;
        }

        static Icon MakeIcon()
        {
            Bitmap bmp = new Bitmap(16, 16);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);
                g.FillEllipse(new SolidBrush(Color.FromArgb(0, 120, 212)), 1, 1, 14, 14);
                g.FillRectangle(new SolidBrush(Color.White), 6, 4, 4, 6);
                g.FillEllipse(new SolidBrush(Color.White), 5, 9, 6, 6);
            }
            IntPtr h = bmp.GetHicon();
            return Icon.FromHandle(h);
        }

        void RestoreWindow()
        {
            Show();
            WindowState = FormWindowState.Normal;
            Activate();
        }

        // -------------------------------------------------------------- startup

        void OnLoaded(object sender, EventArgs e)
        {
            RestoreWindowState();
            Sensors.Init();

            // Global hotkeys must be registered against a live window handle.
            _hotkeys = new HotkeyManager(Handle);
            ApplyHotkeyConfig(HotkeyStore.Load());

            _guardCfg = GuardStore.Load();
            RefreshGuardUi();

            _wallCfg = WallStore.Load();
            RefreshWallUi();

            // 风扇强冷走原生 EC 通道。设备正常情况下会一直存在；万一被外部
            // 卸载脚本删掉，这里在后台尝试一次 PnP 重新枚举，避免界面一直
            // 显示"EC 不可用"。
            Thread ecInit = new Thread(new ThreadStart(delegate
            {
                if (!Ec.IsOpen)
                {
                    string r = Ec.EnsureDevice();
                    Log.Write("EC 初始化: " + r);
                }

                // 键盘背光：上次勾了"记住颜色"就自动恢复。放在这个后台线程里，
                // 才能等到 EC 设备确实可用之后再写。
                int sr, sg, sb;
                if (Ec.KbColor.LoadSaved(out sr, out sg, out sb))
                {
                    string err = Ec.KbColor.ApplyRgb(sr, sg, sb, false);
                    Log.Write(string.Format(CultureInfo.InvariantCulture,
                        "键盘背光 启动应用 RGB({0},{1},{2}): {3}", sr, sg, sb, err == null ? "OK" : err));
                    try
                    {
                        BeginInvoke(new MethodInvoker(delegate
                        {
                            chkLightRemember.Checked = true;
                            RefreshLightUi();
                        }));
                    }
                    catch { }
                }
            }));
            ecInit.IsBackground = true;
            ecInit.Start();

            _thread = new Thread(new ThreadStart(Loop));
            _thread.IsBackground = true;
            _thread.Start();

            _timer = new System.Windows.Forms.Timer();
            _timer.Interval = 1000;
            _timer.Tick += OnTick;
            _timer.Start();

            // 背光状态单独用较慢的节奏刷新，避免每秒都去读 EC
            _lightTimer = new System.Windows.Forms.Timer();
            _lightTimer.Interval = 2000;
            _lightTimer.Tick += delegate { RefreshLightUi(); };
            _lightTimer.Start();

            if (_startHidden)
            {
                WindowState = FormWindowState.Minimized;
                Hide();
            }
            else
            {
                BeginInvoke(new MethodInvoker(delegate
                {
                    RefreshPowerUi();
                }));
            }
            Log.Write("GUI started. elevated=" + Elevation.IsElevated());
        }

        void Loop()
        {
            while (!_stop)
            {
                Snapshot s;
                try { s = Sensors.Read(); }
                catch (Exception ex)
                {
                    s = new Snapshot();
                    s.Error = ex.Message;
                }
                lock (_lock) { _snap = s; }
                Thread.Sleep(1000);
            }
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            // Track the "normal" (non-maximized) client size so it can be restored
            // even if the user closes the window while maximized.
            if (!_restoringState && WindowState == FormWindowState.Normal)
            {
                _normalW = ClientSize.Width;
                _normalH = ClientSize.Height;
            }
        }

        void RestoreWindowState()
        {
            int w, h;
            bool max;
            if (!UiState.LoadWindow(out w, out h, out max)) return;

            Rectangle wa = Screen.FromPoint(new Point(Left, Top)).WorkingArea;
            // 窗口尺寸 = 客户区 + 边框。这里 w/h 是客户区，上限必须按真实边框推算，
            // 否则放大后的界面会比可用高度高出一截、底部被切掉。
            int chromeW = Width - ClientSize.Width;
            int chromeH = Height - ClientSize.Height;
            if (w < MinimumSize.Width) w = MinimumSize.Width;
            if (h < MinimumSize.Height) h = MinimumSize.Height;
            if (w > wa.Width - chromeW - 8) w = wa.Width - chromeW - 8;
            if (h > wa.Height - chromeH - 8) h = wa.Height - chromeH - 8;

            _restoringState = true;
            try
            {
                ClientSize = new Size(w, h);
                if (max) WindowState = FormWindowState.Maximized;
            }
            finally { _restoringState = false; }

            _normalW = w;
            _normalH = h;
        }

        void SaveWindowState()
        {
            int w = _normalW > 0 ? _normalW : ClientSize.Width;
            int h = _normalH > 0 ? _normalH : ClientSize.Height;
            UiState.SaveWindow(w, h, WindowState == FormWindowState.Maximized);
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            _stop = true;
            // Never leave the protective cap applied after the app is gone.
            if (_guardActive)
            {
                try
                {
                    Power.RestoreState(_guardSaved);
                    Log.Write("ThermalGuard restored on exit");
                }
                catch { }
                _guardActive = false;
            }
            try { SaveWindowState(); } catch { }
            if (_hotkeys != null) { _hotkeys.Dispose(); _hotkeys = null; }
            if (_tray != null) { _tray.Visible = false; _tray.Dispose(); }
        }

        // WM_HOTKEY is delivered to the window, so it arrives on the UI thread
        // already - no marshalling needed before touching controls.
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == HotkeyManager.WM_HOTKEY && _hotkeys != null)
            {
                string action = _hotkeys.Resolve(m.WParam.ToInt32());
                if (action != null)
                {
                    OnHotkeyAction(action);
                    return;
                }
            }
            base.WndProc(ref m);
        }

        void OnClosing(object sender, FormClosingEventArgs e)
        {
            if (!_reallyExit && e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
                if (_tray != null)
                {
                    _tray.ShowBalloonTip(1500, "系统控制台", "已最小化到托盘，双击图标可恢复。", ToolTipIcon.Info);
                }
            }
        }

        // ------------------------------------------------------------- refresh

        void OnTick(object sender, EventArgs e)
        {
            Snapshot s;
            lock (_lock) { s = _snap; }

            string hot = "--";
            if (s.Zones.Count > 0)
            {
                double mx = 0; string nm = "";
                for (int i = 0; i < s.Zones.Count; i++)
                {
                    if (s.Zones[i].TempC > mx) { mx = s.Zones[i].TempC; nm = s.Zones[i].Label; }
                }
                hot = string.Format(CultureInfo.InvariantCulture, "{0} {1:0.0}°C", nm, mx);
            }

            _tray.Text = "系统控制台  |  " + hot;
            if (_tray.Text.Length > 62) _tray.Text = _tray.Text.Substring(0, 62);

            // The guard must keep working while hidden in the tray.
            // 温度墙先算（闭环、渐进），超温保护后算（二元兜底）。
            // 超温保护一旦接管，温度墙会在下一个 tick 让位，两者不会互相覆盖。
            WallTick(s.MaxZoneTemp);
            GuardTick(s.MaxZoneTemp);

            if (!Visible) return;

            if (s.Zones.Count > 0)
            {
                double m = s.MaxZoneTemp;
                _history.Add(m);
                while (_history.Count > HistoryMax) _history.RemoveAt(0);
            }

            string thr;
            if (s.ThrottleReasons == 0) thr = "节流状态: 正常（无节流）";
            else thr = string.Format(CultureInfo.InvariantCulture,
                     "节流状态: 触发中  原因标志 = 0x{0:X}", s.ThrottleReasons);
            lblThrottle.Text = thr + "    风扇设备: " + s.FanCount + " 个";
            lblThrottle.ForeColor = s.ThrottleReasons == 0 ? CSub : CDanger;

            lblCpu.Text = string.Format(CultureInfo.InvariantCulture,
                "处理器总占用: {0:0.0}%      相对基准性能: {1:0}%      报告频率: {2:0} MHz      逻辑核心: {3}",
                s.CpuPercent, s.PerfPercent, s.FreqMHz, s.Cores.Length);

            lblMem.Text = string.Format(CultureInfo.InvariantCulture,
                "内存: 已用 {0:0.0} GB / 共 {1:0.0} GB   ({2:0.0}%)",
                (s.MemTotalMB - s.MemAvailMB) / 1024.0, s.MemTotalMB / 1024.0, s.MemUsedPercent);

            UpdateFanUi();

            if (s.Error.Length > 0) stStatus.Text = "读取异常: " + s.Error;

            stElev.Text = s.Elevated ? "权限: 管理员（全部功能可用）" : "权限: 普通用户（仅监控可用）";
            stElev.ForeColor = s.Elevated ? CGreen : CWarn;

            pnlZones.Invalidate();
            pnlGraph.Invalidate();
            pnlCores.Invalidate();
            pnlMem.Invalidate();
        }

        // -------------------------------------------------------------- painting

        void PaintZones(object sender, PaintEventArgs e)
        {
            Snapshot s;
            lock (_lock) { s = _snap; }
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            if (s.Zones.Count == 0)
            {
                g.DrawString("未读取到温度数据", fNormal, new SolidBrush(CSub), 4, 8);
                return;
            }

            for (int i = 0; i < s.Zones.Count && i < 2; i++)
            {
                ZoneReading z = s.Zones[i];
                int y = i * 42;
                double crit = z.HasCritical ? z.CriticalC : 105.0;
                double ratio = z.TempC / crit;
                if (ratio < 0) ratio = 0;
                if (ratio > 1.1) ratio = 1.1;

                Color col = CGreen;
                if (z.TempC >= 85) col = CDanger;
                else if (z.TempC >= 70) col = CWarn;

                g.DrawString(z.Label, fNormal, new SolidBrush(CText), 0, y + 12);
                g.DrawString(string.Format(CultureInfo.InvariantCulture, "{0:0.0}", z.TempC),
                    fBig, new SolidBrush(col), 84, y + 2);
                g.DrawString("°C", fNormal, new SolidBrush(col), 168, y + 18);

                int bx = 210, bh = 18, by = y + 12;
                // 进度条宽度跟随面板宽度伸缩，右侧预留临界温度文字的宽度
                int bw = pnlZones.Width - bx - 150;
                if (bw < 100) bw = 100;
                g.FillRectangle(new SolidBrush(Color.FromArgb(238, 240, 244)), bx, by, bw, bh);
                int fw = (int)(bw * (ratio > 1 ? 1 : ratio));
                g.FillRectangle(new SolidBrush(col), bx, by, fw, bh);
                g.DrawRectangle(new Pen(CLine), bx, by, bw, bh);

                string cs = z.HasCritical
                    ? string.Format(CultureInfo.InvariantCulture, "临界 {0:0.0}°C", z.CriticalC)
                    : "临界点未知";
                g.DrawString(cs, fSmall, new SolidBrush(CSub), bx + bw + 10, by + 2);
            }
        }

        /// <summary>
        /// 曲线图上的标注：右对齐贴在 right 位置，并垫一层浅白底。
        /// 右对齐是算出来的而不是写死偏移，所以任何窗口宽度下都不会被裁掉。
        /// </summary>
        void DrawTag(Graphics g, string text, Font f, Color c, float right, float y)
        {
            int tw = TextW(text, f) + 6;
            int th = f.Height + 2;
            int x = (int)right - tw;
            if (x < 2) x = 2;
            int yy = (int)y;
            int bottom = pnlGraph.Height;
            if (yy + th > bottom) yy = Math.Max(1, bottom - th);
            if (yy < 1) yy = 1;
            using (Brush bg = new SolidBrush(Color.FromArgb(230, 255, 255, 255)))
                g.FillRectangle(bg, x, yy, tw, th);
            g.DrawString(text, f, new SolidBrush(c), x + 3, yy + 1);
        }

        void PaintGraph(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            int w = pnlGraph.Width, h = pnlGraph.Height;
            g.FillRectangle(new SolidBrush(Color.FromArgb(249, 250, 252)), 0, 0, w, h);
            g.DrawRectangle(new Pen(CLine), 0, 0, w - 1, h - 1);

            double lo = 30, hi = 100;
            for (int i = 0; i < _history.Count; i++)
            {
                if (_history[i] > hi - 5) hi = _history[i] + 10;
            }
            if (hi > 110) hi = 110;

            using (Pen gp = new Pen(Color.FromArgb(238, 240, 244)))
            {
                for (int t = (int)lo; t <= (int)hi; t += 10)
                {
                    float y = (float)(h - (t - lo) / (hi - lo) * h);
                    g.DrawLine(gp, 34, y, w - 8, y);
                    // 最上和最下两档刻度正好落在画布边缘，直接画会被裁掉半行，夹一下
                    float ty = y - 8;
                    if (ty < 0) ty = 0;
                    if (ty > h - fSmall.Height) ty = h - fSmall.Height;
                    g.DrawString(t + "°", fSmall, new SolidBrush(CSub), 4, ty);
                }
            }

            // 把温度墙目标与超温保护阈值直接画在曲线上：墙在哪里、离当前温度
            // 还有多远，一眼就能看见，不用去对照数字。
            double wallT = (_wallCfg != null && _wallCfg.Enabled) ? _wallCfg.TargetC : -1;
            double guardT = (_guardCfg != null && _guardCfg.Enabled) ? _guardCfg.TriggerC : -1;

            bool hasWall = (wallT > lo && wallT < hi);
            bool hasGuard = (guardT > lo && guardT < hi);
            float wy = 0, gy = 0;

            if (hasWall)
            {
                wy = (float)(h - (wallT - lo) / (hi - lo) * h);
                using (Brush b = new SolidBrush(Color.FromArgb(26, 214, 64, 64)))
                    g.FillRectangle(b, 34, 0, w - 42, wy);      // 墙上方的"越界区"淡红提示
                using (Pen p = new Pen(CGreen, 1f))
                {
                    p.DashStyle = DashStyle.Dash;
                    g.DrawLine(p, 34, wy, w - 8, wy);
                }
            }

            if (hasGuard)
            {
                gy = (float)(h - (guardT - lo) / (hi - lo) * h);
                using (Pen p = new Pen(CDanger, 1f))
                {
                    p.DashStyle = DashStyle.Dot;
                    g.DrawLine(p, 34, gy, w - 8, gy);
                }
            }

            // 两个标注都右对齐，并且强制错开至少一行的高度 —— 目标温度和触发温度
            // 常常只差几度，两条虚线挨在一起时文字会叠成一团。
            string wallTxt = "温度墙 " + wallT.ToString("0", CultureInfo.InvariantCulture) + "°C";
            string guardTxt = "保护 " + guardT.ToString("0", CultureInfo.InvariantCulture) + "°C";
            float wallTy = wy - 16, guardTy = gy + 3;
            if (hasWall && hasGuard && Math.Abs(guardTy - wallTy) < 15) guardTy = wallTy + 15;
            if (wallTy > h - 15) wallTy = h - 15;
            if (guardTy > h - 15) guardTy = h - 15;
            if (wallTy < 1) wallTy = 1;
            if (guardTy < 1) guardTy = 1;
            if (hasWall) DrawTag(g, wallTxt, fSmall, CGreen, w - 8, wallTy);
            if (hasGuard) DrawTag(g, guardTxt, fSmall, CDanger, w - 8, guardTy);

            if (_history.Count < 2)
            {
                g.DrawString("正在采集温度曲线…", fNormal, new SolidBrush(CSub), 40, h / 2 - 8);
                return;
            }

            PointF[] pts = new PointF[_history.Count];
            for (int i = 0; i < _history.Count; i++)
            {
                float x = 34 + (float)i / (HistoryMax - 1) * (w - 42);
                float y = (float)(h - (_history[i] - lo) / (hi - lo) * h);
                if (y < 0) y = 0;
                if (y > h) y = h;
                pts[i] = new PointF(x, y);
            }
            using (Pen p = new Pen(CAccent, 2f))
            {
                p.LineJoin = LineJoin.Round;
                g.DrawLines(p, pts);
            }
            double last = _history[_history.Count - 1];
            g.DrawString(string.Format(CultureInfo.InvariantCulture, "当前 {0:0.0}°C   最近 {1} 秒", last, _history.Count),
                fSmall, new SolidBrush(CSub), 40, 4);
        }

        void PaintCores(object sender, PaintEventArgs e)
        {
            Snapshot s;
            lock (_lock) { s = _snap; }
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            double[] c = s.Cores;
            int w = pnlCores.Width, h = pnlCores.Height;
            g.FillRectangle(new SolidBrush(Color.FromArgb(249, 250, 252)), 0, 0, w, h);
            g.DrawRectangle(new Pen(CLine), 0, 0, w - 1, h - 1);
            if (c == null || c.Length == 0)
            {
                g.DrawString("未获取到逐核数据", fNormal, new SolidBrush(CSub), 6, h / 2 - 8);
                return;
            }
            int n = c.Length;
            float gap = 3f;
            float bw = (w - 16 - gap * (n - 1)) / n;
            if (bw < 3) { bw = 3; gap = 1; }
            // 图例标签占顶上一条，柱子从它下沿开始、编号贴底。用标签实际下沿
            // 而不是写死数值 —— 整体放大后字号变了它也不会压到柱子。
            float top = (lblCoreLegend != null ? lblCoreLegend.Bottom : 20) + 3f;
            float full = h - top - 16f;
            if (full < 8f) full = 8f;
            for (int i = 0; i < n; i++)
            {
                float x = 8 + i * (bw + gap);
                float v = (float)(c[i] / 100.0);
                if (v < 0) v = 0;
                if (v > 1) v = 1;
                float bh = full * v;
                Color col = i < 16 ? CAccent : Color.FromArgb(120, 90, 200);
                g.FillRectangle(new SolidBrush(Color.FromArgb(232, 236, 242)), x, top, bw, full);
                g.FillRectangle(new SolidBrush(col), x, top + (full - bh), bw, bh);
                if (bw >= 10)
                {
                    string lbl = i.ToString(CultureInfo.InvariantCulture);
                    g.DrawString(lbl, fSmall, new SolidBrush(CSub),
                                 x + bw / 2 - TextW(lbl, fSmall) / 2f, top + full + 2);
                }
            }
        }

        void PaintMem(object sender, PaintEventArgs e)
        {
            Snapshot s;
            lock (_lock) { s = _snap; }
            Graphics g = e.Graphics;
            int w = pnlMem.Width, h = pnlMem.Height;
            double p = s.MemUsedPercent;
            if (p < 0) p = 0; if (p > 100) p = 100;
            g.FillRectangle(new SolidBrush(Color.FromArgb(238, 240, 244)), 0, 0, w, h);
            Color col = p >= 90 ? CDanger : (p >= 75 ? CWarn : CAccent);
            g.FillRectangle(new SolidBrush(col), 0, 0, (int)(w * p / 100.0), h);
            g.DrawRectangle(new Pen(CLine), 0, 0, w - 1, h - 1);
        }

        // ---------------------------------------------------------- power logic

        // ------------------------------------------------------------ 键盘背光

        /// <summary>
        /// 按 0..255 的 RGB 设置键盘背光。内部走原厂协议：写 0x769/0x76A/0x76B
        /// 电平，再置 0x767 的 bit5 提交。
        /// </summary>
        void ApplyLight(Color c, bool remember)
        {
            string err = Ec.KbColor.ApplyRgb(c.R, c.G, c.B, true);
            if (err != null)
            {
                lblLightStatus.Text = "设置失败：" + err;
                lblLightStatus.ForeColor = CDanger;
                Log.Write("键盘背光设置失败: " + err);
                return;
            }
            _lightR = c.R; _lightG = c.G; _lightB = c.B;
            if (remember) Ec.KbColor.SaveSaved(c.R, c.G, c.B);
            RefreshLightUi();
            Log.Write(string.Format(CultureInfo.InvariantCulture,
                "键盘背光 -> RGB({0},{1},{2})  {3}", c.R, c.G, c.B, Ec.KbColor.LevelText(c.R, c.G, c.B)));
        }

        /// <summary>
        /// 生成调色板配色。上排是 24 个全亮度色相 + 11 级灰阶，下排是同样色相的
        /// 压暗版本 + 11 级暗灰阶。
        /// 注意：背光电平只有 1..50，且按 R/5、G/6、B/6 量化，所以极暗的颜色会
        /// 被压到最低档，这里刻意避开纯黑（纯黑相当于"最暗"而不是"关灯"）。
        /// </summary>
        static Color[] BuildLightPalette(int cols)
        {
            int hueCount = cols - 11;
            Color[] list = new Color[cols * 2];
            for (int i = 0; i < hueCount; i++)
            {
                double hue = i * (360.0 / hueCount);
                list[i] = HsvToRgb(hue, 1.0, 1.0);
                list[cols + i] = HsvToRgb(hue, 1.0, 0.55);
            }
            int[] grays = new int[] { 16, 40, 64, 88, 112, 136, 160, 184, 208, 232, 255 };
            for (int i = 0; i < grays.Length && hueCount + i < cols; i++)
            {
                int g = grays[i];
                list[hueCount + i] = Color.FromArgb(g, g, g);
                int d = g * 55 / 100;
                list[cols + hueCount + i] = Color.FromArgb(d, d, d);
            }
            return list;
        }

        static Color HsvToRgb(double h, double s, double v)
        {
            double hh = h / 60.0;
            int i = (int)Math.Floor(hh) % 6;
            if (i < 0) i += 6;
            double f = hh - Math.Floor(hh);
            double p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
            double r, g, b;
            switch (i)
            {
                case 0: r = v; g = t; b = p; break;
                case 1: r = q; g = v; b = p; break;
                case 2: r = p; g = v; b = t; break;
                case 3: r = p; g = q; b = v; break;
                case 4: r = t; g = p; b = v; break;
                default: r = v; g = p; b = q; break;
            }
            return Color.FromArgb((int)Math.Round(r * 255), (int)Math.Round(g * 255), (int)Math.Round(b * 255));
        }

        /// <summary>找出和某个实际颜色最接近的调色板格子（用于高亮当前颜色）。</summary>
        int NearestSwatch(int r, int g, int b)
        {
            if (paletteLight == null || paletteLight.Swatches == null) return -1;
            Color[] sw = paletteLight.Swatches;
            int best = -1;
            long bestD = long.MaxValue;
            for (int i = 0; i < sw.Length; i++)
            {
                long dr = sw[i].R - r, dg = sw[i].G - g, db = sw[i].B - b;
                long d = dr * dr + dg * dg + db * db;
                if (d < bestD) { bestD = d; best = i; }
            }
            return best;
        }

        void OnSwatchClick(object sender, EventArgs e)
        {
            using (ColorDialog d = new ColorDialog())
            {
                d.FullOpen = true;
                d.AnyColor = true;
                if (_lightR >= 0) d.Color = Color.FromArgb(255, _lightR, _lightG, _lightB);
                if (d.ShowDialog(this) == DialogResult.OK)
                    ApplyLight(d.Color, chkLightRemember.Checked);
            }
        }

        /// <summary>恢复出厂色：读 EC 里的 0x76C/0x76D/0x76E（原厂 GetEcDefaultRGB），再写回。</summary>
        void OnLightDefaultClick(object sender, EventArgs e)
        {
            int dr, dg, db;
            if (!Ec.KbColor.ReadDefaults(out dr, out dg, out db))
            {
                lblLightStatus.Text = "读取出厂色失败：" + Ec.LastError;
                lblLightStatus.ForeColor = CDanger;
                return;
            }
            string err = Ec.KbColor.ApplyLevels(dr, dg, db, true);
            if (err != null)
            {
                lblLightStatus.Text = "设置失败：" + err;
                lblLightStatus.ForeColor = CDanger;
                return;
            }
            _lightR = Ec.KbColor.RFromLevel(dr);
            _lightG = Ec.KbColor.GFromLevel(dg);
            _lightB = Ec.KbColor.BFromLevel(db);
            if (chkLightRemember.Checked) Ec.KbColor.SaveSaved(_lightR, _lightG, _lightB);
            RefreshLightUi();
            Log.Write(string.Format(CultureInfo.InvariantCulture,
                "键盘背光 恢复出厂电平 {0}/{1}/{2}", dr, dg, db));
        }

        void OnLightRememberChanged(object sender, EventArgs e)
        {
            if (chkLightRemember.Checked)
            {
                if (_lightR >= 0) Ec.KbColor.SaveSaved(_lightR, _lightG, _lightB);
            }
            else
            {
                Ec.KbColor.ClearSaved();
            }
        }

        /// <summary>把 EC 里的真实电平回显到色块和状态文字上（色块显示的是硬件实际会发出的颜色）。</summary>
        void RefreshLightUi()
        {
            if (btnSwatch == null || lblLightStatus == null) return;
            int lr, lg, lb;
            if (!Ec.KbColor.ReadLevels(out lr, out lg, out lb))
            {
                lblLightStatus.Text = "EC 不可用" + (Ec.LastError.Length > 0 ? "：" + Ec.LastError : "");
                lblLightStatus.ForeColor = CSub;
                return;
            }
            int er = Ec.KbColor.RFromLevel(lr);
            int eg = Ec.KbColor.GFromLevel(lg);
            int eb = Ec.KbColor.BFromLevel(lb);
            btnSwatch.BackColor = Color.FromArgb(er, eg, eb);
            int si = NearestSwatch(er, eg, eb);
            if (paletteLight.SelectedIndex != si)
            {
                paletteLight.SelectedIndex = si;
                paletteLight.Invalidate();
            }
            string t = string.Format(CultureInfo.InvariantCulture,
                "当前 {0}/{1}/{2} ≈ RGB({3},{4},{5})", lr, lg, lb, er, eg, eb);
            int dr, dg, db;
            if (Ec.KbColor.ReadDefaults(out dr, out dg, out db))
                t += string.Format(CultureInfo.InvariantCulture, "   出厂 {0}/{1}/{2}", dr, dg, db);
            lblLightStatus.Text = t;
            lblLightStatus.ForeColor = CSub;
        }

        void RefreshPowerUi()
        {
            _loading = true;
            try
            {
                PowerState st = Power.Read();
                chkTurbo.Checked = st.TurboEnabled;
                cmbMode.SelectedIndex = st.Mode >= 0 && st.Mode <= 2 ? st.Mode : 0;
                cmbCool.SelectedIndex = st.CoolingPolicy == Power.COOLING_ACTIVE ? 1 : 0;
                // 温度墙/超温保护正在人为压低上限时，实时值不是用户的设定值，
                // 不能拿它覆盖滑块 —— 否则每刷新一次基线就往下掉一档，形成
                // "越压越低"的棘轮效应。
                if (_wallApplied <= 0 && !_guardActive)
                {
                    tbMax.Value = Clamp(st.MaxState, tbMax.Minimum, tbMax.Maximum);
                    _wallBaseState = tbMax.Value;
                }
                tbMin.Value = Clamp(st.MinState, tbMin.Minimum, tbMin.Maximum);
                // lblMaxVal / lblMinVal 现在是滑块右端的 "%" 单位标签；数值本身由
                // numMax / numMin 显示，并随上面两个赋值自动同步过去。
                btnElevate.Visible = !Elevation.IsElevated();
                btnApply.Enabled = true;
            }
            finally { _loading = false; }
            UpdatePresetLabel();
            RefreshAutoStartUi();
            RefreshLightUi();
        }

        static int Clamp(int v, int lo, int hi)
        {
            if (v < lo) return lo;
            if (v > hi) return hi;
            return v;
        }

        /// <summary>设计坐标系 → 实际像素。界面所有布局数值都写成"设计值"，
        /// 这里统一乘上用户设定的缩放系数。</summary>
        int S(int v) { return (int)Math.Round(v * (_uiPct / 100.0)); }
        float Sf(float v) { return (float)(v * (_uiPct / 100.0)); }

        /// <summary>按当前缩放系数重建这套字体。改系数后必须重新调用。</summary>
        void ApplyScaledFonts()
        {
            float k = _uiPct / 100f;
            fTitle = new Font("Microsoft YaHei UI", 10F * k, FontStyle.Bold);
            fBig = new Font("Microsoft YaHei UI", 20F * k, FontStyle.Bold);
            fNormal = new Font("Microsoft YaHei UI", 9F * k);
            fSmall = new Font("Microsoft YaHei UI", 8F * k);
            fSect = new Font("Microsoft YaHei UI", 9F * k, FontStyle.Bold);   // 卡片内分区小标题
        }

        void UpdatePresetLabel()
        {
            if (_loading) return;
            List<Power.Preset> ps = Power.Presets();
            string best = "";
            int bestScore = -1;
            for (int i = 0; i < ps.Count; i++)
            {
                Power.Preset p = ps[i];
                int score = 0;
                if (p.Turbo == chkTurbo.Checked) score++;
                if (p.Mode == cmbMode.SelectedIndex) score++;
                if (p.Cooling == (cmbCool.SelectedIndex == 1 ? Power.COOLING_ACTIVE : Power.COOLING_PASSIVE)) score++;
                if (Math.Abs(p.MaxState - tbMax.Value) <= 2) score++;
                if (Math.Abs(p.MinState - tbMin.Value) <= 3) score++;
                if (score > bestScore) { bestScore = score; best = p.Key; }
            }
            _lastPreset = bestScore >= 4 ? best : "";
            string txt = "当前配置接近：--（自定义）";
            for (int i = 0; i < ps.Count; i++)
            {
                if (ps[i].Key == _lastPreset) txt = "当前配置接近：" + ps[i].Name + "   " + ps[i].Desc;
            }
            lblPresetDesc.Text = txt;
            HighlightPresetButtons();
        }

        void HighlightPresetButtons()
        {
            List<Power.Preset> ps = Power.Presets();
            Button[] bs = new Button[] { btnPerf, btnBalanced, btnQuiet };
            for (int i = 0; i < bs.Length; i++)
            {
                bool on = (ps[i].Key == _lastPreset);
                bs[i].FlatStyle = FlatStyle.System;
                bs[i].Font = on ? fTitle : fNormal;
                bs[i].Text = on ? "● " + ps[i].Name : ps[i].Name;
            }
        }

        // ------------------------------------------------------------ autostart

        void OnAutoStartChanged(object sender, EventArgs e)
        {
            if (_loading) return;
            ApplyAutoStart(chkAutoStart.Checked);
        }

        void ApplyAutoStart(bool enable)
        {
            string r = enable
                ? AutoStart.Enable(Application.ExecutablePath)
                : AutoStart.Disable();
            bool ok = (r == "OK");
            Log.Write("AutoStart " + (enable ? "on" : "off") + " -> " + r);

            if (ok)
            {
                stStatus.Text = enable ? "已启用开机自启" : "已关闭开机自启";
            }
            else
            {
                MessageBox.Show(this,
                    (enable ? "启用" : "关闭") + "开机自启失败：\r\n\r\n" + r + "\r\n\r\n" +
                    "该操作会登记一个 Windows 计划任务，需要管理员权限。\r\n" +
                    "请点击「以管理员身份重启」后重试——程序当前仍正常运行，不受影响。",
                    "系统控制台", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            RefreshAutoStartUi();
        }

        // Single source of truth for the autostart UI: the scheduled task itself.
        void RefreshAutoStartUi()
        {
            bool on = AutoStart.IsEnabled();
            bool prev = _loading;
            _loading = true;
            try { if (chkAutoStart != null) chkAutoStart.Checked = on; }
            finally { _loading = prev; }
            if (_trayAuto != null) _trayAuto.Checked = on;
            if (stAuto != null) stAuto.Text = "开机自启: " + (on ? "已启用" : "未启用") + "   ";
        }

        void ApplyPresetByKey(string key)
        {
            Power.Preset p = Power.FindPreset(key);
            if (p == null) return;
            GuardUserOverride();
            WallHandBack("切换场景");
            string rep = Power.ApplyPreset(p);
            Log.Write("ApplyPreset " + key + Environment.NewLine + rep);
            bool ok = rep.IndexOf("OK") >= 0;
            stStatus.Text = "已应用场景: " + p.Name + (Elevation.IsElevated() ? "" : "（部分设置需要管理员权限）");
            RefreshPowerUi();
            if (_tray != null && !Visible) _tray.ShowBalloonTip(1200, "系统控制台", "已切换到 " + p.Name, ToolTipIcon.Info);
            ShowReport("应用场景：" + p.Name, rep);
        }

        void OnApplyClick(object sender, EventArgs e)
        {
            GuardUserOverride();
            WallHandBack("手动应用");
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendLine("TURBO : " + Power.SetTurbo(chkTurbo.Checked));
            sb.AppendLine("MODE  : " + Power.SetMode(cmbMode.SelectedIndex));
            sb.AppendLine("COOL  : " + Power.SetCooling(cmbCool.SelectedIndex == 1 ? Power.COOLING_ACTIVE : Power.COOLING_PASSIVE));
            sb.AppendLine("MAX   : " + Power.SetMaxState(tbMax.Value));
            sb.AppendLine("MIN   : " + Power.SetMinState(tbMin.Value));
            Log.Write("Manual apply" + Environment.NewLine + sb.ToString());
            RefreshPowerUi();
            stStatus.Text = "设置已应用";
            ShowReport("手动应用设置", sb.ToString());
        }

        // 最小处理器状态的常用档位。只写这一个参数，走和「应用设置」里
        // 同一套 Power.SetMinState，所以结果完全一致，而且立即生效。
        void SetMinQuick(int value)
        {
            tbMin.Value = Clamp(value, tbMin.Minimum, tbMin.Maximum);
            string r = Power.SetMinState(tbMin.Value);
            RefreshPowerUi();
            stStatus.Text = "最小处理器状态 → " + tbMin.Value + "%：" + r;
            Log.Write("SetMinQuick " + tbMin.Value + "% -> " + r);
        }

        void ShowReport(string title, string body)
        {
            bool bad = body.IndexOf("ERR") >= 0 || body.IndexOf("EX ") >= 0 || body.IndexOf("TIMEOUT") >= 0;
            if (!bad)
            {
                return; // silent on success
            }
            MessageBox.Show(this,
                body + Environment.NewLine + Environment.NewLine +
                "提示：以管理员身份运行本程序才能修改电源参数。\r\n" +
                "（电源模式切换不需要管理员权限）",
                title + " - 存在问题", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        // ------------------------------------------------------------- hotkeys

        void ApplyHotkeyConfig(HotkeyStore.Config cfg)
        {
            _hotkeyCfg = cfg;
            string rep;
            if (cfg.Enabled)
            {
                rep = _hotkeys.Apply(cfg.Bindings);
            }
            else
            {
                _hotkeys.UnregisterAll();
                rep = "全局快捷键已关闭";
            }
            if (stHot != null)
            {
                stHot.Text = cfg.Enabled
                    ? ("快捷键: " + _hotkeys.ActiveCount + "/" + cfg.Bindings.Count + " 生效   ")
                    : "快捷键: 已关闭   ";
            }
            Log.Write("ApplyHotkeyConfig enabled=" + cfg.Enabled + Environment.NewLine + rep);
        }

        void OnHotkeySettingsClick(object sender, EventArgs e)
        {
            using (HotkeyForm f = new HotkeyForm(_hotkeyCfg))
            {
                if (f.ShowDialog(this) != DialogResult.OK) return;
                HotkeyStore.Save(f.Result);
                ApplyHotkeyConfig(f.Result);
                stStatus.Text = f.Result.Enabled
                    ? "快捷键设置已应用（组合被占用时会注册失败，详见日志）"
                    : "已关闭全局快捷键";
            }
        }

        // ------------------------------------------------------- EC / 风扇强冷

        // 风扇转速与模式来自原生 EC 直读（见 src/Ec.cs），不经过任何 OEM 组件。
        void UpdateFanUi()
        {
            if (lblFan == null) return;
            Ec.FanReadout r = Ec.ReadFan();
            if (r.Ok)
            {
                lblFan.Text = string.Format(CultureInfo.InvariantCulture,
                    "风扇 {0} / {1} RPM   占空比 {2}/{3}   模式 {4}",
                    r.Fan1Rpm, r.Fan2Rpm, r.Fan1Duty, r.Fan2Duty, r.ModeName);
                lblFan.ForeColor = r.Boosted ? CDanger : CAccent;
                if (btnFanBoost != null)
                {
                    btnFanBoost.Text = r.Boosted ? "强冷已开启" : "一键强冷";
                    btnFanBoost.ForeColor = r.Boosted ? CDanger : CText;
                }
            }
            else
            {
                lblFan.Text = "风扇: EC 不可用（" + (r.Error.Length > 0 ? r.Error : "设备未就绪") + "）";
                lblFan.ForeColor = CSub;
            }
        }

        void OnFanBoostClick(object sender, EventArgs e)
        {
            string msg = Ec.FanBoost.Toggle();
            // 手动切换后强冷归用户所有，温度墙不再自动接管这一次
            _wallBoostByWall = false;
            Log.Write("FanBoost: " + msg);
            stStatus.Text = msg;
            UpdateFanUi();
        }

        void OnHotkeyAction(string action)
        {
            Log.Write("Hotkey triggered: " + action);
            if (action == "cycle")
            {
                List<Power.Preset> ps = Power.Presets();
                PowerState st = Power.Read();
                int idx = ClosestPresetIndex(st, ps);
                int next = (idx + 1) % ps.Count;
                stStatus.Text = "快捷键循环切换 -> " + ps[next].Name;
                ApplyPresetByKey(ps[next].Key);
                return;
            }
            if (action == "fanboost")
            {
                stStatus.Text = "快捷键 " + Ec.FanBoost.Toggle();
                UpdateFanUi();
                return;
            }
            stStatus.Text = "快捷键触发 -> " + action;
            ApplyPresetByKey(action);
        }

        static int ClosestPresetIndex(PowerState st, List<Power.Preset> ps)
        {
            int best = 0, bestScore = -1;
            for (int i = 0; i < ps.Count; i++)
            {
                int s = 0;
                if (ps[i].Turbo == st.TurboEnabled) s++;
                if (ps[i].Mode == st.Mode) s++;
                if (ps[i].Cooling == st.CoolingPolicy) s++;
                if (Math.Abs(ps[i].MaxState - st.MaxState) <= 2) s++;
                if (Math.Abs(ps[i].MinState - st.MinState) <= 3) s++;
                if (s > bestScore) { bestScore = s; best = i; }
            }
            return best;
        }

        // -------------------------------------------------------- thermal guard

        void OnGuardEnableChanged(object sender, EventArgs e)
        {
            if (_loading) return;
            _guardCfg.Enabled = chkGuard.Checked;
            GuardStore.Save(_guardCfg);
            if (!_guardCfg.Enabled && _guardActive) GuardRelease("保护已关闭");
            _guardBlocked = false;
            UpdateGuardUi();
            stStatus.Text = _guardCfg.Enabled ? "超温保护已启用" : "超温保护已关闭";
        }

        void OnGuardValueChanged(object sender, EventArgs e)
        {
            if (_loading || _guardCfg == null) return;
            double t = (double)numTrigger.Value;
            double r = (double)numRelease.Value;

            // Enforce a gap so the guard cannot flap around a single temperature.
            if (r >= t - 3)
            {
                r = t - 5;
                if (r < (double)numRelease.Minimum) r = (double)numRelease.Minimum;
                bool prev = _loading;
                _loading = true;
                try { numRelease.Value = (decimal)r; }
                finally { _loading = prev; }
            }

            _guardCfg.TriggerC = t;
            _guardCfg.ReleaseC = r;
            _guardCfg.LimitMaxState = (int)numLimit.Value;
            GuardStore.Save(_guardCfg);
            UpdateGuardUi();
        }

        // ------------------------------------------------------------ 温度墙
        //
        // 与超温保护的区别：超温保护是"越过阈值才动手"的二元开关，会在触发点附近
        // 来回震荡；温度墙是闭环连续控制，把"最高温度"当目标，越接近目标越早开始
        // 收力，使温度收敛在目标附近。
        //
        // 安全性：所有分支只做"降低功耗"，任何路径都不会提高处理器的发热；下限由
        // FloorState 兜住，不会把机器压到不可用。

        void OnWallEnableChanged(object sender, EventArgs e)
        {
            if (_loading) return;
            _wallCfg.Enabled = chkWall.Checked;
            WallStore.Save(_wallCfg);
            if (!_wallCfg.Enabled) WallHandBack("温度墙已关闭");
            UpdateWallUi();
            stStatus.Text = _wallCfg.Enabled
                ? "温度墙已启用：目标 " + _wallCfg.TargetC.ToString("0") + "°C"
                : "温度墙已关闭，已恢复你设定的处理器上限";
        }

        void OnWallValueChanged(object sender, EventArgs e)
        {
            if (_loading || _wallCfg == null) return;
            _wallCfg.TargetC = (double)numWallTarget.Value;
            _wallCfg.DropTurbo = chkWallTurbo.Checked;
            _wallCfg.LinkFanBoost = chkWallBoost.Checked;
            WallStore.Save(_wallCfg);
            UpdateWallUi();
        }

        // 把控制权交还给用户设定的值（用户改了滑块 / 切了场景 / 关了温度墙）
        void WallHandBack(string why)
        {
            int baseState = _wallBaseState > 0 ? _wallBaseState : tbMax.Value;
            if (_wallApplied > 0)
            {
                Power.SetMaxState(baseState);
                Log.Write("ThermalWall hand-back (" + why + ") -> max state " + baseState + "%");
                _wallApplied = -1;
            }
            _wallActive = false;
            if (_wallCfg.BaseState != 0) { _wallCfg.BaseState = 0; WallStore.Save(_wallCfg); }
            if (_wallTurboDropped)
            {
                Power.SetTurbo(true);
                _wallTurboDropped = false;
            }
            if (_wallBoostByWall)
            {
                Ec.FanBoost.Disable();
                _wallBoostByWall = false;
                UpdateFanUi();
            }
            RefreshPowerUi();
            UpdateWallUi();
        }

        void WallTick(double tempC)
        {
            if (_wallCfg == null || tempC <= 0 || !_wallCfg.Enabled) return;
            if (_guardActive) return;              // 超温保护接管时让位

            int baseState = _wallBaseState > 0 ? _wallBaseState : tbMax.Value;
            int cur = _wallApplied > 0 ? _wallApplied : baseState;
            int next = cur;

            // 上次运行在压制期间退出时，实时值会是那个被压低的上限。温度已经降
            // 下来就先把用户记录的基线恢复回去，避免"重启一次永久降一档"。
            if (_wallCfg.BaseState > 0 && _wallCfg.BaseState != baseState &&
                tempC <= _wallCfg.TargetC - _wallCfg.HysteresisC && Elevation.IsElevated())
            {
                Power.SetMaxState(_wallCfg.BaseState);
                Log.Write("ThermalWall: 恢复上次被压制的基线 " + _wallCfg.BaseState + "%");
                _wallBaseState = _wallCfg.BaseState;
                _loading = true;
                try { tbMax.Value = Clamp(_wallCfg.BaseState, tbMax.Minimum, tbMax.Maximum); }
                finally { _loading = false; }
                baseState = _wallCfg.BaseState;
                cur = baseState;
                next = cur;
            }

            if (tempC >= _wallCfg.TargetC)
            {
                if (Elevation.IsElevated())
                {
                    double over = tempC - _wallCfg.TargetC;
                    int step = (int)Math.Ceiling(_wallCfg.StepPercent * (1.0 + over / 5.0));
                    next = Math.Max(_wallCfg.FloorState, Math.Min(baseState, cur - step));
                    if (next != cur)
                    {
                        if (_wallCfg.BaseState != baseState)
                        {
                            _wallCfg.BaseState = baseState;   // 记住用户的基线
                            WallStore.Save(_wallCfg);
                        }
                        Power.SetMaxState(next);
                        _wallApplied = next;
                        Log.Write(string.Format(CultureInfo.InvariantCulture,
                            "ThermalWall: {0:0.0}C over target -> max state {1}%", tempC, next));
                    }
                }
                _wallActive = true;
            }
            else if (tempC <= _wallCfg.TargetC - _wallCfg.HysteresisC && cur < baseState)
            {
                if (Elevation.IsElevated())
                {
                    next = Math.Min(baseState, cur + _wallCfg.StepPercent);
                    if (next != cur)
                    {
                        Power.SetMaxState(next);
                        _wallApplied = next;
                        Log.Write(string.Format(CultureInfo.InvariantCulture,
                            "ThermalWall: {0:0.0}C cooled -> max state {1}%", tempC, next));
                    }
                }
                if (next >= baseState) { _wallApplied = -1; _wallActive = false; }
            }
            else
            {
                _wallActive = false;
            }

            // 明显超温时额外关闭睿频（回来再打开）
            if (_wallCfg.DropTurbo && Elevation.IsElevated())
            {
                bool want = tempC > _wallCfg.TargetC + 5;
                if (want && !_wallTurboDropped)
                {
                    Power.SetTurbo(false);
                    _wallTurboDropped = true;
                    RefreshPowerUi();
                }
                else if (!want && _wallTurboDropped && tempC <= _wallCfg.TargetC - _wallCfg.HysteresisC)
                {
                    Power.SetTurbo(true);
                    _wallTurboDropped = false;
                    RefreshPowerUi();
                }
            }

            WallFanLink(tempC);
            UpdateWallUi();
        }

        // 接近目标时自动开强冷（原生 EC）。只关闭"由温度墙自己开的那一次"，
        // 不会覆盖用户手动切换的强冷状态。
        void WallFanLink(double tempC)
        {
            if (_wallCfg == null || !_wallCfg.LinkFanBoost) return;
            if (!Ec.IsOpen && !Ec.Open()) return;

            double on = _wallCfg.TargetC - _wallCfg.LinkMarginC;
            double off = _wallCfg.TargetC - _wallCfg.HysteresisC - 2;

            if (!_wallBoostByWall && tempC >= on)
            {
                string r = Ec.FanBoost.Enable();
                _wallBoostByWall = true;
                Log.Write("ThermalWall: 联动强冷开启 (" +
                          tempC.ToString("0.0", CultureInfo.InvariantCulture) + "C) - " + r);
                UpdateFanUi();
            }
            else if (_wallBoostByWall && tempC <= off)
            {
                Ec.FanBoost.Disable();
                _wallBoostByWall = false;
                Log.Write("ThermalWall: 联动强冷关闭");
                UpdateFanUi();
            }
        }

        void UpdateWallUi()
        {
            if (chkWall == null) return;
            if (!_wallCfg.Enabled) chkWall.ForeColor = CText;
            else if (_wallActive) chkWall.ForeColor = CDanger;
            else chkWall.ForeColor = CGreen;
            UpdateGuardUi();       // 状态行由两套机制合并显示
        }

        void RefreshWallUi()
        {
            bool prev = _loading;
            _loading = true;
            try
            {
                chkWall.Checked = _wallCfg.Enabled;
                numWallTarget.Value = Clamp((int)Math.Round(_wallCfg.TargetC),
                                            (int)numWallTarget.Minimum, (int)numWallTarget.Maximum);
                chkWallTurbo.Checked = _wallCfg.DropTurbo;
                chkWallBoost.Checked = _wallCfg.LinkFanBoost;
            }
            finally { _loading = prev; }
            UpdateWallUi();
        }

        // Runs on every tick, including while hidden in the tray.
        void GuardTick(double tempC)
        {
            if (_guardCfg == null || tempC <= 0) return;

            if (!_guardCfg.Enabled)
            {
                if (_guardActive) GuardRelease("保护已关闭");
                return;
            }
            if (_guardActive)
            {
                if (tempC <= _guardCfg.ReleaseC) GuardRelease("温度已回落");
                return;
            }
            if (_guardBlocked)
            {
                if (tempC < _guardCfg.ReleaseC - 3) { _guardBlocked = false; UpdateGuardUi(); }
                return;
            }
            if (!Elevation.IsElevated()) return;      // cannot write power settings
            if (tempC >= _guardCfg.TriggerC) GuardEngage(tempC);
        }

        void GuardEngage(double tempC)
        {
            _guardSaved = Power.Read();
            _guardActive = true;
            string rep = Power.ApplyLimits(_guardCfg);
            Log.Write("ThermalGuard ENGAGED at " + tempC.ToString("0.0", CultureInfo.InvariantCulture) +
                      " C" + Environment.NewLine + rep);
            stStatus.Text = "超温保护已触发：限功耗降温中（" + tempC.ToString("0.0") + "°C）";
            if (_tray != null)
            {
                _tray.ShowBalloonTip(2500, "系统控制台 · 超温保护",
                    "温度 " + tempC.ToString("0.0") + "°C 超过阈值，已自动把处理器上限降到 " +
                    _guardCfg.LimitMaxState + "% 以降低发热。", ToolTipIcon.Warning);
            }
            RefreshPowerUi();
            UpdateGuardUi();
        }

        void GuardRelease(string why)
        {
            if (!_guardActive) return;
            _guardActive = false;
            string rep = Power.RestoreState(_guardSaved);
            _guardSaved = null;
            Log.Write("ThermalGuard RELEASED (" + why + ")" + Environment.NewLine + rep);
            stStatus.Text = "超温保护已解除：" + why + "，已恢复原设置";
            if (_tray != null)
            {
                _tray.ShowBalloonTip(2000, "系统控制台 · 超温保护",
                    "温度已回落，已恢复原有性能设置。", ToolTipIcon.Info);
            }
            RefreshPowerUi();
            UpdateGuardUi();
        }

        // The user changed the mode by hand: stop overriding them, and re-arm only
        // after the machine has actually cooled down.
        void GuardUserOverride()
        {
            if (!_guardActive) return;
            _guardActive = false;
            _guardBlocked = true;
            _guardSaved = null;
            Log.Write("ThermalGuard paused by user override");
            UpdateGuardUi();
        }

        void UpdateGuardUi()
        {
            if (chkGuard == null) return;
            // The checkbox caption stays short so it always fits; state is carried
            // by colour plus the status line underneath.
            if (_guardActive) chkGuard.ForeColor = CDanger;
            else if (_guardBlocked) chkGuard.ForeColor = CWarn;
            else chkGuard.ForeColor = CText;

            if (lblWallStatus == null) return;

            // ---- 温度墙 ----
            string w;
            if (!_wallCfg.Enabled) w = "温度墙 关闭";
            else if (!Elevation.IsElevated()) w = "温度墙 需管理员权限";
            else if (_wallActive) w = "温度墙 压制中 → 上限 " + (_wallApplied > 0 ? _wallApplied : tbMax.Value) + "%";
            else w = "温度墙 监控中（目标 " + _wallCfg.TargetC.ToString("0") + "°C）";
            if (_wallCfg.Enabled && _wallBoostByWall) w += " · 强冷已联动";

            // ---- 超温保护 ----
            string g;
            if (!_guardCfg.Enabled) g = "超温保护 关闭";
            else if (_guardActive) g = "超温保护 已触发 → 上限 " + _guardCfg.LimitMaxState + "%";
            else if (_guardBlocked) g = "超温保护 已暂停（手动改过模式）";
            else if (!Elevation.IsElevated()) g = "超温保护 需管理员权限";
            else g = "超温保护 待命（" + _guardCfg.TriggerC.ToString("0") + "°C）";

            lblWallStatus.Text = w + "        " + g;
            lblWallStatus.ForeColor = (_wallActive || _guardActive) ? CDanger : CSub;
        }

        void RefreshGuardUi()
        {
            bool prev = _loading;
            _loading = true;
            try
            {
                chkGuard.Checked = _guardCfg.Enabled;
                numTrigger.Value = Clamp((int)Math.Round(_guardCfg.TriggerC), (int)numTrigger.Minimum, (int)numTrigger.Maximum);
                numRelease.Value = Clamp((int)Math.Round(_guardCfg.ReleaseC), (int)numRelease.Minimum, (int)numRelease.Maximum);
                numLimit.Value = Clamp(_guardCfg.LimitMaxState, (int)numLimit.Minimum, (int)numLimit.Maximum);
            }
            finally { _loading = prev; }
            UpdateGuardUi();
        }

        // ------------------------------------------------------------ 界面缩放

        /// <summary>
        /// 用户改了缩放：存盘后整界面重建一遍。布局数值都是「设计值 × 系数」，
        /// 只在 BuildUi() 里算一次，所以必须重建才能重新排版 —— 运行时的
        /// Control.Scale() 只缩窗体自身，手工改 Bounds 又会被锚定引擎弹回。
        /// </summary>
        void OnScaleChanged(object sender, EventArgs e)
        {
            if (_loading || cmbScale == null) return;
            int pct = UiScaleStore.PercentOf(cmbScale.SelectedItem as string);
            if (pct <= 0 || pct == _uiPct) return;

            UiScaleStore.Save(pct);
            _uiPct = pct;
            Log.Write("界面缩放 -> " + pct + "%");
            // 用 BeginInvoke 推迟一拍：重建会把下拉框自己一起 Dispose，
            // 直接在它自己的 SelectedIndexChanged 里做会崩。
            BeginInvoke(new MethodInvoker(delegate
            {
                RebuildUi();
                if (stStatus != null) stStatus.Text = "界面缩放已调整为 " + _uiPct + "%";
            }));
        }

        void RebuildUi()
        {
            SuspendLayout();
            try
            {
                List<Control> old = new List<Control>();
                foreach (Control c in Controls) old.Add(c);
                Controls.Clear();
                for (int i = 0; i < old.Count; i++) old[i].Dispose();

                BuildUi();

                // 重建后把运行状态重新贴回新控件上
                _guardCfg = GuardStore.Load(); RefreshGuardUi();
                _wallCfg = WallStore.Load(); RefreshWallUi();
                RefreshPowerUi();
                RefreshAutoStartUi();
                UpdatePresetLabel();
                RefreshLightUi();
            }
            catch (Exception ex)
            {
                Log.Write("界面重建失败: " + ex.Message);
                if (stStatus != null) stStatus.Text = "界面重建失败，请重启程序";
            }
            finally
            {
                ResumeLayout(true);
                PerformLayout();
            }
        }

        void OnElevateClick(object sender, EventArgs e)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo(Application.ExecutablePath);
                psi.UseShellExecute = true;
                psi.Verb = "runas";
                Process.Start(psi);
                _reallyExit = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "提权启动失败：" + ex.Message, "系统控制台",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
