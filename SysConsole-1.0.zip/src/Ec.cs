// ============================================================================
//  SysConsole — Ec.cs
//  EC（嵌入式控制器）原生访问层。这是整个项目里唯一直接读写硬件寄存器的文件。
//  走的是 \.\ACPIDriver，IOCTL 0x9C40A488(读) / 0x9C40A48C(写)。
//
//  主要内容：
//    Ec             打开/读写/回读校验，设备丢失时用 pnputil 重新枚举
//    Ec.FanBoost    风扇强冷开关（0x751 的 0x40 位）
//    Ec.KbColor     键盘背光颜色（0x769/0x76A/0x76B 写电平，0x767 bit5 提交）
//
//  注意：背光电平有效范围是 1..50，直接把 0..255 的原始分量写进去会把灯关掉；
//        详见 docs/KEYBOARD-LIGHT-PROTOCOL.md。
//
//    · 编译：系统自带 csc.exe（.NET Framework 4.8），无 SDK / 无网络 / 无第三方库
//    · 语法：C# 5，不用 async/await、字符串插值、nameof 等新语法
//    · 编码：UTF-8；.ps1 脚本另需纯 ASCII 或带 BOM，否则 PS 5.1 会按 GBK 解码
//    · 硬件寄存器地址来自原厂文件反汇编 + 本机实测，出处见 docs/ 下的协议文档
// ============================================================================

using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace SysConsole
{

// ============================================================================
//  Ec.cs — 原生嵌入式控制器（EC）访问 + 风扇强冷
//
//  这条链路完全不依赖机械革命控制中心的任何进程/服务/DLL：
//
//      SysConsole ──CreateFile──▶ \\.\ACPIDriver ──▶ UWACPIDriver.sys ──▶ EC
//                                  │
//                                  └─ DeviceIoControl(0x9C40A488 / 0x9C40A48C)
//
//  设备 \\.\ACPIDriver 由 BIOS ACPI 命名空间中的真实设备 _SB.INOU
//  （_HID = "INOU0000"）枚举而来。驱动程序 UWACPIDriver.sys 由微软
//  WHQL 签名（oem111.inf，类 {4d36e97d-...}，KMDF 1.15），随系统内置安装，
//  不需要安装任何 OEM 软件。若设备不存在（例如被 OEM 卸载脚本
//  `devcon remove acpi\INOU0000` 删除），一次 PnP 重新扫描即可恢复：
//      pnputil /scan-devices
//
//  协议逆向自 ACPIDriverDll.dll 的导出函数（ReadEC RVA 0x3410 /
//  WriteEC RVA 0x34F0）反汇编结果，并用写入通道回读校验：
//
//      共享缓冲区（0x400000 字节，输入与输出为同一指针）
//      Read :  buf[0..3] = 地址       →  DeviceIoControl(0x9C40A488)
//              返回 buf[0]
//      Write:  buf[0..3] = 地址
//              buf[4..7] = 数值       →  DeviceIoControl(0x9C40A48C)
//
//  风扇寄存器（实测本机 GM6AR57C）：
//      0x751  风扇模式选择器（位域）
//              0x00 = 安静      (稳态占空比 ≈120)
//              0x10 = 标准      (≈140)
//              0x30 = 出厂默认  (≈140)
//              0x40 = 强冷位 ★  (≈200；风扇1 4607→5891 RPM)
//              0xA0 = 静音      (≈100)
//              实测 EC 会把强冷位与基础模式按位或，例如 0x30 开强冷后
//              自行变成 0x70 = 0x30 | 0x40。因此一切判断都必须按位测试
//              (v & 0x40)，不能写成 v == 0x40。
//      0x464/0x465  风扇1 转速 = (0x464<<8) | 0x465
//      0x46B/0x46C  风扇2 转速 = (0x46C<<8) | 0x46B
//      0x75B/0x75C  风扇1/风扇2 占空比（EC 只读输出，写入会被立刻覆盖）
//      0x730/0x731  GAMING PL1/PL2 (W)   0x734/0x735  OFFICE PL1/PL2 (W)
//      0x783/0x784/0x785  生效中的 PL1/PL2/PL4
//      0x7D8  TCC 偏移
//
//  安全性：0x40 经实测写入后风扇升速、还原后立刻回落；温度寄存器全程不变，
//  证明是模式驱动而非温度驱动。关闭强冷时优先写回进入强冷前记录的原值。
// ============================================================================

public static class Ec
{
    // ---- Win32 ----
    const uint GENERIC_READ = 0x80000000;
    const uint GENERIC_WRITE = 0x40000000;
    const uint OPEN_EXISTING = 3;
    const uint FILE_SHARE_RW = 3;

    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    static extern IntPtr CreateFileW(string name, uint access, uint share,
                                     IntPtr sa, uint disposition, uint flags, IntPtr template);
    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool DeviceIoControl(IntPtr h, uint code, IntPtr inBuf, uint inSize,
                                       IntPtr outBuf, uint outSize, out uint returned, IntPtr overlapped);
    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool CloseHandle(IntPtr h);

    // ---- 协议常量 ----
    public const string DevicePath = @"\\.\ACPIDriver";
    public const string HardwareId = @"ACPI\INOU0000";
    const uint IOCTL_READ_EC = 0x9C40A488;
    const uint IOCTL_WRITE_EC = 0x9C40A48C;
    const int BUF_SIZE = 64;                  // 实测：ACPIDriver 只用到前 8 字节，
                                              // 原来照抄 DLL 的 0x400000 纯属浪费——
                                              // 每次调用都锁/清零 4MB，IOCTL 从 0.006s 降到
                                              // 0.0001s（约 60 倍），并发池压力消失。
                                              // 读/写/回读校验均已用同一值往返验证通过。
    static readonly IntPtr INVALID = (IntPtr)(-1);

    // ---- 寄存器 ----
    public const int REG_FAN1_RPM_HI = 0x464, REG_FAN1_RPM_LO = 0x465;
    public const int REG_FAN2_RPM_HI = 0x46C, REG_FAN2_RPM_LO = 0x46B;
    public const int REG_FAN1_DUTY = 0x75B, REG_FAN2_DUTY = 0x75C;
    public const int REG_FAN_CTRL = 0x751;
    public const int REG_PL1_GAMING = 0x730, REG_PL2_GAMING = 0x731;
    public const int REG_PL1_OFFICE = 0x734, REG_PL2_OFFICE = 0x735;
    public const int REG_PL1_LIVE = 0x783, REG_PL2_LIVE = 0x784, REG_PL4_LIVE = 0x785;
    public const int REG_TCC_OFFSET = 0x7D8;

    // ---- 键盘背光 / Logo 灯寄存器（原厂常量表 + 实测）----
    public const int REG_KB_TRIGGER = 0x767;   // ADDR_TRIGGER_BYTE  提交触发器，bit5=0x20
    public const int REG_KB_STATUS = 0x768;   // ADDR_STAUTS_BYTE
    public const int REG_KB_LEVEL_R = 0x769;   // RGBKB_LEVEL_R / AP_EC_LOGO_R
    public const int REG_KB_LEVEL_G = 0x76A;   // RGBKB_LEVEL_G / AP_EC_LOGO_G
    public const int REG_KB_LEVEL_B = 0x76B;   // RGBKB_LEVEL_B / AP_EC_LOGO_B
    public const int REG_KB_DEF_R = 0x76C;   // RGBKB_LEVEL_DEFAULT_R
    public const int REG_KB_DEF_G = 0x76D;   // RGBKB_LEVEL_DEFAULT_G
    public const int REG_KB_DEF_B = 0x76E;   // RGBKB_LEVEL_DEFAULT_B
    public const int REG_KB_MODE = 0x7AB;   // AP_EC_LOGO / 效果索引

    // ---- 风扇模式值 ----
    public const int FAN_MODE_QUIET = 0x00;   // 安静
    public const int FAN_MODE_STD_A = 0x10;   // 标准
    public const int FAN_MODE_STOCK = 0x30;   // 本机出厂默认（无记录时的回退值）
    public const int FAN_MODE_BOOST = 0x40;   // ★ 强冷
    public const int FAN_MODE_SILENT = 0xA0;  // 静音

    static IntPtr _h = INVALID;
    static IntPtr _buf = IntPtr.Zero;
    static readonly object _sync = new object();

    public static string LastError = "";

    // ------------------------------------------------------------------ 打开

    public static bool IsOpen { get { lock (_sync) { return _h != INVALID; } } }

    /// <summary>打开 EC 设备。成功返回 true；失败时 LastError 含原因。</summary>
    public static bool Open()
    {
        lock (_sync)
        {
            if (_h != INVALID) return true;
            if (_buf == IntPtr.Zero) _buf = Marshal.AllocHGlobal(BUF_SIZE);
            IntPtr h = CreateFileW(DevicePath, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_RW,
                                   IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
            if (h == INVALID)
            {
                LastError = string.Format(CultureInfo.InvariantCulture,
                    "CreateFile({0}) 失败，Win32 错误 {1}", DevicePath, Marshal.GetLastWin32Error());
                return false;
            }
            _h = h;
            LastError = "";
            return true;
        }
    }

    public static void Close()
    {
        lock (_sync)
        {
            if (_h != INVALID) { CloseHandle(_h); _h = INVALID; }
        }
    }

    /// <summary>
    /// 确保设备可用。若 \\.\ACPIDriver 不存在，触发一次 PnP 重新扫描——
    /// 驱动包本身已在 DriverStore 中，重新扫描会让 ACPI 总线再次枚举
    /// ACPI\INOU0000 并自动加载 UWACPIDriver.sys。需要管理员权限。
    /// </summary>
    public static string EnsureDevice()
    {
        if (Open()) return "EC 设备已就绪";

        string first = LastError;
        if (!Elevation.IsElevated())
            return "EC 设备不可用（" + first + "）。恢复设备需要管理员权限。";

        try
        {
            ProcessStartInfo psi = new ProcessStartInfo("pnputil.exe", "/scan-devices");
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            using (Process p = Process.Start(psi))
            {
                p.StandardOutput.ReadToEnd();
                p.StandardError.ReadToEnd();
                p.WaitForExit(20000);
            }
        }
        catch (Exception ex)
        {
            return "pnputil 重新扫描失败: " + ex.Message;
        }

        // 枚举是新设备并加载驱动需要一点时间
        for (int i = 0; i < 20; i++)
        {
            Thread.Sleep(700);
            if (Open()) return "EC 设备已重新枚举并就绪（" + HardwareId + "）";
        }
        return "已触发重新扫描，但设备仍未出现（" + LastError + "）。可能需要重启。";
    }

    // ------------------------------------------------------------------ 读写

    /// <summary>读一个 EC 字节。失败返回 -1。</summary>
    public static int Read(int addr)
    {
        if (!Open()) return -1;
        lock (_sync)
        {
            for (int i = 0; i < 8; i++) Marshal.WriteByte(_buf, i, 0);
            Marshal.WriteInt32(_buf, 0, addr);
            uint ret;
            if (!DeviceIoControl(_h, IOCTL_READ_EC, _buf, BUF_SIZE, _buf, BUF_SIZE, out ret, IntPtr.Zero))
            {
                LastError = "DeviceIoControl(READ_EC) 失败，Win32 错误 " + Marshal.GetLastWin32Error();
                Close();
                return -1;
            }
            return Marshal.ReadByte(_buf, 0);
        }
    }

    /// <summary>写一个 EC 字节。</summary>
    public static bool Write(int addr, int value)
    {
        if (!Open()) return false;
        lock (_sync)
        {
            for (int i = 0; i < 8; i++) Marshal.WriteByte(_buf, i, 0);
            Marshal.WriteInt32(_buf, 0, addr);
            Marshal.WriteInt32(_buf, 4, value & 0xFF);
            uint ret;
            if (!DeviceIoControl(_h, IOCTL_WRITE_EC, _buf, BUF_SIZE, _buf, BUF_SIZE, out ret, IntPtr.Zero))
            {
                LastError = "DeviceIoControl(WRITE_EC) 失败，Win32 错误 " + Marshal.GetLastWin32Error();
                Close();
                return false;
            }
            return true;
        }
    }

    /// <summary>写后回读校验（用于确认模式切换真的生效）。</summary>
    public static bool WriteVerify(int addr, int value)
    {
        if (!Write(addr, value)) return false;
        Thread.Sleep(120);
        return Read(addr) == (value & 0xFF);
    }

    // ------------------------------------------------------------------ 风扇

    public class FanReadout
    {
        public bool Ok;
        public int Fan1Rpm, Fan2Rpm;
        public int Fan1Duty, Fan2Duty;
        public int FanCtrl;
        public string Error = "";
        public bool Boosted { get { return (FanCtrl & FAN_MODE_BOOST) != 0; } }

        /// <summary>清掉强冷位后的基础模式。</summary>
        public int BaseMode { get { return FanCtrl & ~FAN_MODE_BOOST & 0xFF; } }

        public string ModeName
        {
            get
            {
                // 强冷是一个独立的位，可以和任意基础模式共存（EC 会自行按位或，
                // 例如 0x30 开强冷后读到 0x70），所以先判位再看基础模式。
                string b;
                switch (BaseMode)
                {
                    case FAN_MODE_QUIET: b = "安静"; break;
                    case FAN_MODE_STD_A: b = "标准"; break;
                    case FAN_MODE_STOCK: b = "默认"; break;
                    case FAN_MODE_SILENT: b = "静音"; break;
                    default: b = "0x" + BaseMode.ToString("X2", CultureInfo.InvariantCulture); break;
                }
                return Boosted ? (b + " + 强冷") : b;
            }
        }

        public string Summary
        {
            get
            {
                if (!Ok) return "风扇: 读取失败" + (Error.Length > 0 ? "（" + Error + "）" : "");
                return string.Format(CultureInfo.InvariantCulture,
                    "风扇  {0} / {1} RPM    占空比 {2} / {3}    模式 {4}",
                    Fan1Rpm, Fan2Rpm, Fan1Duty, Fan2Duty, ModeName);
            }
        }
    }

    public static FanReadout ReadFan()
    {
        FanReadout r = new FanReadout();
        if (!Open()) { r.Error = LastError; return r; }

        int a = Read(REG_FAN1_RPM_HI), b = Read(REG_FAN1_RPM_LO);
        int c = Read(REG_FAN2_RPM_HI), d = Read(REG_FAN2_RPM_LO);
        int e = Read(REG_FAN1_DUTY), f = Read(REG_FAN2_DUTY), g = Read(REG_FAN_CTRL);
        if (a < 0 || b < 0 || c < 0 || d < 0 || e < 0 || f < 0 || g < 0)
        {
            r.Error = LastError.Length > 0 ? LastError : "EC 读取失败";
            return r;
        }
        r.Fan1Rpm = (a << 8) | b;     // 实测 0x464 为高位
        r.Fan2Rpm = (c << 8) | d;     // 实测 0x46C 为高位
        r.Fan1Duty = e;
        r.Fan2Duty = f;
        r.FanCtrl = g;
        r.Ok = true;
        return r;
    }

    // ------------------------------------------------------------ 强冷开关

    /// <summary>
    /// 强冷开关。打开时把进入前的 0x751 原值记到磁盘，关闭时精确还原——
    /// 这样"关闭"不会把用户原本的风扇模式一并改掉。
    /// </summary>
    public static class FanBoost
    {
        public static string StorePath()
        {
            return Path.Combine(Log.Dir(), "fanboost.txt");
        }

        static int LoadSaved()
        {
            try
            {
                string p = StorePath();
                if (!File.Exists(p)) return -1;
                string t = File.ReadAllText(p).Trim();
                int v;
                if (int.TryParse(t, NumberStyles.Integer, CultureInfo.InvariantCulture, out v)) return v;
            }
            catch { }
            return -1;
        }

        static void SaveSaved(int value)
        {
            try
            {
                string p = StorePath();
                if (value < 0) { if (File.Exists(p)) File.Delete(p); return; }
                File.WriteAllText(p, value.ToString(CultureInfo.InvariantCulture));
            }
            catch { }
        }

        public static bool IsOn()
        {
            int v = Ec.Read(REG_FAN_CTRL);
            return v >= 0 && (v & FAN_MODE_BOOST) != 0;
        }

        /// <summary>开启强冷：只置强冷位，保留原有基础模式。</summary>
        public static string Enable()
        {
            if (!Ec.Open()) return "EC 设备不可用：" + LastError;

            int cur = Ec.Read(REG_FAN_CTRL);
            if (cur < 0) return "读取风扇寄存器失败：" + LastError;

            int baseMode = cur & ~FAN_MODE_BOOST & 0xFF;
            if ((cur & FAN_MODE_BOOST) != 0)
            {
                if (LoadSaved() < 0) SaveSaved(baseMode);
                return "强冷已处于开启状态";
            }

            // 记住强冷位之外的基础模式，关闭时精确还原，避免顺带改掉用户的风扇模式
            SaveSaved(baseMode);

            int target = baseMode | FAN_MODE_BOOST;
            if (!Ec.WriteVerify(REG_FAN_CTRL, target))
                return "写入强冷模式失败（" + LastError + "）";

            Log.Write(string.Format(CultureInfo.InvariantCulture,
                "FanBoost ON: 0x751 0x{0:X2} -> 0x{1:X2}", cur, target));
            return "强冷已开启（0x751: 0x" + cur.ToString("X2", CultureInfo.InvariantCulture) +
                   " → 0x" + target.ToString("X2", CultureInfo.InvariantCulture) + "），风扇将升到高转速";
        }

        /// <summary>关闭强冷：还原到开启前记录的基础模式。</summary>
        public static string Disable()
        {
            if (!Ec.Open()) return "EC 设备不可用：" + LastError;

            int target = LoadSaved();
            if (target < 0) target = FAN_MODE_STOCK;      // 无记录（例如强冷期间重启过）
            target &= ~FAN_MODE_BOOST & 0xFF;

            int cur = Ec.Read(REG_FAN_CTRL);
            if (cur >= 0 && (cur & FAN_MODE_BOOST) == 0 && cur == target)
            {
                SaveSaved(-1);
                return "强冷已处于关闭状态";
            }

            if (!Ec.WriteVerify(REG_FAN_CTRL, target))
                return "还原风扇模式失败（" + LastError + "）";

            SaveSaved(-1);
            Log.Write(string.Format(CultureInfo.InvariantCulture,
                "FanBoost OFF: 0x751 -> 0x{0:X2}", target));
            return "强冷已关闭，风扇模式已还原为 0x" + target.ToString("X2", CultureInfo.InvariantCulture);
        }

        public static string Toggle()
        {
            return IsOn() ? Disable() : Enable();
        }

        public static string Status()
        {
            FanReadout r = ReadFan();
            if (!r.Ok) return "风扇状态读取失败：" + r.Error;
            return string.Format(CultureInfo.InvariantCulture,
                "强冷     : {0}\r\n风扇模式 : 0x{1:X2} ({2})\r\n风扇1    : {3} RPM，占空比 {4}\r\n风扇2    : {5} RPM，占空比 {6}",
                r.Boosted ? "已开启" : "已关闭", r.FanCtrl, r.ModeName,
                r.Fan1Rpm, r.Fan1Duty, r.Fan2Rpm, r.Fan2Duty);
        }
    }

    // ------------------------------------------------------------ 诊断报告

    public static string Report()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("--- EC / 风扇（原生 IOCTL 直连）---");
        sb.AppendLine("  设备路径 : " + DevicePath);
        sb.AppendLine("  硬件 ID  : " + HardwareId + "  (BIOS ACPI _SB.INOU)");
        sb.AppendLine("  IOCTL    : 读 0x" + IOCTL_READ_EC.ToString("X8", CultureInfo.InvariantCulture) +
                      "  写 0x" + IOCTL_WRITE_EC.ToString("X8", CultureInfo.InvariantCulture) +
                      "  缓冲 " + BUF_SIZE + " 字节");
        sb.AppendLine("  依赖 OEM : 无（仅需微软 WHQL 签名的 UWACPIDriver.sys）");

        if (!Open())
        {
            sb.AppendLine("  状态     : 不可用 — " + LastError);
            sb.AppendLine("  恢复方法 : pnputil /scan-devices   （管理员）");
            sb.AppendLine();
            return sb.ToString();
        }

        FanReadout r = ReadFan();
        if (!r.Ok)
        {
            sb.AppendLine("  状态     : 已打开，但读取失败 — " + r.Error);
        }
        else
        {
            sb.AppendLine("  状态     : 已连接");
            sb.AppendLine("  风扇模式 : 0x" + r.FanCtrl.ToString("X2", CultureInfo.InvariantCulture) + " (" + r.ModeName + ")");
            sb.AppendLine("  风扇1    : " + r.Fan1Rpm + " RPM    占空比 " + r.Fan1Duty + " / 255");
            sb.AppendLine("  风扇2    : " + r.Fan2Rpm + " RPM    占空比 " + r.Fan2Duty + " / 255");
            sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                "  功耗上限 : GAMING PL1={0}W PL2={1}W   OFFICE PL1={2}W PL2={3}W",
                Read(REG_PL1_GAMING), Read(REG_PL2_GAMING), Read(REG_PL1_OFFICE), Read(REG_PL2_OFFICE)));
            sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                "  生效限制 : PL1={0}W PL2={1}W PL4={2}W   TCC 偏移={3}",
                Read(REG_PL1_LIVE), Read(REG_PL2_LIVE), Read(REG_PL4_LIVE), Read(REG_TCC_OFFSET)));
            sb.AppendLine("  强冷开关 : " + (r.Boosted ? "已开启" : "已关闭") +
                          "   (关闭时还原值: " + (FanBoost.IsOn() ? "记录中" : "无") + ")");
            sb.AppendLine();
            sb.AppendLine("  风扇模式对照（0x751 位域，本机实测）:");
            sb.AppendLine("    0x00 安静      稳态占空比 ≈120");
            sb.AppendLine("    0x10 标准      ≈140");
            sb.AppendLine("    0x30 出厂默认  ≈140");
            sb.AppendLine("    0x40 强冷位 ★  ≈200   风扇1 4607→5891 RPM");
            sb.AppendLine("    0x70 0x30|强冷 ≈200   EC 自行按位或的结果");
            sb.AppendLine("    0xA0 静音      ≈100");
            sb.AppendLine("  说明     : 强冷是独立位(0x40)，与基础模式共存；判断必须按位测试");
        }
        sb.AppendLine();
        return sb.ToString();
    }

    // ------------------------------------------------------------ 键盘背光颜色

    /// <summary>
    /// 键盘背光颜色。协议由原厂 DefaultTool.exe 反汇编还原，并在本机实测通过。
    ///
    /// 原厂代码 MyControlCenter.MyRgbKeyboard.SingleZone.SetRGBLevel (RVA 0x3E43C)：
    ///     WriteECRAM(0x769, rLevel);
    ///     WriteECRAM(0x76A, gLevel);
    ///     WriteECRAM(0x76B, bLevel);
    ///     ReadECRAM(0x767, ref v);
    ///     BitArray ba = new BitArray(new byte[] { (byte)v });
    ///     ba.set_Item(5, 1);
    ///     WriteECRAM(0x767, ConvertToByte(ba));      // ← 提交触发器
    ///
    /// 颜色到电平 (SetRGBColor → RGBValueToLevel → LimitToRange(x, 1, 50))：
    ///     rLevel = clamp(R / 5, 1, 50)
    ///     gLevel = clamp(G / 6, 1, 50)
    ///     bLevel = clamp(B / 6, 1, 50)
    ///
    /// 电平有效范围 1..50。把 0..255 的原始分量直接写进去（例如 255）会超出范围，
    /// EC 会把背光直接关掉——这正是先前写 255 导致键盘灯熄灭的原因。
    /// </summary>
    public static class KbColor
    {
        public const int TRIGGER_BIT = 0x20;   // 0x767 的 bit5

        static int Clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

        public static int LevelFromR(int r) { return Clamp(r / 5, 1, 50); }
        public static int LevelFromG(int g) { return Clamp(g / 6, 1, 50); }
        public static int LevelFromB(int b) { return Clamp(b / 6, 1, 50); }

        /// <summary>电平反推回 0..255 分量（界面回显用）。</summary>
        public static int RFromLevel(int l) { return Clamp(l * 5, 0, 255); }
        public static int GFromLevel(int l) { return Clamp(l * 6, 0, 255); }
        public static int BFromLevel(int l) { return Clamp(l * 6, 0, 255); }

        /// <summary>读当前电平三元组 (0x769/0x76A/0x76B)。</summary>
        public static bool ReadLevels(out int r, out int g, out int b)
        {
            r = Read(REG_KB_LEVEL_R); g = Read(REG_KB_LEVEL_G); b = Read(REG_KB_LEVEL_B);
            return r >= 0 && g >= 0 && b >= 0;
        }

        /// <summary>读出厂默认电平 (0x76C/0x76D/0x76E)，对应原厂 GetEcDefaultRGB。</summary>
        public static bool ReadDefaults(out int r, out int g, out int b)
        {
            r = Read(REG_KB_DEF_R); g = Read(REG_KB_DEF_G); b = Read(REG_KB_DEF_B);
            return r >= 0 && g >= 0 && b >= 0;
        }

        /// <summary>提交：把 0x767 的 bit5 置 1，保留其它位。EC 读回会自行清零。</summary>
        public static bool Commit()
        {
            int cur = Read(REG_KB_TRIGGER);
            if (cur < 0) return false;
            return Write(REG_KB_TRIGGER, cur | TRIGGER_BIT);
        }

        /// <summary>写电平三元组并提交。成功返回 null，失败返回原因。</summary>
        public static string ApplyLevels(int rl, int gl, int bl, bool verify)
        {
            if (!Open()) return "EC 设备不可用：" + LastError;
            rl = Clamp(rl, 0, 255); gl = Clamp(gl, 0, 255); bl = Clamp(bl, 0, 255);
            if (!Write(REG_KB_LEVEL_R, rl)) return "写 0x769 失败：" + LastError;
            if (!Write(REG_KB_LEVEL_G, gl)) return "写 0x76A 失败：" + LastError;
            if (!Write(REG_KB_LEVEL_B, bl)) return "写 0x76B 失败：" + LastError;
            Thread.Sleep(60);
            if (!Commit()) return "触发 0x767 失败：" + LastError;
            Thread.Sleep(120);
            if (verify)
            {
                int rr = Read(REG_KB_LEVEL_R), gg = Read(REG_KB_LEVEL_G), bb = Read(REG_KB_LEVEL_B);
                if (rr != rl || gg != gl || bb != bl)
                    return string.Format(CultureInfo.InvariantCulture,
                        "回读不一致：期望 {0}/{1}/{2}，实际 {3}/{4}/{5}", rl, gl, bl, rr, gg, bb);
            }
            return null;
        }

        /// <summary>按 0..255 的 RGB 设置颜色。</summary>
        public static string ApplyRgb(int r, int g, int b, bool verify)
        {
            return ApplyLevels(LevelFromR(r), LevelFromG(g), LevelFromB(b), verify);
        }

        /// <summary>把 0..255 的 RGB 换算成实际会写入的电平，供界面提示。</summary>
        public static string LevelText(int r, int g, int b)
        {
            return string.Format(CultureInfo.InvariantCulture, "写出电平 {0}/{1}/{2}",
                LevelFromR(r), LevelFromG(g), LevelFromB(b));
        }

        // ---- 持久化：勾选"启动时应用"后，每次启动自动恢复上次颜色 ----

        public static string StorePath() { return Path.Combine(Log.Dir(), "kbcolor.txt"); }

        public static bool LoadSaved(out int r, out int g, out int b)
        {
            r = g = b = -1;
            try
            {
                string p = StorePath();
                if (!File.Exists(p)) return false;
                string[] parts = File.ReadAllText(p).Trim().Split(',');
                if (parts.Length < 3) return false;
                if (!int.TryParse(parts[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out r)) return false;
                if (!int.TryParse(parts[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out g)) return false;
                if (!int.TryParse(parts[2], NumberStyles.Integer, CultureInfo.InvariantCulture, out b)) return false;
                return true;
            }
            catch { return false; }
        }

        public static void SaveSaved(int r, int g, int b)
        {
            try
            {
                File.WriteAllText(StorePath(),
                    string.Format(CultureInfo.InvariantCulture, "{0},{1},{2}", r, g, b));
            }
            catch { }
        }

        public static void ClearSaved()
        {
            try { string p = StorePath(); if (File.Exists(p)) File.Delete(p); } catch { }
        }
    }
}

}
