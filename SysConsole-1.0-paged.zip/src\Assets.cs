using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Reflection;

namespace SysConsole
{
    /// <summary>
    /// 内嵌素材加载器。
    ///
    /// 图标取自原厂控制台安装包（GamingCenter3 的 Assets/C1），挑的是它的模式图标、
    /// 分区图标和品牌 Logo。全部以**嵌入资源**的形式编进 exe，
    /// 所以程序仍然是单文件、不需要旁边再放一个 assets 目录。
    ///
    /// 资源名规则：`SysConsole.assets.<文件名>`，由 build.ps1 的 /resource: 参数生成。
    /// </summary>
    static class Assets
    {
        static readonly Dictionary<string, Image> Cache = new Dictionary<string, Image>();

        /// <summary>取原始大小的原图；没有就返回 null（调用方要能容忍）。</summary>
        public static Image Get(string name)
        {
            lock (Cache)
            {
                Image img;
                if (Cache.TryGetValue(name, out img)) return img;
                img = null;
                try
                {
                    Assembly asm = Assembly.GetExecutingAssembly();
                    using (Stream st = asm.GetManifestResourceStream("SysConsole.assets." + name))
                    {
                        if (st != null) img = Image.FromStream(st);
                    }
                }
                catch { img = null; }
                Cache[name] = img;
                return img;
            }
        }

        /// <summary>
        /// 按目标高度等比缩放。原图是 80x80 的大图，按钮上只要十几像素，
        /// 而且缩放系数会随界面缩放变，所以每次都要重新算。
        /// </summary>
        public static Image GetSized(string name, int height, int maxWidth)
        {
            Image src = Get(name);
            if (src == null || height <= 0) return null;
            int w = Math.Max(1, (int)Math.Round(src.Width * (double)height / src.Height));
            if (maxWidth > 0 && w > maxWidth)
            {
                w = maxWidth;
                height = Math.Max(1, (int)Math.Round(src.Height * (double)maxWidth / src.Width));
            }
            Bitmap b = new Bitmap(w, height);
            using (Graphics g = Graphics.FromImage(b))
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.DrawImage(src, 0, 0, w, height);
            }
            return b;
        }

        /// <summary>把素材做成 Icon（窗口/托盘用）。</summary>
        public static Icon GetIcon(string name, int size)
        {
            Image src = Get(name);
            if (src == null) return null;
            try
            {
                using (Bitmap b = new Bitmap(src, new Size(size, size)))
                {
                    IntPtr h = b.GetHicon();
                    return Icon.FromHandle(h);
                }
            }
            catch { return null; }
        }
    }
}
