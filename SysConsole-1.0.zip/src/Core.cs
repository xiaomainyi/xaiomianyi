// ============================================================================
//  SysConsole — Core.cs
//  纯逻辑层：传感器读取、电源计划控制、开机自启、以及温度墙/超温保护的配置持久化。
//  这里不碰任何界面代码，可以被 GUI 和命令行两条路径共用。
//
//  主要内容：
//    Sensor / Snapshot   温度、风扇、逐核占用、内存等实时快照
//    Power               电源计划：最大/最小处理器状态、睿频、电源模式、散热策略
//    Elevation           管理员权限检测与自我提权
//    Autostart           开机自启（计划任务 SysConsoleAutostart）
//    ThermalWallConfig   + WallStore    温度墙配置与落盘
//    ThermalGuardConfig  + GuardStore   超温保护配置与落盘
//    UiState             窗口位置/尺寸的保存与恢复
//    Log                 日志文件
//
//    · 编译：系统自带 csc.exe（.NET Framework 4.8），无 SDK / 无网络 / 无第三方库
//    · 语法：C# 5，不用 async/await、字符串插值、nameof 等新语法
//    · 编码：UTF-8；.ps1 脚本另需纯 ASCII 或带 BOM，否则 PS 5.1 会按 GBK 解码
//    · 硬件寄存器地址来自原厂文件反汇编 + 本机实测，出处见 docs/ 下的协议文档
// ============================================================================

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Management;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.Win32;

namespace SysConsole
{
    // ------------------------------------------------------------------ models

    public class ZoneReading
    {
        public string Key = "?";
        public string Label = "未知热区";
        public double TempC;
        public double CriticalC;   // 0 = unknown
        public bool HasCritical;
    }

    public class Snapshot
    {
        public DateTime Time = DateTime.Now;
        public List<ZoneReading> Zones = new List<ZoneReading>();
        public double CpuPercent;
        public double[] Cores = new double[0];
        public double MemUsedPercent;
        public double MemTotalMB;
        public double MemAvailMB;
        public double PerfPercent;
        public double FreqMHz;
        public uint ThrottleReasons;
        public int FanCount;
        public double MaxZoneTemp;
        public bool Elevated;
        public string Error = "";
    }

    public class PowerState
    {
        public bool TurboEnabled = true;
        public int Mode = 0;          // 0 = balanced, 1 = best performance, 2 = best efficiency
        public int CoolingPolicy = 1; // 0 = passive, 1 = active
        public int MaxState = 100;
        public int MinState = 5;
    }

    // ------------------------------------------------------------------ native

    [StructLayout(LayoutKind.Sequential)]
    public class MEMORYSTATUSEX
    {
        public uint dwLength;
        public uint dwMemoryLoad;
        public ulong ullTotalPhys;
        public ulong ullAvailPhys;
        public ulong ullTotalPageFile;
        public ulong ullAvailPageFile;
        public ulong ullTotalVirtual;
        public ulong ullAvailVirtual;
        public ulong ullAvailExtendedVirtual;
        public MEMORYSTATUSEX()
        {
            dwLength = (uint)Marshal.SizeOf(typeof(MEMORYSTATUSEX));
        }
    }

    public static class Native
    {
        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool GlobalMemoryStatusEx([In, Out] MEMORYSTATUSEX lpBuffer);

        [DllImport("powrprof.dll")]
        public static extern uint PowerGetActiveScheme(IntPtr userRootPowerKey, out IntPtr activePolicyGuid);

        [DllImport("powrprof.dll")]
        public static extern uint PowerGetEffectiveOverlayScheme(out Guid effectiveOverlayGuid);

        [DllImport("powrprof.dll")]
        public static extern uint PowerSetActiveOverlayScheme(ref Guid overlayGuid);

        [DllImport("kernel32.dll")]
        public static extern IntPtr LocalFree(IntPtr hMem);

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool AttachConsole(int dwProcessId);

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool AllocConsole();
    }

    public static class Elevation
    {
        public static bool IsElevated()
        {
            try
            {
                System.Security.Principal.WindowsIdentity id = System.Security.Principal.WindowsIdentity.GetCurrent();
                System.Security.Principal.WindowsPrincipal p = new System.Security.Principal.WindowsPrincipal(id);
                return p.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);
            }
            catch { return false; }
        }
    }

    // ----------------------------------------------------------------- sensors

    public static class Sensors
    {
        static bool _inited;
        static readonly object _initLock = new object();

        static PerformanceCounter _cpuTotal;
        static PerformanceCounter _perf;
        static PerformanceCounter _freq;
        static PerformanceCounter[] _cores;

        static ManagementObjectSearcher _tzWmi;
        static ManagementObjectSearcher _tzCim;
        static ManagementObjectSearcher _fanSearch;

        public static void Init()
        {
            if (_inited) return;
            lock (_initLock)
            {
                if (_inited) return;
                try { _cpuTotal = new PerformanceCounter("Processor", "% Processor Time", "_Total", true); _cpuTotal.NextValue(); }
                catch { _cpuTotal = null; }
                try { _perf = new PerformanceCounter("Processor Information", "% Processor Performance", "_Total", true); _perf.NextValue(); }
                catch { _perf = null; }
                try { _freq = new PerformanceCounter("Processor Information", "Processor Frequency", "_Total", true); _freq.NextValue(); }
                catch { _freq = null; }
                try
                {
                    int n = Environment.ProcessorCount;
                    _cores = new PerformanceCounter[n];
                    for (int i = 0; i < n; i++)
                    {
                        _cores[i] = new PerformanceCounter("Processor", "% Processor Time",
                            i.ToString(CultureInfo.InvariantCulture), true);
                        _cores[i].NextValue();
                    }
                }
                catch { _cores = null; }
                try { _tzWmi = new ManagementObjectSearcher("root\\wmi", "SELECT * FROM MSAcpi_ThermalZoneTemperature"); }
                catch { _tzWmi = null; }
                try { _tzCim = new ManagementObjectSearcher("root\\cimv2", "SELECT * FROM Win32_PerfFormattedData_Counters_ThermalZoneInformation"); }
                catch { _tzCim = null; }
                try { _fanSearch = new ManagementObjectSearcher("root\\cimv2", "SELECT * FROM Win32_Fan"); }
                catch { _fanSearch = null; }
                _inited = true;
            }
        }

        static double ToD(object o)
        {
            if (o == null) return 0;
            try { return Convert.ToDouble(o, CultureInfo.InvariantCulture); }
            catch { return 0; }
        }

        static string ZoneKey(string raw)
        {
            if (raw == null) return "?";
            string s = raw;
            int i = s.LastIndexOf('\\');
            if (i >= 0) s = s.Substring(i + 1);
            i = s.LastIndexOf('.');
            if (i >= 0) s = s.Substring(i + 1);
            if (s.EndsWith("_0")) s = s.Substring(0, s.Length - 2);
            return s.Trim();
        }

        public static string ZoneLabel(string key)
        {
            string k = (key == null ? "" : key).ToUpperInvariant();
            if (k.Contains("ECTZ")) return "EC 热区";
            if (k.Contains("TZ00")) return "主板热区";
            if (k.Contains("TZ01")) return "副热区";
            return key;
        }

        // Rich source: root\wmi (temperature + trip points). Requires elevation.
        static List<ZoneReading> ReadZonesWmi()
        {
            List<ZoneReading> list = new List<ZoneReading>();
            if (_tzWmi == null) return list;
            try
            {
                ManagementObjectCollection col = _tzWmi.Get();
                foreach (ManagementBaseObject mo in col)
                {
                    try
                    {
                        string inst = Convert.ToString(mo["InstanceName"]);
                        double cur = ToD(mo["CurrentTemperature"]) / 10.0 - 273.15;
                        double crit = ToD(mo["CriticalTripPoint"]) / 10.0 - 273.15;
                        if (cur > -50 && cur < 200)
                        {
                            ZoneReading z = new ZoneReading();
                            z.Key = ZoneKey(inst);
                            z.Label = ZoneLabel(z.Key);
                            z.TempC = cur;
                            if (crit > 0 && crit < 200) { z.CriticalC = crit; z.HasCritical = true; }
                            list.Add(z);
                        }
                    }
                    finally { mo.Dispose(); }
                }
            }
            catch { list.Clear(); }
            return list;
        }

        // Fallback source: root\cimv2 counter class. Works without elevation.
        static List<ZoneReading> ReadZonesCim(out uint throttle)
        {
            throttle = 0;
            List<ZoneReading> list = new List<ZoneReading>();
            if (_tzCim == null) return list;
            try
            {
                ManagementObjectCollection col = _tzCim.Get();
                foreach (ManagementBaseObject mo in col)
                {
                    try
                    {
                        string nm = Convert.ToString(mo["Name"]);
                        double k = ToD(mo["Temperature"]);
                        uint t = 0;
                        try { t = Convert.ToUInt32(mo["ThrottleReasons"]); } catch { }
                        if (t > throttle) throttle = t;
                        if (k > 100 && k < 400)
                        {
                            ZoneReading z = new ZoneReading();
                            z.Key = ZoneKey(nm);
                            z.Label = ZoneLabel(z.Key);
                            z.TempC = k - 273.15;
                            list.Add(z);
                        }
                    }
                    finally { mo.Dispose(); }
                }
            }
            catch { list.Clear(); }
            return list;
        }

        public static Snapshot Read()
        {
            Init();
            Snapshot s = new Snapshot();
            s.Elevated = Elevation.IsElevated();

            uint throttle = 0;
            List<ZoneReading> zones = ReadZonesWmi();
            if (zones.Count == 0)
            {
                zones = ReadZonesCim(out throttle);
            }
            else
            {
                uint t2;
                List<ZoneReading> cim = ReadZonesCim(out t2);
                throttle = t2;
                // merge critical trip points by zone key
                for (int i = 0; i < zones.Count; i++)
                {
                    if (zones[i].HasCritical) continue;
                    for (int j = 0; j < cim.Count; j++)
                    {
                        if (string.Equals(cim[j].Key, zones[i].Key, StringComparison.OrdinalIgnoreCase))
                        {
                            if (cim[j].HasCritical)
                            {
                                zones[i].CriticalC = cim[j].CriticalC;
                                zones[i].HasCritical = true;
                            }
                        }
                    }
                }
            }
            s.Zones = zones;
            s.ThrottleReasons = throttle;

            double max = 0;
            for (int i = 0; i < zones.Count; i++) if (zones[i].TempC > max) max = zones[i].TempC;
            s.MaxZoneTemp = max;

            try { if (_cpuTotal != null) s.CpuPercent = _cpuTotal.NextValue(); } catch { }
            try { if (_perf != null) s.PerfPercent = _perf.NextValue(); } catch { }
            try { if (_freq != null) s.FreqMHz = _freq.NextValue(); } catch { }

            if (_cores != null)
            {
                double[] c = new double[_cores.Length];
                for (int i = 0; i < _cores.Length; i++)
                {
                    try { c[i] = _cores[i].NextValue(); } catch { c[i] = 0; }
                }
                s.Cores = c;
            }

            try
            {
                MEMORYSTATUSEX ms = new MEMORYSTATUSEX();
                if (Native.GlobalMemoryStatusEx(ms))
                {
                    s.MemTotalMB = ms.ullTotalPhys / 1048576.0;
                    s.MemAvailMB = ms.ullAvailPhys / 1048576.0;
                    double used = s.MemTotalMB - s.MemAvailMB;
                    s.MemUsedPercent = s.MemTotalMB > 0 ? (used / s.MemTotalMB) * 100.0 : 0;
                }
            }
            catch { }

            try
            {
                if (_fanSearch != null)
                {
                    int n = 0;
                    ManagementObjectCollection col = _fanSearch.Get();
                    foreach (ManagementBaseObject mo in col) { n++; mo.Dispose(); }
                    s.FanCount = n;
                }
            }
            catch { }

            return s;
        }
    }

    // ------------------------------------------------------------------- power

    public static class Power
    {
        public const int MODE_BALANCED = 0;
        public const int MODE_PERFORMANCE = 1;
        public const int MODE_EFFICIENCY = 2;

        public const int COOLING_PASSIVE = 0;
        public const int COOLING_ACTIVE = 1;

        static readonly Guid SUB_PROCESSOR = new Guid("54533251-82be-4824-96c1-47b60b740d00");
        static readonly Guid PERFBOOSTMODE = new Guid("be337238-0d82-4146-a960-4f3749d470c7");
        static readonly Guid SYSCOOLPOL = new Guid("94d3a615-a899-4ac5-ae2b-e4d8f634367f");
        static readonly Guid THROTTLEMAX = new Guid("bc5038f7-23e0-4960-96da-33abaf5935ec");
        static readonly Guid THROTTLEMIN = new Guid("893dee8e-2bef-41e0-89c6-b55d0929964c");

        public static readonly Guid OVERLAY_BALANCED = new Guid("00000000-0000-0000-0000-000000000000");
        public static readonly Guid OVERLAY_PERFORMANCE = new Guid("ded574b5-45a0-4f42-8737-46345c09c238");
        public static readonly Guid OVERLAY_EFFICIENCY = new Guid("961cc777-2547-4f9d-8174-7d86181b8a7a");

        public static string ModeName(int m)
        {
            if (m == MODE_PERFORMANCE) return "最佳性能";
            if (m == MODE_EFFICIENCY) return "最佳能效";
            return "平衡";
        }

        public static Guid ActiveScheme()
        {
            IntPtr p = IntPtr.Zero;
            try
            {
                uint rc = Native.PowerGetActiveScheme(IntPtr.Zero, out p);
                if (rc != 0 || p == IntPtr.Zero) return Guid.Empty;
                Guid g = (Guid)Marshal.PtrToStructure(p, typeof(Guid));
                return g;
            }
            catch { return Guid.Empty; }
            finally { if (p != IntPtr.Zero) Native.LocalFree(p); }
        }

        public static int EffectiveMode()
        {
            try
            {
                Guid g;
                uint rc = Native.PowerGetEffectiveOverlayScheme(out g);
                if (rc != 0) return -1;
                if (g == OVERLAY_PERFORMANCE) return MODE_PERFORMANCE;
                if (g == OVERLAY_EFFICIENCY) return MODE_EFFICIENCY;
                return MODE_BALANCED;
            }
            catch { return -1; }
        }

        static int ReadIndex(Guid scheme, Guid setting, int def)
        {
            if (scheme == Guid.Empty) return def;
            string path = string.Format(CultureInfo.InvariantCulture,
                "SYSTEM\\CurrentControlSet\\Control\\Power\\User\\PowerSchemes\\{0}\\{1}\\{2}",
                scheme.ToString("D"), SUB_PROCESSOR.ToString("D"), setting.ToString("D"));
            try
            {
                using (RegistryKey k = Registry.LocalMachine.OpenSubKey(path))
                {
                    if (k == null) return def;
                    object o = k.GetValue("ACSettingIndex");
                    if (o == null) return def;
                    return Convert.ToInt32(o, CultureInfo.InvariantCulture);
                }
            }
            catch { return def; }
        }

        public static PowerState Read()
        {
            PowerState st = new PowerState();
            Guid scheme = ActiveScheme();
            int boost = ReadIndex(scheme, PERFBOOSTMODE, -1);
            st.TurboEnabled = (boost != 0);
            st.Mode = EffectiveMode();
            if (st.Mode < 0) st.Mode = MODE_BALANCED;
            st.CoolingPolicy = ReadIndex(scheme, SYSCOOLPOL, COOLING_ACTIVE);
            st.MaxState = ReadIndex(scheme, THROTTLEMAX, 100);
            st.MinState = ReadIndex(scheme, THROTTLEMIN, 5);
            return st;
        }

        public static string RunPowerCfg(string args)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo("powercfg.exe", args);
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;
                using (Process p = Process.Start(psi))
                {
                    string so = p.StandardOutput.ReadToEnd();
                    string se = p.StandardError.ReadToEnd();
                    if (!p.WaitForExit(20000))
                    {
                        try { p.Kill(); } catch { }
                        return "TIMEOUT";
                    }
                    if (p.ExitCode != 0)
                    {
                        string msg = (so + " " + se).Trim();
                        return "ERR(" + p.ExitCode + ") " + msg;
                    }
                    return "OK";
                }
            }
            catch (Exception ex) { return "EX " + ex.Message; }
        }

        static string SetIndex(Guid setting, int ac, int dc)
        {
            string g = setting.ToString("D");
            string r1 = RunPowerCfg("/setacvalueindex SCHEME_CURRENT SUB_PROCESSOR " + g + " " + ac.ToString(CultureInfo.InvariantCulture));
            string r2 = RunPowerCfg("/setdcvalueindex SCHEME_CURRENT SUB_PROCESSOR " + g + " " + dc.ToString(CultureInfo.InvariantCulture));
            string r3 = RunPowerCfg("/setactive SCHEME_CURRENT");
            if (r1 != "OK") return "AC:" + r1;
            if (r2 != "OK") return "DC:" + r2;
            if (r3 != "OK") return "ACT:" + r3;
            return "OK";
        }

        public static string SetTurbo(bool on)
        {
            return SetIndex(PERFBOOSTMODE, on ? 2 : 0, on ? 2 : 0);
        }

        public static string SetCooling(int policy)
        {
            return SetIndex(SYSCOOLPOL, policy, policy);
        }

        public static string SetMaxState(int percent)
        {
            if (percent < 5) percent = 5;
            if (percent > 100) percent = 100;
            return SetIndex(THROTTLEMAX, percent, percent);
        }

        public static string SetMinState(int percent)
        {
            if (percent < 0) percent = 0;
            if (percent > 100) percent = 100;
            return SetIndex(THROTTLEMIN, percent, percent);
        }

        public static string SetMode(int mode)
        {
            try
            {
                Guid g = OVERLAY_BALANCED;
                if (mode == MODE_PERFORMANCE) g = OVERLAY_PERFORMANCE;
                else if (mode == MODE_EFFICIENCY) g = OVERLAY_EFFICIENCY;
                uint rc = Native.PowerSetActiveOverlayScheme(ref g);
                if (rc == 0) return "OK";
                return "ERR(" + rc + ")";
            }
            catch (Exception ex) { return "EX " + ex.Message; }
        }

        // Applies several processor settings with ONE /setactive at the end.
        // powercfg spawns a process per invocation, so batching directly cuts the
        // UI stall when the thermal guard switches profiles.
        public static string ApplyBatch(List<KeyValuePair<Guid, int>> values, int mode)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < values.Count; i++)
            {
                string g = values[i].Key.ToString("D");
                string v = values[i].Value.ToString(CultureInfo.InvariantCulture);
                string r1 = RunPowerCfg("/setacvalueindex SCHEME_CURRENT SUB_PROCESSOR " + g + " " + v);
                string r2 = RunPowerCfg("/setdcvalueindex SCHEME_CURRENT SUB_PROCESSOR " + g + " " + v);
                if (r1 != "OK") sb.AppendLine("AC " + g + " -> " + r1);
                if (r2 != "OK") sb.AppendLine("DC " + g + " -> " + r2);
            }
            if (mode >= 0)
            {
                string rm = SetMode(mode);
                if (rm != "OK") sb.AppendLine("MODE -> " + rm);
            }
            string r3 = RunPowerCfg("/setactive SCHEME_CURRENT");
            if (r3 != "OK") sb.AppendLine("SETACTIVE -> " + r3);
            return sb.Length == 0 ? "OK" : sb.ToString().Trim();
        }

        // Snapshot -> powercfg values, used to undo the thermal guard.
        public static string RestoreState(PowerState st)
        {
            if (st == null) return "no saved state";
            List<KeyValuePair<Guid, int>> vals = new List<KeyValuePair<Guid, int>>();
            vals.Add(new KeyValuePair<Guid, int>(PERFBOOSTMODE, st.TurboEnabled ? 2 : 0));
            vals.Add(new KeyValuePair<Guid, int>(SYSCOOLPOL, st.CoolingPolicy));
            vals.Add(new KeyValuePair<Guid, int>(THROTTLEMAX, st.MaxState));
            vals.Add(new KeyValuePair<Guid, int>(THROTTLEMIN, st.MinState));
            return ApplyBatch(vals, st.Mode);
        }

        // The protective profile: less heat, but the fans stay in active cooling
        // so the EC still ramps them rather than the OS throttling silently.
        public static string ApplyLimits(ThermalGuardConfig cfg)
        {
            List<KeyValuePair<Guid, int>> vals = new List<KeyValuePair<Guid, int>>();
            vals.Add(new KeyValuePair<Guid, int>(PERFBOOSTMODE, cfg.LimitTurboOff ? 0 : 2));
            vals.Add(new KeyValuePair<Guid, int>(SYSCOOLPOL, cfg.LimitCooling));
            vals.Add(new KeyValuePair<Guid, int>(THROTTLEMAX, cfg.LimitMaxState));
            vals.Add(new KeyValuePair<Guid, int>(THROTTLEMIN, 5));
            return ApplyBatch(vals, cfg.LimitMode);
        }

        public class Preset
        {
            public string Key = "";
            public string Name = "";
            public string Desc = "";
            public bool Turbo = true;
            public int Mode = MODE_BALANCED;
            public int Cooling = COOLING_ACTIVE;
            public int MaxState = 100;
            public int MinState = 5;
        }

        public static List<Preset> Presets()
        {
            List<Preset> l = new List<Preset>();
            Preset p1 = new Preset();
            p1.Key = "performance"; p1.Name = "性能模式";
            p1.Desc = "睿频激进 + 最佳性能 + 主动散热，处理器锁定高频。最凉快散热但最吵、最耗电。";
            p1.Turbo = true; p1.Mode = MODE_PERFORMANCE; p1.Cooling = COOLING_ACTIVE;
            p1.MaxState = 100; p1.MinState = 100;
            l.Add(p1);

            Preset p2 = new Preset();
            p2.Key = "balanced"; p2.Name = "均衡模式";
            p2.Desc = "睿频开启 + 平衡 + 主动散热。日常默认，性能与噪音兼顾。";
            p2.Turbo = true; p2.Mode = MODE_BALANCED; p2.Cooling = COOLING_ACTIVE;
            p2.MaxState = 100; p2.MinState = 5;
            l.Add(p2);

            Preset p3 = new Preset();
            p3.Key = "quiet"; p3.Name = "静音模式";
            p3.Desc = "关闭睿频 + 最佳能效 + 被动散热 + 限制 70% 上限。大幅降低发热，让风扇停转或低速。";
            p3.Turbo = false; p3.Mode = MODE_EFFICIENCY; p3.Cooling = COOLING_PASSIVE;
            p3.MaxState = 70; p3.MinState = 5;
            l.Add(p3);
            return l;
        }

        public static Preset FindPreset(string key)
        {
            List<Preset> l = Presets();
            for (int i = 0; i < l.Count; i++)
            {
                if (string.Equals(l[i].Key, key, StringComparison.OrdinalIgnoreCase)) return l[i];
            }
            return null;
        }

        // Apply a preset. Returns a multi-line report.
        public static string ApplyPreset(Preset p)
        {
            StringBuilder sb = new StringBuilder();
            if (!Elevation.IsElevated())
            {
                // The overlay switch works without elevation; the rest does not.
                sb.AppendLine("MODE  : " + SetMode(p.Mode) + " (无需管理员)");
                sb.AppendLine("WARN  : 当前未以管理员身份运行，以下的电源参数修改会失败。");
                sb.AppendLine("TURBO : " + SetTurbo(p.Turbo));
                sb.AppendLine("COOL  : " + SetCooling(p.Cooling));
                sb.AppendLine("MAX   : " + SetMaxState(p.MaxState));
                sb.AppendLine("MIN   : " + SetMinState(p.MinState));
                return sb.ToString();
            }
            sb.AppendLine("TURBO : " + SetTurbo(p.Turbo) + "  (睿频 = " + (p.Turbo ? "开启" : "关闭") + ")");
            sb.AppendLine("MODE  : " + SetMode(p.Mode) + "  (电源模式 = " + ModeName(p.Mode) + ")");
            sb.AppendLine("COOL  : " + SetCooling(p.Cooling) + "  (散热策略 = " + (p.Cooling == COOLING_ACTIVE ? "主动" : "被动") + ")");
            sb.AppendLine("MAX   : " + SetMaxState(p.MaxState) + "  (最大处理器状态 = " + p.MaxState + "%)");
            sb.AppendLine("MIN   : " + SetMinState(p.MinState) + "  (最小处理器状态 = " + p.MinState + "%)");
            return sb.ToString();
        }
    }

    // --------------------------------------------------------------- autostart

    public static class AutoStart
    {
        public const string TaskName = "SysConsoleAutostart";

        public static string Run(string args)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo("schtasks.exe", args);
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;
                using (Process p = Process.Start(psi))
                {
                    string so = p.StandardOutput.ReadToEnd();
                    string se = p.StandardError.ReadToEnd();
                    if (!p.WaitForExit(20000))
                    {
                        try { p.Kill(); } catch { }
                        return "TIMEOUT";
                    }
                    if (p.ExitCode != 0) return "ERR(" + p.ExitCode + ") " + (so + " " + se).Trim();
                    return "OK";
                }
            }
            catch (Exception ex) { return "EX " + ex.Message; }
        }

        public static bool IsEnabled()
        {
            string r = Run("/Query /TN \"" + TaskName + "\"");
            return r == "OK";
        }

        static string XmlEscape(string s)
        {
            if (s == null) return "";
            return s.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("\"", "&quot;");
        }

        // Created from a task XML instead of schtasks switches so that the
        // battery conditions and the execution time limit can be controlled.
        // The defaults schtasks applies ("stop on battery", "stop after 72h")
        // would kill a tray monitor as soon as the laptop is unplugged.
        public static string Enable(string exePath)
        {
            string user = "";
            try { user = System.Security.Principal.WindowsIdentity.GetCurrent().Name; }
            catch { }
            string dir = "";
            try { dir = Path.GetDirectoryName(exePath); }
            catch { }

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-16\"?>");
            sb.AppendLine("<Task version=\"1.2\" xmlns=\"http://schemas.microsoft.com/windows/2004/02/mit/task\">");
            sb.AppendLine("  <RegistrationInfo>");
            sb.AppendLine("    <Description>SysConsole system console autostart</Description>");
            sb.AppendLine("  </RegistrationInfo>");
            sb.AppendLine("  <Triggers>");
            sb.AppendLine("    <LogonTrigger>");
            sb.AppendLine("      <Enabled>true</Enabled>");
            sb.AppendLine("      <UserId>" + XmlEscape(user) + "</UserId>");
            sb.AppendLine("    </LogonTrigger>");
            sb.AppendLine("  </Triggers>");
            sb.AppendLine("  <Principals>");
            sb.AppendLine("    <Principal id=\"Author\">");
            sb.AppendLine("      <UserId>" + XmlEscape(user) + "</UserId>");
            sb.AppendLine("      <LogonType>InteractiveToken</LogonType>");
            sb.AppendLine("      <RunLevel>HighestAvailable</RunLevel>");
            sb.AppendLine("    </Principal>");
            sb.AppendLine("  </Principals>");
            sb.AppendLine("  <Settings>");
            sb.AppendLine("    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>");
            sb.AppendLine("    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>");
            sb.AppendLine("    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>");
            sb.AppendLine("    <AllowHardTerminate>true</AllowHardTerminate>");
            sb.AppendLine("    <StartWhenAvailable>true</StartWhenAvailable>");
            sb.AppendLine("    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>");
            sb.AppendLine("    <AllowStartOnDemand>true</AllowStartOnDemand>");
            sb.AppendLine("    <Enabled>true</Enabled>");
            sb.AppendLine("    <Hidden>false</Hidden>");
            sb.AppendLine("    <RunOnlyIfIdle>false</RunOnlyIfIdle>");
            sb.AppendLine("    <WakeToRun>false</WakeToRun>");
            sb.AppendLine("    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>");
            sb.AppendLine("    <Priority>7</Priority>");
            sb.AppendLine("  </Settings>");
            sb.AppendLine("  <Actions Context=\"Author\">");
            sb.AppendLine("    <Exec>");
            sb.AppendLine("      <Command>" + XmlEscape(exePath) + "</Command>");
            sb.AppendLine("      <Arguments>--tray</Arguments>");
            sb.AppendLine("      <WorkingDirectory>" + XmlEscape(dir) + "</WorkingDirectory>");
            sb.AppendLine("    </Exec>");
            sb.AppendLine("  </Actions>");
            sb.AppendLine("</Task>");

            string tmp = Path.Combine(Path.GetTempPath(), "sysconsole-task.xml");
            try { File.WriteAllText(tmp, sb.ToString(), new UnicodeEncoding(false, true)); }
            catch (Exception ex) { return "EX " + ex.Message; }

            string r = Run("/Create /TN \"" + TaskName + "\" /XML \"" + tmp + "\" /F");
            try { File.Delete(tmp); } catch { }
            return r;
        }

        public static string Disable()
        {
            return Run("/Delete /TN \"" + TaskName + "\" /F");
        }
    }

    // ----------------------------------------------------------- thermal guard

    // Automatic overheat protection. Fan speed itself cannot be commanded on this
    // machine (the EC owns it and exposes no channel), but HEAT GENERATION can be
    // controlled - which is the only software lever that actually lowers
    // temperature. So: above the trigger, cap the processor and drop turbo.
    public class ThermalGuardConfig
    {
        public bool Enabled = false;
        public double TriggerC = 88.0;
        public double ReleaseC = 78.0;
        public int LimitMaxState = 60;
        public bool LimitTurboOff = true;
        public int LimitCooling = Power.COOLING_ACTIVE;   // keep fans working while capped
        public int LimitMode = Power.MODE_EFFICIENCY;

        public ThermalGuardConfig Clone()
        {
            ThermalGuardConfig c = new ThermalGuardConfig();
            c.Enabled = Enabled; c.TriggerC = TriggerC; c.ReleaseC = ReleaseC;
            c.LimitMaxState = LimitMaxState; c.LimitTurboOff = LimitTurboOff;
            c.LimitCooling = LimitCooling; c.LimitMode = LimitMode;
            return c;
        }
    }

    public static class GuardStore
    {
        public static string FilePath()
        {
            return Path.Combine(Log.Dir(), "guard.txt");
        }

        public static void Save(ThermalGuardConfig c)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("# SysConsole 超温保护配置");
                sb.AppendLine("enabled=" + (c.Enabled ? "1" : "0"));
                sb.AppendLine("trigger=" + c.TriggerC.ToString("0.#", CultureInfo.InvariantCulture));
                sb.AppendLine("release=" + c.ReleaseC.ToString("0.#", CultureInfo.InvariantCulture));
                sb.AppendLine("limit_max_state=" + c.LimitMaxState.ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("limit_turbo_off=" + (c.LimitTurboOff ? "1" : "0"));
                File.WriteAllText(FilePath(), sb.ToString(), Encoding.UTF8);
            }
            catch (Exception ex) { Log.Write("GuardStore.Save failed: " + ex.Message); }
        }

        public static ThermalGuardConfig Load()
        {
            ThermalGuardConfig c = new ThermalGuardConfig();
            try
            {
                if (!File.Exists(FilePath())) return c;
                string[] lines = File.ReadAllLines(FilePath(), Encoding.UTF8);
                for (int i = 0; i < lines.Length; i++)
                {
                    string line = lines[i].Trim();
                    if (line.Length == 0 || line.StartsWith("#")) continue;
                    int eq = line.IndexOf('=');
                    if (eq <= 0) continue;
                    string k = line.Substring(0, eq).Trim().ToLowerInvariant();
                    string v = line.Substring(eq + 1).Trim();
                    double d; int n;
                    if (k == "enabled") c.Enabled = (v == "1" || v.ToLowerInvariant() == "true");
                    else if (k == "trigger" && double.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out d)) c.TriggerC = d;
                    else if (k == "release" && double.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out d)) c.ReleaseC = d;
                    else if (k == "limit_max_state" && int.TryParse(v, out n)) c.LimitMaxState = n;
                    else if (k == "limit_turbo_off") c.LimitTurboOff = (v == "1" || v.ToLowerInvariant() == "true");
                }
            }
            catch (Exception ex) { Log.Write("GuardStore.Load failed: " + ex.Message); }
            return c;
        }
    }

    // ------------------------------------------------------------------ 温度墙
    //
    // 温度墙与超温保护的定位不同，两者可以叠加：
    //
    //   超温保护（ThermalGuardConfig）= 二元兜底
    //       越过触发温度才一次性限功耗，回落到解除温度才恢复。简单，但会在
    //       触发点附近来回震荡，而且只在"已经太热"之后才动作。
    //
    //   温度墙（ThermalWallConfig）  = 闭环连续控制
    //       把"最高温度"当作目标值，按偏差逐步加减处理器上限，使温度收敛在
    //       目标附近而不是撞上去再退回来。越接近目标越早开始收力。
    //
    // 控制律（每 tick = 1 秒；只有数值真的变化时才调用 powercfg，避免频繁启动进程）：
    //   T >  目标          → 上限下调 step × (1 + 超出/5)，不低于 floor
    //   T <= 目标 - 回差   → 上限上调 step，不高于用户在滑块上设定的值
    //   回差带内           → 保持不动（避免抖动）
    //   T >  目标 + 5      → 额外关闭睿频（可关）；回到回差内恢复
    //
    // 可选"接近目标时自动开强冷"：进入 目标 - 联动余量 时打开 EC 强冷
    // （0x751 置 0x40 位），降回 目标 - 回差 - 2 以下时关闭。只关闭"由温度墙
    // 自己开启的那一次"，不会覆盖用户手动切换的强冷状态。
    //
    // 安全：整个机制只做"降低功耗"这一件事，任何时刻都不会提高处理器的发热。
    public class ThermalWallConfig
    {
        public bool Enabled = false;
        public double TargetC = 85.0;        // 温度墙目标
        public double HysteresisC = 3.0;     // 回差，防止在目标附近抖动
        public int FloorState = 30;          // 处理器上限的下限，防止把机器压死
        public int StepPercent = 5;          // 每次调整的幅度
        public bool DropTurbo = true;        // 明显超温时关闭睿频
        public bool LinkFanBoost = false;    // 接近目标时自动开强冷
        public double LinkMarginC = 5.0;     // 距目标多少度开始联动强冷
        // 温度墙开始压制前用户设定的处理器上限。持久化它的原因：如果程序正好
        // 在压制期间被重启，实时读到的就是被压低的那个值；没有这个记录就会
        // 把它误当成用户基线，形成"每重启一次就永久降一档"的棘轮效应。
        public int BaseState = 0;            // 0 = 无记录

        public ThermalWallConfig Clone()
        {
            ThermalWallConfig c = new ThermalWallConfig();
            c.Enabled = Enabled; c.TargetC = TargetC; c.HysteresisC = HysteresisC;
            c.FloorState = FloorState; c.StepPercent = StepPercent;
            c.DropTurbo = DropTurbo; c.LinkFanBoost = LinkFanBoost; c.LinkMarginC = LinkMarginC;
            c.BaseState = BaseState;
            return c;
        }
    }

    public static class WallStore
    {
        public static string FilePath()
        {
            return Path.Combine(Log.Dir(), "wall.txt");
        }

        public static void Save(ThermalWallConfig c)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("# SysConsole 温度墙配置");
                sb.AppendLine("enabled=" + (c.Enabled ? "1" : "0"));
                sb.AppendLine("target=" + c.TargetC.ToString("0.#", CultureInfo.InvariantCulture));
                sb.AppendLine("hysteresis=" + c.HysteresisC.ToString("0.#", CultureInfo.InvariantCulture));
                sb.AppendLine("floor_state=" + c.FloorState.ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("step=" + c.StepPercent.ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("drop_turbo=" + (c.DropTurbo ? "1" : "0"));
                sb.AppendLine("link_fan_boost=" + (c.LinkFanBoost ? "1" : "0"));
                sb.AppendLine("link_margin=" + c.LinkMarginC.ToString("0.#", CultureInfo.InvariantCulture));
                sb.AppendLine("base_state=" + c.BaseState.ToString(CultureInfo.InvariantCulture));
                File.WriteAllText(FilePath(), sb.ToString(), Encoding.UTF8);
            }
            catch (Exception ex) { Log.Write("WallStore.Save failed: " + ex.Message); }
        }

        public static ThermalWallConfig Load()
        {
            ThermalWallConfig c = new ThermalWallConfig();
            try
            {
                if (!File.Exists(FilePath())) return c;
                string[] lines = File.ReadAllLines(FilePath(), Encoding.UTF8);
                for (int i = 0; i < lines.Length; i++)
                {
                    string line = lines[i].Trim();
                    if (line.Length == 0 || line.StartsWith("#")) continue;
                    int eq = line.IndexOf('=');
                    if (eq <= 0) continue;
                    string k = line.Substring(0, eq).Trim().ToLowerInvariant();
                    string v = line.Substring(eq + 1).Trim();
                    double d; int n;
                    if (k == "enabled") c.Enabled = (v == "1" || v.ToLowerInvariant() == "true");
                    else if (k == "target" && double.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out d)) c.TargetC = d;
                    else if (k == "hysteresis" && double.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out d)) c.HysteresisC = d;
                    else if (k == "floor_state" && int.TryParse(v, out n)) c.FloorState = n;
                    else if (k == "step" && int.TryParse(v, out n)) c.StepPercent = n;
                    else if (k == "drop_turbo") c.DropTurbo = (v == "1" || v.ToLowerInvariant() == "true");
                    else if (k == "link_fan_boost") c.LinkFanBoost = (v == "1" || v.ToLowerInvariant() == "true");
                    else if (k == "link_margin" && double.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out d)) c.LinkMarginC = d;
                    else if (k == "base_state" && int.TryParse(v, out n)) c.BaseState = n;
                }
            }
            catch (Exception ex) { Log.Write("WallStore.Load failed: " + ex.Message); }
            if (c.TargetC < 50) c.TargetC = 50;
            if (c.TargetC > 100) c.TargetC = 100;
            if (c.FloorState < 5) c.FloorState = 5;
            if (c.FloorState > 100) c.FloorState = 100;
            if (c.StepPercent < 1) c.StepPercent = 1;
            if (c.StepPercent > 25) c.StepPercent = 25;
            return c;
        }
    }

    // ------------------------------------------------------------------ logger

    public static class Log
    {
        public static string Dir()
        {
            string d = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "SysConsole");
            try { if (!Directory.Exists(d)) Directory.CreateDirectory(d); }
            catch { }
            return d;
        }

        public static string FilePath()
        {
            return Path.Combine(Dir(), "sysconsole.log");
        }

        public static void Write(string msg)
        {
            try
            {
                File.AppendAllText(FilePath(),
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) + "  " + msg + Environment.NewLine,
                    Encoding.UTF8);
            }
            catch { }
        }
    }

    // ------------------------------------------------------------- UI state

    // Remembers the window size between runs. Stored next to the hotkey config
    // so everything user-tweakable lives in one folder.
    public static class UiState
    {
        public static string FilePath()
        {
            return Path.Combine(Log.Dir(), "ui.txt");
        }

        public static void SaveWindow(int clientW, int clientH, bool maximized)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("# SysConsole 窗口状态");
                sb.AppendLine("width=" + clientW.ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("height=" + clientH.ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("maximized=" + (maximized ? "1" : "0"));
                File.WriteAllText(FilePath(), sb.ToString(), Encoding.UTF8);
            }
            catch { }
        }

        // Returns false when nothing usable was stored.
        public static bool LoadWindow(out int clientW, out int clientH, out bool maximized)
        {
            clientW = 0; clientH = 0; maximized = false;
            try
            {
                if (!File.Exists(FilePath())) return false;
                string[] lines = File.ReadAllLines(FilePath(), Encoding.UTF8);
                for (int i = 0; i < lines.Length; i++)
                {
                    string line = lines[i].Trim();
                    if (line.Length == 0 || line.StartsWith("#")) continue;
                    int eq = line.IndexOf('=');
                    if (eq <= 0) continue;
                    string k = line.Substring(0, eq).Trim().ToLowerInvariant();
                    string v = line.Substring(eq + 1).Trim();
                    int n;
                    if (k == "width" && int.TryParse(v, out n)) clientW = n;
                    else if (k == "height" && int.TryParse(v, out n)) clientH = n;
                    else if (k == "maximized") maximized = (v == "1" || v.ToLowerInvariant() == "true");
                }
                return clientW > 0 && clientH > 0;
            }
            catch { return false; }
        }
    }
}
