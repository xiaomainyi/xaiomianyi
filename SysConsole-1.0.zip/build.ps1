# build.ps1 - compile SysConsole with the in-box .NET Framework C# compiler.
# No SDK, no NuGet, no network required.
#
# NOTE: this file must stay pure ASCII. Windows PowerShell 5.1 decodes UTF-8
# script files without a BOM as the system ANSI codepage, which corrupts any
# non-ASCII string literal and breaks parsing.

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$srcDir = Join-Path $root 'src'
$binDir = Join-Path $root 'bin'
$fw = Join-Path $env:SystemRoot 'Microsoft.NET\Framework64\v4.0.30319'
$csc = Join-Path $fw 'csc.exe'

if (-not (Test-Path $csc)) { throw "csc.exe not found: $csc" }
if (-not (Test-Path $binDir)) { New-Item -ItemType Directory -Path $binDir | Out-Null }

$out = Join-Path $binDir 'SysConsole.exe'
$manifest = Join-Path $root 'app.manifest'

$refNames = @(
    'System.dll',
    'System.Core.dll',
    'System.Drawing.dll',
    'System.Windows.Forms.dll',
    'System.Management.dll',
    'System.Xml.dll'
)
$refs = @()
foreach ($n in $refNames) {
    $p = Join-Path $fw $n
    if (-not (Test-Path $p)) { throw "missing assembly: $p" }
    $refs += ('/r:' + $p)
}

$sources = Get-ChildItem $srcDir -Filter *.cs | Sort-Object Name | ForEach-Object { $_.FullName }
if ($sources.Count -eq 0) { throw "no .cs files under src" }

$cscArgs = @(
    '/nologo',
    '/target:winexe',
    '/platform:x64',
    '/optimize+',
    '/warn:4',
    '/codepage:65001',
    ('/win32manifest:' + $manifest),
    ('/out:' + $out)
) + $refs + $sources

Write-Host '=== Building SysConsole ===' -ForegroundColor Cyan
Write-Host ("compiler : " + $csc)
Write-Host ("sources  : " + $sources.Count)
Write-Host ("output   : " + $out)
Write-Host ''

& $csc @cscArgs
$code = $LASTEXITCODE

if ($code -ne 0) {
    Write-Host ''
    Write-Host ("BUILD FAILED, exit code " + $code) -ForegroundColor Red
    exit $code
}

$fi = Get-Item $out
$kb = [math]::Round($fi.Length / 1KB, 1)
Write-Host ''
Write-Host ("BUILD OK: " + $fi.FullName + "  (" + $kb + " KB)") -ForegroundColor Green
