// ============================================================================
//  SysConsole — Program.cs
//  程序入口 + 命令行模式。命令行既给用户手动调参数用，也是这个项目的测试手段
//  （没有单元测试框架，全靠内置的自检命令）。
//
//  主要内容：
//    --selftest      传感器/电源自检
//    --uitest        无界面地建出窗口，校验布局、文字、控件交叠
//    --uitest-live   真的显示窗口跑几秒，用运行时真实数据再校验一遍
//    --fan/--fanboost/--wall/--color/--uiscale/--preset/--set/--autostart
//    --keytest       按键诊断（看 Fn 之类能不能被 Windows 看到）
//
//    · 编译：系统自带 csc.exe（.NET Framework 4.8），无 SDK / 无网络 / 无第三方库
//    · 语法：C# 5，不用 async/await、字符串插值、nameof 等新语法
//    · 编码：UTF-8；.ps1 脚本另需纯 ASCII 或带 BOM，否则 PS 5.1 会按 GBK 解码
//    · 硬件寄存器地址来自原厂文件反汇编 + 本机实测，出处见 docs/ 下的协议文档
// ============================================================================

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace SysConsole
{
    static class Program
    {
        static string CliLogPath()
        {
            return Path.Combine(Log.Dir(), "cli-last.txt");
        }

        static void Emit(string text)
        {
            try { Console.WriteLine(text); } catch { }
            try { File.WriteAllText(CliLogPath(), text, Encoding.UTF8); } catch { }
            Log.Write("CLI: " + text.Replace(Environment.NewLine, " | "));
        }

        [STAThread]
        static void Main(string[] args)
        {
            // --tray also starts with "--" but belongs to the GUI path, so it is
            // resolved before the CLI dispatch. (Getting this wrong makes the
            // autostart task launch, print usage and exit immediately.)
            bool startHidden = false;
            for (int i = 0; i < args.Length; i++)
            {
                if (string.Equals(args[i], "--tray", StringComparison.OrdinalIgnoreCase)) startHidden = true;
            }

            bool isCli = args.Length > 0 && args[0].StartsWith("--") &&
                         !string.Equals(args[0], "--tray", StringComparison.OrdinalIgnoreCase);
            if (isCli)
            {
                Native.AttachConsole(-1);
                RunCli(args);
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Single instance guard: a second tray icon would mean a second
            // polling thread and duplicated balloon notifications. CLI runs are
            // exempt so they can execute while the tray instance is alive.
            bool createdNew = false;
            _single = new Mutex(true, "Local\\SysConsoleSingleInstance", out createdNew);
            if (!createdNew)
            {
                Log.Write("Second GUI instance refused (already running).");
                return;
            }

            Application.Run(new MainForm(startHidden));
            GC.KeepAlive(_single);
        }

        static Mutex _single;

        static void RunCli(string[] args)
        {
            string cmd = args[0].ToLowerInvariant();
            StringBuilder sb = new StringBuilder();

            if (cmd == "--selftest")
            {
                sb.AppendLine("=== SysConsole 自检 ===");
                sb.AppendLine("时间     : " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
                sb.AppendLine("程序     : " + Application.ExecutablePath);
                sb.AppendLine("管理员   : " + Elevation.IsElevated());
                sb.AppendLine();

                Snapshot s1 = Sensors.Read();
                Thread.Sleep(1100);
                Snapshot s2 = Sensors.Read();

                sb.AppendLine("--- 温度（ACPI 热区）---");
                if (s2.Zones.Count == 0) sb.AppendLine("  未读取到温度数据");
                for (int i = 0; i < s2.Zones.Count; i++)
                {
                    ZoneReading z = s2.Zones[i];
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                        "  {0,-8} [{1,-6}] {2,7:0.0} C   临界 {3}",
                        z.Label, z.Key, z.TempC,
                        z.HasCritical ? string.Format(CultureInfo.InvariantCulture, "{0:0.0} C", z.CriticalC) : "未知"));
                }
                sb.AppendLine("  节流原因标志: 0x" + s2.ThrottleReasons.ToString("X", CultureInfo.InvariantCulture) +
                              (s2.ThrottleReasons == 0 ? "  (无节流)" : "  (节流中)"));
                sb.AppendLine();

                sb.AppendLine("--- 处理器 ---");
                sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "  总占用    : {0:0.0} %", s2.CpuPercent));
                sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "  相对基准  : {0:0} %", s2.PerfPercent));
                sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "  报告频率  : {0:0} MHz", s2.FreqMHz));
                sb.AppendLine("  逻辑核心  : " + s2.Cores.Length);
                sb.Append("  逐核占用  : ");
                for (int i = 0; i < s2.Cores.Length; i++)
                {
                    sb.Append(string.Format(CultureInfo.InvariantCulture, "{0:0}", s2.Cores[i]));
                    if (i != s2.Cores.Length - 1) sb.Append(", ");
                }
                sb.AppendLine();
                sb.AppendLine();

                sb.AppendLine("--- 内存 ---");
                sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                    "  已用 {0:0} MB / 共 {1:0} MB  ({2:0.0} %)",
                    s2.MemTotalMB - s2.MemAvailMB, s2.MemTotalMB, s2.MemUsedPercent));
                sb.AppendLine();

                sb.AppendLine("--- 风扇（Windows 层）---");
                sb.AppendLine("  Win32_Fan 设备数 : " + s2.FanCount + "  （ACPI PNP0C0B 不暴露 RPM）");
                sb.AppendLine();
                sb.Append(Ec.Report());

                sb.AppendLine("--- 电源设置 ---");
                PowerState st = Power.Read();
                sb.AppendLine("  睿频加速        : " + (st.TurboEnabled ? "开启" : "关闭"));
                sb.AppendLine("  电源模式        : " + Power.ModeName(st.Mode) + " (" + st.Mode + ")");
                sb.AppendLine("  散热策略        : " + (st.CoolingPolicy == Power.COOLING_ACTIVE ? "主动" : "被动") + " (" + st.CoolingPolicy + ")");
                sb.AppendLine("  最大处理器状态  : " + st.MaxState + " %");
                sb.AppendLine("  最小处理器状态  : " + st.MinState + " %");
                sb.AppendLine();

                sb.AppendLine("--- 开机自启 ---");
                sb.AppendLine("  任务名称 : " + AutoStart.TaskName);
                sb.AppendLine("  状态     : " + (AutoStart.IsEnabled() ? "已启用" : "未启用"));
                sb.AppendLine();

                sb.AppendLine("--- 全局快捷键 ---");
                HotkeyStore.Config hc = HotkeyStore.Load();
                sb.AppendLine("  开关     : " + (hc.Enabled ? "已启用" : "已关闭"));
                for (int i = 0; i < hc.Bindings.Count; i++)
                {
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "  {0,-10} : {1}",
                        hc.Bindings[i].Label, hc.Bindings[i].Text));
                }
                sb.AppendLine("  配置文件 : " + HotkeyStore.StorePath());
                sb.AppendLine();

                sb.AppendLine("--- 温度墙（闭环功耗控制）---");
                ThermalWallConfig wc = WallStore.Load();
                sb.AppendLine("  开关     : " + (wc.Enabled ? "已启用" : "未启用"));
                sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "  目标温度 : {0:0.#} °C  (回差 {1:0.#} °C)",
                    wc.TargetC, wc.HysteresisC));
                sb.AppendLine("  处理器上限范围 : " + wc.FloorState + "% - 用户设定值，每次调整 " + wc.StepPercent + "%");
                sb.AppendLine("  超温关睿频     : " + (wc.DropTurbo ? "开" : "关"));
                sb.AppendLine("  联动强冷       : " + (wc.LinkFanBoost
                    ? "开（距目标 " + wc.LinkMarginC.ToString("0.#", CultureInfo.InvariantCulture) + "°C 时自动开 EC 强冷）"
                    : "关"));
                sb.AppendLine("  配置文件 : " + WallStore.FilePath());
                sb.AppendLine();

                sb.AppendLine("--- 超温保护 ---");
                ThermalGuardConfig gc = GuardStore.Load();
                sb.AppendLine("  开关     : " + (gc.Enabled ? "已启用" : "未启用"));
                sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "  触发温度 : {0:0.#} °C", gc.TriggerC));
                sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "  解除温度 : {0:0.#} °C  (回差 {1:0.#} °C)",
                    gc.ReleaseC, gc.TriggerC - gc.ReleaseC));
                sb.AppendLine("  限功耗至 : " + gc.LimitMaxState + " % 最大处理器状态" +
                              (gc.LimitTurboOff ? "，并关闭睿频" : ""));
                sb.AppendLine("  配置文件 : " + GuardStore.FilePath());
                sb.AppendLine();

                sb.AppendLine("--- 场景定义 ---");
                List<Power.Preset> ps = Power.Presets();
                for (int i = 0; i < ps.Count; i++)
                {
                    Power.Preset p = ps[i];
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                        "  {0,-6} 睿频={1,-3} 模式={2,-8} 散热={3,-4} 最大={4,3}% 最小={5,3}%",
                        p.Key, p.Turbo ? "开" : "关", Power.ModeName(p.Mode),
                        p.Cooling == Power.COOLING_ACTIVE ? "主动" : "被动", p.MaxState, p.MinState));
                }
                sb.AppendLine();
                sb.AppendLine("=== 自检结束 ===");
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--uitest")
            {
                // Structural self-check: builds the form (which creates every
                // control) and walks the tree, without showing anything or
                // starting the polling thread. Used to verify that settings
                // controls really exist rather than just assuming they render.
                _uiCount = 0;
                sb.AppendLine("=== SysConsole UI 结构自检 ===");
                sb.AppendLine("时间: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
                sb.AppendLine();
                MainForm f = new MainForm(true, true);
                IntPtr handle = f.Handle;   // force handle creation so layout is live
                DumpControl(f, 0, sb);
                sb.AppendLine();
                sb.AppendLine("控件总数: " + _uiCount);

                // ---- adaptive layout verification ----
                string[] keys = new string[] {
                    "gbMonitor", "pnlZones", "pnlGraph", "pnlCores", "pnlMem", "lblFan",
                    "lblCpu", "lblMem", "lHint", "lblLightStatus", "lblCoreLegend",
                    "gbControl", "lblPresetDesc", "chkGuard", "lblWallStatus",
                    "chkWall", "numWallTarget", "chkWallTurbo", "chkWallBoost",
                    "sep1", "sep2", "lblSec1", "lblSec2", "lblSec3",
                    "tbMax", "numMax", "tbMin", "numMin",
                    "btnMin0", "btnMin5", "btnMin50", "btnMin100",
                    "btnApply", "btnHotkey", "chkAutoStart",
                    "sep3", "lblSec4", "lblLightStatus", "btnSwatch",
                    "paletteLight", "chkLightRemember", "btnLightDefault"
                };
                Dictionary<string, Rectangle> before = new Dictionary<string, Rectangle>();
                LayoutSnapshot(f, keys, before);

                Size oldSize = f.Size;
                f.Size = new Size(f.Width + 400, f.Height + 220);
                f.PerformLayout();
                Application.DoEvents();
                Dictionary<string, Rectangle> after = new Dictionary<string, Rectangle>();
                LayoutSnapshot(f, keys, after);

                // 窗口能长多少受屏幕可用高度限制（界面放大后本来就没多少余量），
                // 所以期望值取「实际长出来的量」，而不是写死的 400/220。
                int dW = f.Width - oldSize.Width;
                int dH = f.Height - oldSize.Height;

                sb.AppendLine();
                sb.AppendLine("--- 自适应布局验证：窗口放大 " + dW + " x " + dH + " 像素 ---");
                sb.AppendLine("  控件             默认尺寸              放大后尺寸");
                for (int i = 0; i < keys.Length; i++)
                {
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                        "  {0,-14} {1,-21} {2}", keys[i], Show(before, keys[i]), Show(after, keys[i])));
                }

                bool okW = (after["gbMonitor"].Width - before["gbMonitor"].Width) == dW;
                bool okH = (after["pnlGraph"].Height - before["pnlGraph"].Height) == dH;
                bool okSlider = (after["tbMax"].Width - before["tbMax"].Width) == dW;
                bool okRight = (after["btnApply"].Left - before["btnApply"].Left) == dW;
                bool okBottom = (after["gbControl"].Top - before["gbControl"].Top) == dH;

                sb.AppendLine();
                sb.AppendLine("--- 关键判定 ---");
                sb.AppendLine("  宽度自适应 gbMonitor  " + Show(before, "gbMonitor") + " -> " + Show(after, "gbMonitor") + (okW ? "   PASS (+" + dW + ")" : "   FAIL"));
                sb.AppendLine("  高度自适应 pnlGraph   " + Show(before, "pnlGraph") + " -> " + Show(after, "pnlGraph") + (okH ? "   PASS (+" + dH + ")" : "   FAIL"));
                sb.AppendLine("  滑块拉伸 tbMax        " + Show(before, "tbMax") + " -> " + Show(after, "tbMax") + (okSlider ? "   PASS (+" + dW + ")" : "   FAIL"));
                sb.AppendLine("  右侧按钮跟随 btnApply " + Show(before, "btnApply") + " -> " + Show(after, "btnApply") + (okRight ? "   PASS (+" + dW + ")" : "   FAIL"));
                sb.AppendLine("  底部卡片贴底 gbControl " + Show(before, "gbControl") + " -> " + Show(after, "gbControl") + (okBottom ? "   PASS (+" + dH + ")" : "   FAIL"));
                bool okSep = (after["sep1"].Width - before["sep1"].Width) == dW &&
                             (after["sep2"].Width - before["sep2"].Width) == dW;
                sb.AppendLine("  分区线跟随拉伸 sep1/2 " + Show(before, "sep1") + " -> " + Show(after, "sep1") + (okSep ? "   PASS (+" + dW + ")" : "   FAIL"));

                // 最大 / 最小两条滑块必须等宽且同起点，数值框与单位列也必须对齐 ——
                // 否则两行看起来就是"各写各的"。
                bool okTwin =
                    before["tbMax"].Width == before["tbMin"].Width &&
                    after["tbMax"].Width == after["tbMin"].Width &&
                    before["tbMax"].Left == before["tbMin"].Left &&
                    before["numMax"].Left == before["numMin"].Left &&
                    after["numMax"].Left == after["numMin"].Left &&
                    before["numMax"].Width == before["numMin"].Width;
                sb.AppendLine("  最大/最小两行结构对齐 " + Show(before, "tbMax") + " / " + Show(before, "tbMin") +
                              (okTwin ? "   PASS（等宽同列）" : "   FAIL"));

                // 温度曲线图是监控卡片里唯一纵向伸缩的控件。它长高之后绝不能盖住
                // 下方的「处理器 / 逐核 / 内存」—— 下面几行必须跟着一起下移。
                string[] belowGraph = new string[] { "lblCpu", "pnlCores", "lblMem", "pnlMem" };
                int covered = 0;
                for (int i = 0; i < belowGraph.Length; i++)
                {
                    Rectangle gr = after["pnlGraph"];
                    Rectangle rc = after[belowGraph[i]];
                    if (gr.Bottom > rc.Top)
                    {
                        covered++;
                        sb.AppendLine("  !! 曲线图盖住了 " + belowGraph[i] + "：曲线底 " + gr.Bottom + " > 该行顶 " + rc.Top);
                    }
                    bool movedWith = (rc.Top - before[belowGraph[i]].Top) == dH;
                    if (!movedWith)
                    {
                        covered++;
                        sb.AppendLine("  !! " + belowGraph[i] + " 没有跟着卡片下移：" +
                                      before[belowGraph[i]].Top + " -> " + rc.Top);
                    }
                }
                sb.AppendLine("  曲线图不遮挡下方三行 " +
                              (covered == 0 ? "   PASS（间距恒定）" : "   FAIL"));

                // 窗口放大后必须重新量一遍：有些标签的锚定方式会让它在放大后才被截，
                // 只在默认尺寸量是查不出来的。
                sb.AppendLine();
                sb.AppendLine("--- 放大之后重新检查文字 ---");
                int bigProblems = 0;
                CheckTextFit(f, sb, ref bigProblems);
                if (bigProblems == 0)
                    sb.AppendLine("  放大后全部文字仍可完整显示   PASS");
                else
                    sb.AppendLine("  放大后共 " + bigProblems + " 处文字会被截断   FAIL");

                {
                    Control ls = FindByName(f, "lblLightStatus");
                    Label lsl = ls as Label;
                    if (lsl != null)
                    {
                        sb.AppendLine();
                        sb.AppendLine("--- 背光状态标签实测 ---");
                        sb.AppendLine("  rect        : " + lsl.Left + "," + lsl.Top + "  " + lsl.Width + "x" + lsl.Height);
                        sb.AppendLine("  TextAlign   : " + lsl.TextAlign + "   AutoEllipsis=" + lsl.AutoEllipsis);
                        sb.AppendLine("  文本长度    : " + lsl.Text.Length);
                        sb.AppendLine("  需要宽度    : " + TextRenderer.MeasureText(lsl.Text, lsl.Font).Width +
                                      "   可用宽度 " + lsl.ClientSize.Width);
                        sb.AppendLine("  文本        : [" + lsl.Text + "]");
                    }
                    else sb.AppendLine("  lblLightStatus 未找到");
                }

                sb.AppendLine();
                sb.AppendLine("--- 控件交叠检查（放大之后） ---");
                int ovMon = ReportOverlaps(FindByName(f, "gbMonitor"), sb, "系统监控");
                int ovCtl = ReportOverlaps(FindByName(f, "gbControl"), sb, "操作面板");
                if (ovMon + ovCtl == 0)
                    sb.AppendLine("  两张卡片内均无控件交叠   PASS");
                else
                    sb.AppendLine("  共 " + (ovMon + ovCtl) + " 处交叠（监控 " + ovMon + " / 操作 " + ovCtl + "）   FAIL");

                // ---- 防割裂：所有可操作项必须同属「操作面板」，监控项必须同属「系统监控」 ----
                string[] opKeys = new string[] {
                    "chkWall", "numWallTarget", "chkWallTurbo", "chkWallBoost",
                    "chkGuard", "numTrigger", "numRelease", "numLimit", "lblWallStatus",
                    "chkTurbo", "tbMax", "numMax", "tbMin", "numMin", "chkAutoStart",
                    "btnMin0", "btnMin5", "btnMin50", "btnMin100",
                    "btnApply", "btnHotkey", "lblPresetDesc",
                    "btnSwatch", "chkLightRemember", "btnLightDefault", "paletteLight",
                    "cmbScale"
                };
                string[] monKeys = new string[] { "pnlZones", "pnlGraph", "pnlCores", "pnlMem", "lblFan" };
                int strayOp = 0, strayMon = 0;
                for (int i = 0; i < opKeys.Length; i++)
                {
                    Control c = FindByName(f, opKeys[i]);
                    if (c == null || c.Parent == null || c.Parent.Name != "gbControl")
                    { strayOp++; sb.AppendLine("  !! 操作项不在操作面板内: " + opKeys[i]); }
                }
                for (int i = 0; i < monKeys.Length; i++)
                {
                    Control c = FindByName(f, monKeys[i]);
                    if (c == null || c.Parent == null || c.Parent.Name != "gbMonitor")
                    { strayMon++; sb.AppendLine("  !! 监控项不在监控卡片内: " + monKeys[i]); }
                }
                sb.AppendLine();
                sb.AppendLine("--- 防割裂检查：操作项是否集中在同一张卡片 ---");
                sb.AppendLine("  操作面板内 " + (opKeys.Length - strayOp) + "/" + opKeys.Length +
                              "   监控卡片内 " + (monKeys.Length - strayMon) + "/" + monKeys.Length +
                              ((strayOp == 0 && strayMon == 0) ? "   PASS（无割裂）" : "   FAIL"));
                sb.AppendLine("  顶层卡片数: " + CountTopCards(f) + "  (期望 2：系统监控 + 操作面板)");
                bool okCards = CountTopCards(f) == 2;
                if (!okCards) sb.AppendLine("  !! 顶层卡片数不是 2，界面又被拆散了");

                // shrink back and confirm everything returns to the original geometry
                f.Size = oldSize;
                f.PerformLayout();
                Application.DoEvents();
                bool okBack = (f.Width - oldSize.Width) == 0 &&
                              (after.Count == before.Count) &&
                              (Show(f, "gbMonitor") == Show(before, "gbMonitor"));
                sb.AppendLine("  缩回默认尺寸 gbMonitor " + Show(f, "gbMonitor") +
                              (okBack ? "   PASS (完全复原)" : "   FAIL"));

                sb.AppendLine();
                sb.AppendLine("--- 文本完整显示检查（TextRenderer 实测像素） ---");
                int problems = 0;
                CheckTextFit(f, sb, ref problems);
                CheckStatusStrip(f, sb, ref problems);

                sb.AppendLine();
                sb.AppendLine("--- 快捷键设置对话框文本检查 ---");
                HotkeyForm hf = new HotkeyForm(new HotkeyStore.Config());
                IntPtr hh = hf.Handle;
                int hp = 0;
                CheckTextFit(hf, sb, ref hp);
                if (hp == 0) sb.AppendLine("  对话框内全部文字均可完整显示  PASS");
                else sb.AppendLine("  对话框内共 " + hp + " 处文字会被截断");
                problems += hp;
                hf.Dispose();

                sb.AppendLine();
                if (problems == 0) sb.AppendLine("  结果: 全部文字均可完整显示  PASS");
                else sb.AppendLine("  结果: 共 " + problems + " 处文字会被截断  FAIL");

                sb.AppendLine();
                sb.AppendLine("--- 调用 RefreshAutoStartUi() 验证自启开关与真实任务状态的同步 ---");
                try
                {
                    System.Reflection.MethodInfo mi = typeof(MainForm).GetMethod(
                        "RefreshAutoStartUi",
                        System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                    if (mi == null)
                    {
                        sb.AppendLine("  失败: 未找到 RefreshAutoStartUi 方法");
                    }
                    else
                    {
                        mi.Invoke(f, null);
                        sb.AppendLine("  调用成功，无异常");
                        CheckBox cb = FindCheckBox(f, "开机自启动");
                        if (cb == null)
                        {
                            sb.AppendLine("  失败: 未找到「开机自启动」复选框");
                        }
                        else
                        {
                            bool real = AutoStart.IsEnabled();
                            sb.AppendLine("  复选框勾选状态 : " + (cb.Checked ? "已勾选" : "未勾选"));
                            sb.AppendLine("  计划任务实际状态: " + (real ? "已启用" : "未启用"));
                            sb.AppendLine("  两者一致        : " + (cb.Checked == real ? "是 (PASS)" : "否 (FAIL)"));
                        }
                    }
                }
                catch (Exception ex)
                {
                    Exception inner = ex.InnerException != null ? ex.InnerException : ex;
                    sb.AppendLine("  异常: " + inner.Message);
                }
                f.Dispose();
                sb.AppendLine();
                sb.AppendLine("=== UI 自检结束 ===");
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--uitest-live")
            {
                // 真正把窗口显示出来、跑几秒轮询，再用"运行时真实文字"量一遍。
                // 默认尺寸下的自检只能看到控件的初始文字（很多是 "--" 或空串），
                // 量不出运行时才填进去的长文本。
                MainForm lf = new MainForm(false, true);
                lf.StartPosition = FormStartPosition.Manual;
                lf.Location = new Point(0, 0);
                lf.Show();
                for (int i = 0; i < 45; i++) { Application.DoEvents(); System.Threading.Thread.Sleep(100); }
                StringBuilder ls = new StringBuilder();
                ls.AppendLine("=== SysConsole 实时文字检查（含运行时数据）===");
                int lp = 0;
                CheckTextFit(lf, ls, ref lp);
                CheckStatusStrip(lf, ls, ref lp);
                ls.AppendLine();
                ls.AppendLine(lp == 0 ? "结果: 运行时全部文字均可完整显示  PASS"
                                      : "结果: 运行时共 " + lp + " 处文字会被截断  FAIL");

                // 界面缩放的实时重建路径也要验一遍：切到最小档再切回原档，
                // 看窗体是否真的变了、重建之后文字和卡片是否还完整。
                int origPct = UiScaleStore.Load();
                ComboBox cs = FindByName(lf, "cmbScale") as ComboBox;
                if (cs != null && cs.Items.Count > 1)
                {
                    ls.AppendLine();
                    ls.AppendLine("--- 界面缩放实时重建检查 ---");
                    ls.AppendLine("  可选档位    : " + string.Join(" / ", UiScaleStore.Options()));
                    int w0 = lf.Width;
                    cs.SelectedIndex = 0;
                    for (int i = 0; i < 25; i++) { Application.DoEvents(); System.Threading.Thread.Sleep(40); }
                    int p2 = 0;
                    CheckTextFit(lf, ls, ref p2);
                    ls.AppendLine("  切到最小档  : 窗体宽 " + w0 + " -> " + lf.Width +
                                  "   顶层卡片 " + CountTopCards(lf) + "   文字问题 " + p2);

                    ComboBox cs2 = FindByName(lf, "cmbScale") as ComboBox;
                    if (cs2 != null) { cs2.SelectedIndex = cs2.Items.Count - 1; }
                    for (int i = 0; i < 25; i++) { Application.DoEvents(); System.Threading.Thread.Sleep(40); }
                    int p3 = 0;
                    CheckTextFit(lf, ls, ref p3);
                    ls.AppendLine("  切到最大档  : 窗体宽 " + lf.Width +
                                  "   顶层卡片 " + CountTopCards(lf) + "   文字问题 " + p3);

                    ComboBox cs3 = FindByName(lf, "cmbScale") as ComboBox;
                    if (cs3 != null) cs3.SelectedItem = UiScaleStore.Label(origPct);
                    for (int i = 0; i < 25; i++) { Application.DoEvents(); System.Threading.Thread.Sleep(40); }
                    ls.AppendLine("  复原为 " + origPct + "% : 窗体宽 " + lf.Width +
                                  (Math.Abs(lf.Width - w0) <= 2 ? "   PASS" : "   FAIL"));
                }
                else UiScaleStore.Save(origPct);
                Emit(ls.ToString());
                lf.Close();
                return;
            }

            if (cmd == "--uiscale")
            {
                // --uiscale         查看当前设置
                // --uiscale N       设置（80-125，受屏幕可用高度限制）
                if (args.Length > 1)
                {
                    int pct;
                    if (!int.TryParse(args[1].TrimEnd('%'), NumberStyles.Integer,
                                      CultureInfo.InvariantCulture, out pct))
                    { Emit("用法: --uiscale [80-125]"); return; }
                    int c = UiScaleStore.Clamp(pct);
                    UiScaleStore.Save(c);
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                        "界面缩放已设为 {0}%（请求 {1}%，本机屏幕上限 {2}%）", c, pct, UiScaleStore.MaxForScreen()));
                }
                else
                {
                    sb.AppendLine("当前界面缩放 : " + UiScaleStore.Load() + "%");
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                        "可选范围     : {0}% - {1}%（上限由屏幕可用高度决定）",
                        UiScaleStore.Min, UiScaleStore.MaxForScreen()));
                }
                sb.AppendLine("配置文件     : " + UiScaleStore.FilePath());
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--keytest")
            {
                int sec = 30;
                if (args.Length > 1)
                {
                    int n;
                    if (int.TryParse(args[1], out n) && n > 0 && n <= 300) sec = n;
                }
                KeyTest.Run(sec);
                sb.AppendLine("按键诊断完成。");
                sb.AppendLine("结果文件: " + KeyTest.ResultPath());
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--preset")
            {
                string key = args.Length > 1 ? args[1] : "balanced";
                Power.Preset p = Power.FindPreset(key);
                if (p == null)
                {
                    Emit("未知场景: " + key + "  (可用: performance | balanced | quiet)");
                    return;
                }
                sb.AppendLine("应用场景: " + p.Name + " (" + p.Key + ")");
                sb.AppendLine("管理员: " + Elevation.IsElevated());
                sb.AppendLine(Power.ApplyPreset(p));
                sb.AppendLine("--- 应用后回读 ---");
                PowerState st = Power.Read();
                sb.AppendLine("  睿频加速        : " + (st.TurboEnabled ? "开启" : "关闭"));
                sb.AppendLine("  电源模式        : " + Power.ModeName(st.Mode));
                sb.AppendLine("  散热策略        : " + (st.CoolingPolicy == Power.COOLING_ACTIVE ? "主动" : "被动"));
                sb.AppendLine("  最大处理器状态  : " + st.MaxState + " %");
                sb.AppendLine("  最小处理器状态  : " + st.MinState + " %");
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--autostart")
            {
                string what = args.Length > 1 ? args[1].ToLowerInvariant() : "status";
                if (what == "on")
                {
                    string r = AutoStart.Enable(Application.ExecutablePath);
                    sb.AppendLine("启用开机自启: " + r);
                }
                else if (what == "off")
                {
                    string r = AutoStart.Disable();
                    sb.AppendLine("关闭开机自启: " + r);
                }
                sb.AppendLine("当前状态: " + (AutoStart.IsEnabled() ? "已启用" : "未启用"));
                sb.AppendLine("任务名称: " + AutoStart.TaskName);
                sb.AppendLine("程序路径: " + Application.ExecutablePath);
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--set")
            {
                // --set turbo=on|off mode=balanced|performance|efficiency cooling=active|passive max=100 min=5
                sb.AppendLine("管理员: " + Elevation.IsElevated());
                for (int i = 1; i < args.Length; i++)
                {
                    string a = args[i];
                    int eq = a.IndexOf('=');
                    if (eq <= 0) continue;
                    string k = a.Substring(0, eq).ToLowerInvariant();
                    string v = a.Substring(eq + 1).ToLowerInvariant();
                    if (k == "turbo") sb.AppendLine("TURBO : " + Power.SetTurbo(v == "on" || v == "1" || v == "true"));
                    else if (k == "mode")
                    {
                        int m = Power.MODE_BALANCED;
                        if (v == "performance") m = Power.MODE_PERFORMANCE;
                        else if (v == "efficiency") m = Power.MODE_EFFICIENCY;
                        sb.AppendLine("MODE  : " + Power.SetMode(m));
                    }
                    else if (k == "cooling") sb.AppendLine("COOL  : " + Power.SetCooling(v == "active" ? Power.COOLING_ACTIVE : Power.COOLING_PASSIVE));
                    else if (k == "max") { int n; if (int.TryParse(v, out n)) sb.AppendLine("MAX   : " + Power.SetMaxState(n)); }
                    else if (k == "min") { int n; if (int.TryParse(v, out n)) sb.AppendLine("MIN   : " + Power.SetMinState(n)); }
                }
                PowerState st = Power.Read();
                sb.AppendLine("--- 回读 ---");
                sb.AppendLine("  睿频=" + (st.TurboEnabled ? "开" : "关") + "  模式=" + Power.ModeName(st.Mode) +
                              "  散热=" + (st.CoolingPolicy == Power.COOLING_ACTIVE ? "主动" : "被动") +
                              "  最大=" + st.MaxState + "%  最小=" + st.MinState + "%");
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--fan")
            {
                Emit(Ec.Report());
                return;
            }

            if (cmd == "--fanboost")
            {
                // --fanboost on|off|toggle|status|ensure
                string what = args.Length > 1 ? args[1].ToLowerInvariant() : "status";
                sb.AppendLine("管理员: " + Elevation.IsElevated());
                if (what == "on") sb.AppendLine(Ec.FanBoost.Enable());
                else if (what == "off") sb.AppendLine(Ec.FanBoost.Disable());
                else if (what == "toggle") sb.AppendLine(Ec.FanBoost.Toggle());
                else if (what == "ensure") sb.AppendLine(Ec.EnsureDevice());
                else if (what != "status") { Emit("未知参数: " + what + "  (可用: on | off | toggle | status | ensure)"); return; }
                sb.AppendLine();
                sb.AppendLine(Ec.FanBoost.Status());
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--color")
            {
                // --color R G B          按 0..255 RGB 设色（内部按原厂公式换算电平）
                // --color read           读当前/出厂电平
                // --color default        恢复 EC 出厂色
                // --color levels r g b   直接写电平（1..50）
                string a1 = args.Length > 1 ? args[1].ToLowerInvariant() : "read";
                sb.AppendLine("管理员: " + Elevation.IsElevated());
                if (a1 == "read" || args.Length < 4)
                {
                    int lr, lg, lb, dr, dg, db;
                    if (Ec.KbColor.ReadLevels(out lr, out lg, out lb))
                        sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                            "当前电平 : {0}/{1}/{2}   ≈ RGB({3},{4},{5})", lr, lg, lb,
                            Ec.KbColor.RFromLevel(lr), Ec.KbColor.GFromLevel(lg), Ec.KbColor.BFromLevel(lb)));
                    else sb.AppendLine("读取电平失败: " + Ec.LastError);
                    if (Ec.KbColor.ReadDefaults(out dr, out dg, out db))
                        sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                            "出厂电平 : {0}/{1}/{2}", dr, dg, db));
                    sb.AppendLine("触发字节 0x767 = " + Ec.Read(Ec.REG_KB_TRIGGER) +
                                  "    状态 0x768 = " + Ec.Read(Ec.REG_KB_STATUS));
                    Emit(sb.ToString());
                    return;
                }
                if (a1 == "default")
                {
                    int dr, dg, db;
                    if (!Ec.KbColor.ReadDefaults(out dr, out dg, out db)) { Emit("读出厂色失败: " + Ec.LastError); return; }
                    string e = Ec.KbColor.ApplyLevels(dr, dg, db, true);
                    sb.AppendLine(e == null ? "已恢复出厂电平 " + dr + "/" + dg + "/" + db : e);
                    Emit(sb.ToString());
                    return;
                }
                if (a1 == "levels")
                {
                    int rl, gl, bl;
                    if (args.Length < 5 || !int.TryParse(args[2], out rl) ||
                        !int.TryParse(args[3], out gl) || !int.TryParse(args[4], out bl))
                    { Emit("用法: --color levels <r> <g> <b>   (电平 1..50)"); return; }
                    string e = Ec.KbColor.ApplyLevels(rl, gl, bl, true);
                    sb.AppendLine(e == null ? "已写入电平 " + rl + "/" + gl + "/" + bl : e);
                    Emit(sb.ToString());
                    return;
                }
                int r, g, b;
                if (!int.TryParse(a1, out r) || args.Length < 4 ||
                    !int.TryParse(args[2], out g) || !int.TryParse(args[3], out b))
                { Emit("用法: --color <R> <G> <B> (0..255) | read | default | levels r g b"); return; }
                string er2 = Ec.KbColor.ApplyRgb(r, g, b, true);
                sb.AppendLine(er2 == null
                    ? string.Format(CultureInfo.InvariantCulture, "已设置 RGB({0},{1},{2})   {3}",
                                    r, g, b, Ec.KbColor.LevelText(r, g, b))
                    : er2);
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--wall")
            {
                // --wall on|off|target=85|floor=30|step=5|drop_turbo=on|link_boost=on|margin=5
                // 温度墙是闭环控制，实际执行在 GUI 进程里；这里只负责改配置。
                ThermalWallConfig w = WallStore.Load();
                sb.AppendLine("管理员: " + Elevation.IsElevated());
                bool changed = false;
                for (int i = 1; i < args.Length; i++)
                {
                    string a = args[i].ToLowerInvariant();
                    if (a == "on") { w.Enabled = true; changed = true; continue; }
                    if (a == "off") { w.Enabled = false; changed = true; continue; }
                    int eq = a.IndexOf('=');
                    if (eq <= 0) continue;
                    string k = a.Substring(0, eq);
                    string v = a.Substring(eq + 1);
                    double d; int n;
                    if (k == "target") { if (double.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out d)) { w.TargetC = d; changed = true; } }
                    else if (k == "floor") { if (int.TryParse(v, out n)) { w.FloorState = n; changed = true; } }
                    else if (k == "step") { if (int.TryParse(v, out n)) { w.StepPercent = n; changed = true; } }
                    else if (k == "drop_turbo") { w.DropTurbo = (v == "on" || v == "1" || v == "true"); changed = true; }
                    else if (k == "link_boost") { w.LinkFanBoost = (v == "on" || v == "1" || v == "true"); changed = true; }
                    else if (k == "margin") { if (double.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out d)) { w.LinkMarginC = d; changed = true; } }
                }
                if (changed) { WallStore.Save(w); sb.AppendLine("配置已保存（GUI 下次启动时生效）"); }
                sb.AppendLine();
                sb.AppendLine("温度墙   : " + (w.Enabled ? "已启用" : "未启用"));
                sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "目标温度 : {0:0.#} °C   回差 {1:0.#} °C", w.TargetC, w.HysteresisC));
                sb.AppendLine("控制范围 : 处理器上限 " + w.FloorState + "% - 你设定的值，每次调整 " + w.StepPercent + "%");
                sb.AppendLine("超温关睿频: " + (w.DropTurbo ? "开" : "关"));
                sb.AppendLine("联动强冷 : " + (w.LinkFanBoost ? "开（距目标 " + w.LinkMarginC.ToString("0.#") + "°C 时）" : "关"));
                sb.AppendLine("配置文件 : " + WallStore.FilePath());
                Emit(sb.ToString());
                return;
            }

            Emit("SysConsole 用法:\r\n" +
                 "  SysConsole.exe                     启动图形控制台\r\n" +
                 "  SysConsole.exe --tray              启动并最小化到托盘\r\n" +
                 "  SysConsole.exe --selftest          无界面自检，结果写入 cli-last.txt\r\n" +
                 "  SysConsole.exe --preset <key>      应用场景 performance|balanced|quiet\r\n" +
                 "  SysConsole.exe --autostart on|off|status\r\n" +
                 "  SysConsole.exe --set turbo=on mode=balanced cooling=active max=100 min=5\r\n" +
                 "  SysConsole.exe --keytest [秒]      按键诊断，探测 Fn 等功能键是否上报给 Windows\r\n" +
                 "  SysConsole.exe --fan                读取 EC：风扇转速/模式/功耗上限（原生 IOCTL）\r\n" +
                 "  SysConsole.exe --fanboost on|off|status   一键强冷（直写 EC 0x751，不依赖 OEM 软件）\r\n" +
                 "  SysConsole.exe --wall on|off target=85 floor=30 step=5 drop_turbo=on link_boost=on\r\n" +
                 "\r\n日志目录: " + Log.Dir());
        }

        static int _uiCount;

        static void DumpControl(Control c, int depth, System.Text.StringBuilder sb)
        {
            _uiCount++;
            string txt = c.Text;
            if (txt != null && txt.Length > 44) txt = txt.Substring(0, 44) + "...";
            sb.Append(new string(' ', depth * 2));
            sb.Append(c.GetType().Name);
            if (!string.IsNullOrEmpty(txt)) sb.Append("  [").Append(txt).Append("]");
            sb.Append("  @").Append(c.Left).Append(',').Append(c.Top)
              .Append(' ').Append(c.Width).Append('x').Append(c.Height);
            if (!c.Enabled) sb.Append("  (disabled)");
            if (c is CheckBox) sb.Append(((CheckBox)c).Checked ? "  <已勾选>" : "  <未勾选>");
            if (c is Panel || c is GroupBox || c is TrackBar || c is Button || c is CheckBox)
            {
                string a = c.Anchor.ToString();
                sb.Append("  [anchor: ").Append(a).Append(']');
            }
            sb.AppendLine();
            foreach (Control ch in c.Controls) DumpControl(ch, depth + 1, sb);
        }

        static CheckBox FindCheckBox(Control root, string text)
        {
            CheckBox self = root as CheckBox;
            if (self != null && self.Text == text) return self;
            foreach (Control c in root.Controls)
            {
                CheckBox r = FindCheckBox(c, text);
                if (r != null) return r;
            }
            return null;
        }

        static string Shorten(string s)
        {
            if (s == null) return "";
            s = s.Replace("\r", " ").Replace("\n", " ");
            return s.Length <= 46 ? s : s.Substring(0, 46) + "...";
        }

        // Measures every caption against the room the control actually gives it.
        // This is how clipped option text gets found instead of guessed at.
        static void CheckTextFit(Control root, StringBuilder sb, ref int problems)
        {
            string t = root.Text;

            if (!string.IsNullOrEmpty(t))
            {
                bool check = (root is Label) || (root is CheckBox) || (root is Button) || (root is GroupBox);
                if (check)
                {
                    string[] tl = t.Replace("\r\n", "\n").Split('\n');
                    int needW = 0;
                    for (int li = 0; li < tl.Length; li++)
                    {
                        int w = TextRenderer.MeasureText(tl[li], root.Font).Width;
                        if (w > needW) needW = w;
                    }
                    int avail = root.ClientSize.Width;
                    if (root is CheckBox) avail -= 20;      // glyph + gap
                    if (root is GroupBox) avail -= 18;      // frame + leading space
                    if (needW + 3 > avail)
                    {
                        problems++;
                        sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                            "  [{0,-10}] \"{1}\"  需要 {2}px / 可用 {3}px  超出 {4}px",
                            root.GetType().Name, Shorten(tl.Length > 1 ? tl[0] + " …" : t),
                            needW, avail, needW + 3 - avail));
                    }
                    // multi-line captions must also have the height to show every line
                    int needH = tl.Length * (root.Font.Height + 2);
                    if (tl.Length > 1 && needH > root.ClientSize.Height + 2)
                    {
                        problems++;
                        sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                            "  [{0,-10}] \"{1}\"  {2} 行需要高 {3}px / 可用 {4}px",
                            root.GetType().Name, Shorten(tl[0] + " …"), tl.Length, needH, root.ClientSize.Height));
                    }
                }
            }

            // Dropdown items are the usual culprit: the closed box must fit the widest one.
            ComboBox cb = root as ComboBox;
            if (cb != null)
            {
                int avail = cb.ClientSize.Width - 24;   // arrow button
                for (int i = 0; i < cb.Items.Count; i++)
                {
                    string item = Convert.ToString(cb.Items[i]);
                    Size need = TextRenderer.MeasureText(item, cb.Font);
                    if (need.Width + 4 > avail)
                    {
                        problems++;
                        sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                            "  [ComboBox项 ] \"{0}\"  需要 {1}px / 可用 {2}px  超出 {3}px  (控件宽 {4})",
                            Shorten(item), need.Width, avail, need.Width + 4 - avail, cb.ClientSize.Width));
                    }
                }
            }

            // TextBox that displays values must not clip them either.
            TextBox tb = root as TextBox;
            if (tb != null && !string.IsNullOrEmpty(tb.Text) && tb.ReadOnly)
            {
                Size need = TextRenderer.MeasureText(tb.Text, tb.Font);
                int avail = tb.ClientSize.Width - 8;
                if (need.Width + 3 > avail)
                {
                    problems++;
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                        "  [TextBox   ] \"{0}\"  需要 {1}px / 可用 {2}px  超出 {3}px",
                        Shorten(tb.Text), need.Width, avail, need.Width + 3 - avail));
                }
            }

            // A caption can fit its own box yet still be clipped by the parent.
            if (root.Parent != null && !(root is StatusStrip) && root.Visible)
            {
                Control pc = root.Parent;
                int overR = root.Right - pc.ClientSize.Width;
                int overB = root.Bottom - pc.ClientSize.Height;
                if (overR > 0 || overB > 0)
                {
                    problems++;
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                        "  [超出父容器 ] {0} \"{1}\"  右溢出 {2}px / 下溢出 {3}px  (父容器 {4}x{5})",
                        root.GetType().Name, Shorten(t), overR > 0 ? overR : 0, overB > 0 ? overB : 0,
                        pc.ClientSize.Width, pc.ClientSize.Height));
                }
            }

            foreach (Control c in root.Controls) CheckTextFit(c, sb, ref problems);
        }

        static void CheckStatusStrip(Control root, StringBuilder sb, ref int problems)
        {
            StatusStrip ss = null;
            foreach (Control c in root.Controls) { StatusStrip s = c as StatusStrip; if (s != null) { ss = s; break; } }
            if (ss == null) return;

            int total = 0, springW = 0;
            for (int i = 0; i < ss.Items.Count; i++)
            {
                ToolStripItem it = ss.Items[i];
                int w = TextRenderer.MeasureText(it.Text, it.Font).Width + 10;
                ToolStripStatusLabel sl = it as ToolStripStatusLabel;
                if (sl != null && sl.Spring) springW = w; else total += w;
            }
            sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                "  [状态栏     ] 固定项合计 {0}px，弹性项需要 {1}px，状态栏宽 {2}px", total, springW, ss.ClientSize.Width));
            if (total + springW > ss.ClientSize.Width)
            {
                problems++;
                sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                    "  [状态栏     ] 超出 {0}px —— 弹性项(状态文字)会被截断", total + springW - ss.ClientSize.Width));
            }
        }

        static Control FindByName(Control root, string name)
        {
            if (root.Name == name) return root;
            foreach (Control c in root.Controls)
            {
                Control r = FindByName(c, name);
                if (r != null) return r;
            }
            return null;
        }

        static void LayoutSnapshot(Control root, string[] names, Dictionary<string, Rectangle> into)
        {
            for (int i = 0; i < names.Length; i++)
            {
                Control c = FindByName(root, names[i]);
                into[names[i]] = (c == null) ? Rectangle.Empty : c.Bounds;
            }
        }

        static string CtrlName(Control c)
        {
            if (!string.IsNullOrEmpty(c.Name)) return c.Name;
            string t = c.Text == null ? "" : c.Text;
            if (t.Length > 14) t = t.Substring(0, 14) + "…";
            return c.GetType().Name + "[" + t + "]";
        }

        /// <summary>
        /// 同一个容器里的兄弟控件不允许矩形交叠 —— 交叠就意味着 z 序靠上的那个会把
        /// 下面那个盖住（Controls.Add 先加的在前，后加的在后）。高度 ≤1 的是分隔线，
        /// 本来就横跨整行，跳过。
        /// </summary>
        static int ReportOverlaps(Control parent, StringBuilder sb, string label)
        {
            if (parent == null) return 0;
            List<Control> kids = new List<Control>();
            foreach (Control c in parent.Controls) if (c.Visible) kids.Add(c);
            int n = 0;
            for (int i = 0; i < kids.Count; i++)
            {
                for (int j = i + 1; j < kids.Count; j++)
                {
                    Rectangle a = kids[i].Bounds, b = kids[j].Bounds;
                    if (a.Height <= 1 || b.Height <= 1) continue;
                    if (!a.IntersectsWith(b)) continue;
                    n++;
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                        "  !! {0}：{1} {2} 压住 {3} {4}", label, CtrlName(kids[i]), a, CtrlName(kids[j]), b));
                }
            }
            return n;
        }

        // 顶层 GroupBox 数量。界面被拆散时这个数会变大，用它守住"只有两个大卡片"：
        // 系统监控（只读）+ 操作面板（所有可操作项）。
        static int CountTopCards(Control root)
        {
            int n = 0;
            for (int i = 0; i < root.Controls.Count; i++)
            {
                if (root.Controls[i] is GroupBox) n++;
            }
            return n;
        }

        static string Show(Dictionary<string, Rectangle> snap, string name)
        {
            Rectangle r;
            if (!snap.TryGetValue(name, out r) || r == Rectangle.Empty) return "(未找到)";
            return r.Width + "x" + r.Height + " @" + r.Left + "," + r.Top;
        }

        static string Show(Control root, string name)
        {
            Control c = FindByName(root, name);
            if (c == null) return "(未找到)";
            return c.Width + "x" + c.Height + " @" + c.Left + "," + c.Top;
        }
    }
}
