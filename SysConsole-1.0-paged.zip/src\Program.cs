// ============================================================================
//  SysConsole — Program.cs
//  程序入口 + 命令行模式。命令行既给用户手动调参数用，也是这个项目的测试手段
//  （没有单元测试框架，全靠内置的自检命令）。
//
//  主要内容：
//    --selftest      传感器/电源自检
//    --uitest        无界面地建出窗口，校验布局、文字、控件交叠
//    --uitest-live   真的显示窗口跑几秒，用运行时真实数据再校验一遍
//    --fan/--fanboost/--wall/--color/--uiscale/--preset/--set/--autostart
//    --keytest       按键诊断（看 Fn 之类能不能被 Windows 看到）
//
//    · 编译：系统自带 csc.exe（.NET Framework 4.8），无 SDK / 无网络 / 无第三方库
//    · 语法：C# 5，不用 async/await、字符串插值、nameof 等新语法
//    · 编码：UTF-8；.ps1 脚本另需纯 ASCII 或带 BOM，否则 PS 5.1 会按 GBK 解码
//    · 硬件寄存器地址来自原厂文件反汇编 + 本机实测，出处见 docs/ 下的协议文档
// ============================================================================

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace SysConsole
{
    static class Program
    {
        static string CliLogPath()
        {
            return Path.Combine(Log.Dir(), "cli-last.txt");
        }

        static void Emit(string text)
        {
            try { Console.WriteLine(text); } catch { }
            try { File.WriteAllText(CliLogPath(), text, Encoding.UTF8); } catch { }
            Log.Write("CLI: " + text.Replace(Environment.NewLine, " | "));
        }

        [STAThread]
        static void Main(string[] args)
        {
            // --tray also starts with "--" but belongs to the GUI path, so it is
            // resolved before the CLI dispatch. (Getting this wrong makes the
            // autostart task launch, print usage and exit immediately.)
            bool startHidden = false;
            for (int i = 0; i < args.Length; i++)
            {
                if (string.Equals(args[i], "--tray", StringComparison.OrdinalIgnoreCase)) startHidden = true;
            }

            bool isCli = args.Length > 0 && args[0].StartsWith("--") &&
                         !string.Equals(args[0], "--tray", StringComparison.OrdinalIgnoreCase);
            if (isCli)
            {
                Native.AttachConsole(-1);
                RunCli(args);
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Single instance guard: a second tray icon would mean a second
            // polling thread and duplicated balloon notifications. CLI runs are
            // exempt so they can execute while the tray instance is alive.
            bool createdNew = false;
            _single = new Mutex(true, "Local\\SysConsoleSingleInstance", out createdNew);
            if (!createdNew)
            {
                Log.Write("Second GUI instance refused (already running).");
                return;
            }

            Application.Run(new MainForm(startHidden));
            GC.KeepAlive(_single);
        }

        static Mutex _single;

        static void RunCli(string[] args)
        {
            string cmd = args[0].ToLowerInvariant();
            StringBuilder sb = new StringBuilder();

            if (cmd == "--selftest")
            {
                sb.AppendLine("=== SysConsole 自检 ===");
                sb.AppendLine("时间     : " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
                sb.AppendLine("程序     : " + Application.ExecutablePath);
                sb.AppendLine("管理员   : " + Elevation.IsElevated());
                sb.AppendLine();

                Snapshot s1 = Sensors.Read();
                Thread.Sleep(1100);
                Snapshot s2 = Sensors.Read();

                sb.AppendLine("--- 温度（ACPI 热区）---");
                if (s2.Zones.Count == 0) sb.AppendLine("  未读取到温度数据");
                for (int i = 0; i < s2.Zones.Count; i++)
                {
                    ZoneReading z = s2.Zones[i];
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                        "  {0,-8} [{1,-6}] {2,7:0.0} C   临界 {3}",
                        z.Label, z.Key, z.TempC,
                        z.HasCritical ? string.Format(CultureInfo.InvariantCulture, "{0:0.0} C", z.CriticalC) : "未知"));
                }
                sb.AppendLine("  节流原因标志: 0x" + s2.ThrottleReasons.ToString("X", CultureInfo.InvariantCulture) +
                              (s2.ThrottleReasons == 0 ? "  (无节流)" : "  (节流中)"));
                sb.AppendLine();

                sb.AppendLine("--- 处理器 ---");
                sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "  总占用    : {0:0.0} %", s2.CpuPercent));
                sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "  相对基准  : {0:0} %", s2.PerfPercent));
                sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "  报告频率  : {0:0} MHz", s2.FreqMHz));
                sb.AppendLine("  逻辑核心  : " + s2.Cores.Length);
                sb.Append("  逐核占用  : ");
                for (int i = 0; i < s2.Cores.Length; i++)
                {
                    sb.Append(string.Format(CultureInfo.InvariantCulture, "{0:0}", s2.Cores[i]));
                    if (i != s2.Cores.Length - 1) sb.Append(", ");
                }
                sb.AppendLine();
                sb.AppendLine();

                sb.AppendLine("--- 内存 ---");
                sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                    "  已用 {0:0} MB / 共 {1:0} MB  ({2:0.0} %)",
                    s2.MemTotalMB - s2.MemAvailMB, s2.MemTotalMB, s2.MemUsedPercent));
                sb.AppendLine();

                sb.AppendLine("--- 风扇（Windows 层）---");
                sb.AppendLine("  Win32_Fan 设备数 : " + s2.FanCount + "  （ACPI PNP0C0B 不暴露 RPM）");
                sb.AppendLine();
                sb.Append(Ec.Report());

                sb.AppendLine("--- 电源设置 ---");
                PowerState st = Power.Read();
                sb.AppendLine("  睿频加速        : " + (st.TurboEnabled ? "开启" : "关闭"));
                sb.AppendLine("  电源模式        : " + Power.ModeName(st.Mode) + " (" + st.Mode + ")");
                sb.AppendLine("  散热策略        : " + (st.CoolingPolicy == Power.COOLING_ACTIVE ? "主动" : "被动") + " (" + st.CoolingPolicy + ")");
                sb.AppendLine("  最大处理器状态  : " + st.MaxState + " %");
                sb.AppendLine("  最小处理器状态  : " + st.MinState + " %");
                sb.AppendLine();

                sb.AppendLine("--- 开机自启 ---");
                sb.AppendLine("  任务名称 : " + AutoStart.TaskName);
                sb.AppendLine("  状态     : " + (AutoStart.IsEnabled() ? "已启用" : "未启用"));
                sb.AppendLine();

                sb.AppendLine("--- 全局快捷键 ---");
                HotkeyStore.Config hc = HotkeyStore.Load();
                sb.AppendLine("  开关     : " + (hc.Enabled ? "已启用" : "已关闭"));
                for (int i = 0; i < hc.Bindings.Count; i++)
                {
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "  {0,-10} : {1}",
                        hc.Bindings[i].Label, hc.Bindings[i].Text));
                }
                sb.AppendLine("  配置文件 : " + HotkeyStore.StorePath());
                sb.AppendLine();

                sb.AppendLine("--- 温度墙（闭环功耗控制）---");
                ThermalWallConfig wc = WallStore.Load();
                sb.AppendLine("  开关     : " + (wc.Enabled ? "已启用" : "未启用"));
                sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "  目标温度 : {0:0.#} °C  (回差 {1:0.#} °C)",
                    wc.TargetC, wc.HysteresisC));
                sb.AppendLine("  处理器上限范围 : " + wc.FloorState + "% - 用户设定值，每次调整 " + wc.StepPercent + "%");
                sb.AppendLine("  超温关睿频     : " + (wc.DropTurbo ? "开" : "关"));
                sb.AppendLine("  联动强冷       : " + (wc.LinkFanBoost
                    ? "开（距目标 " + wc.LinkMarginC.ToString("0.#", CultureInfo.InvariantCulture) + "°C 时自动开 EC 强冷）"
                    : "关"));
                sb.AppendLine("  配置文件 : " + WallStore.FilePath());
                sb.AppendLine();

                sb.AppendLine("--- 超温保护 ---");
                ThermalGuardConfig gc = GuardStore.Load();
                sb.AppendLine("  开关     : " + (gc.Enabled ? "已启用" : "未启用"));
                sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "  触发温度 : {0:0.#} °C", gc.TriggerC));
                sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "  解除温度 : {0:0.#} °C  (回差 {1:0.#} °C)",
                    gc.ReleaseC, gc.TriggerC - gc.ReleaseC));
                sb.AppendLine("  限功耗至 : " + gc.LimitMaxState + " % 最大处理器状态" +
                              (gc.LimitTurboOff ? "，并关闭睿频" : ""));
                sb.AppendLine("  配置文件 : " + GuardStore.FilePath());
                sb.AppendLine();

                sb.AppendLine("--- 场景定义 ---");
                List<Power.Preset> ps = Power.Presets();
                for (int i = 0; i < ps.Count; i++)
                {
                    Power.Preset p = ps[i];
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                        "  {0,-6} 睿频={1,-3} 模式={2,-8} 散热={3,-4} 最大={4,3}% 最小={5,3}%",
                        p.Key, p.Turbo ? "开" : "关", Power.ModeName(p.Mode),
                        p.Cooling == Power.COOLING_ACTIVE ? "主动" : "被动", p.MaxState, p.MinState));
                }
                sb.AppendLine();
                sb.AppendLine("=== 自检结束 ===");
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--uitest")
            {
                // Structural self-check: builds the form (which creates every
                // control) and walks the tree, without showing anything or
                // starting the polling thread.
                //
                // 分页版：隐藏的页面不参与"是否超出父容器"和"控件交叠"的检查
                // （Control.Visible 会因为父级隐藏而变 false），所以必须逐页切
                // 过去量一遍 —— 这也是这个自检唯一能覆盖全部五页的办法。
                _uiCount = 0;
                sb.AppendLine("=== SysConsole UI 结构自检（分页版） ===");
                sb.AppendLine("时间: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
                sb.AppendLine();

                MainForm f = new MainForm(true, true);
                IntPtr handle = f.Handle;   // force handle creation so layout is live
                DumpControl(f, 0, sb);
                sb.AppendLine();
                sb.AppendLine("控件总数: " + _uiCount);

                string[] pages = new string[] { "page0", "page1", "page2", "page3", "page4", "page5" };
                string[] navs = new string[] { "nav0", "nav1", "nav2", "nav3", "nav4", "nav5" };
                string[] cards = new string[] { "gbMonitor", "gbControl", "gbThermal", "gbLight", "gbSystem", "gbFan" };
                string[] titles = new string[] { "系统概览", "性能与散热", "温度保护", "键盘背光", "系统与设置", "风扇曲线" };

                // ---- 外壳结构 ----
                int shellBad = 0;
                Control body = FindByName(f, "pnlBody");
                if (FindByName(f, "pnlNav") == null) { shellBad++; sb.AppendLine("  !! 缺导航栏 pnlNav"); }
                for (int i = 0; i < pages.Length; i++)
                {
                    if (FindByName(f, "pageMark" + i) == null) { shellBad++; sb.AppendLine("  !! 缺页名水印 pageMark" + i); }
                }
                if (body == null) { shellBad++; sb.AppendLine("  !! 缺页面容器 pnlBody"); }
                for (int i = 0; i < pages.Length; i++)
                {
                    if (FindByName(f, pages[i]) == null) { shellBad++; sb.AppendLine("  !! 缺页面 " + pages[i]); }
                    if (FindByName(f, navs[i]) == null) { shellBad++; sb.AppendLine("  !! 缺导航按钮 " + navs[i]); }
                    if (FindByName(f, cards[i]) == null) { shellBad++; sb.AppendLine("  !! 缺卡片 " + cards[i]); }
                }
                sb.AppendLine();
                sb.AppendLine("--- 分页外壳 ---");
                sb.AppendLine("  页面数 " + PageCount(body) + " / 导航按钮 " + pages.Length);
                sb.AppendLine("  导航 " + Show(f, "pnlNav") + "   页体 " + Show(f, "pnlBody") + "（无标题栏，页名在右下角水印）");
                sb.AppendLine("  外壳结构 " + (shellBad == 0 ? "PASS" : "FAIL"));

                // 每页各自盯住的控件（放大前后对照用）
                string[][] watch = new string[][] {
                    new string[] { "pnlNav", "pnlBody", "pageMark0", "gbMonitor", "pnlGraph", "lblCpu", "pnlCores", "lblMem", "pnlMem" },
                    new string[] { "gbControl", "tbMax", "tbMin", "numMax", "numMin", "btnApply", "sep1", "sep2", "lblPresetDesc" },
                    new string[] { "gbThermal", "sepWall" },
                    new string[] { "gbLight", "paletteLight", "btnLightDefault" },
                    new string[] { "gbSystem", "btnHotkey", "btnElevate", "cmbScale" },
                    new string[] { "gbFan", "pnlFanCurve", "lblFanStatus", "lblFanSafety", "btnFanApply", "sepFan" }
                };

                // ---- 逐页：切换 → 版面 → 文字 → 交叠 ----
                int pageBad = 0, textBad = 0, overlapBad = 0;
                Dictionary<string, Rectangle> before = new Dictionary<string, Rectangle>();
                for (int i = 0; i < pages.Length; i++)
                {
                    CallSwitchPage(f, i);
                    f.PerformLayout();
                    Application.DoEvents();

                    bool onlyThis = true;
                    for (int k = 0; k < pages.Length; k++)
                    {
                        Control pp = FindByName(f, pages[k]);
                        if (pp != null && OwnVisible(pp) != (k == i)) onlyThis = false;
                    }
                    Label lt = FindByName(f, "pageMark" + i) as Label;
                    Control mark = FindByName(f, "pnlNavMark");
                    Control nb = FindByName(f, navs[i]);
                    bool titleOk = (lt != null && lt.Text == titles[i]);
                    bool markOk = (mark != null && nb != null && mark.Top == nb.Top);

                    Control pg = FindByName(f, pages[i]);
                    Control card = FindByName(f, cards[i]);

                    sb.AppendLine();
                    sb.AppendLine("--- 第 " + (i + 1) + " 页：" + titles[i] + " ---");
                    sb.AppendLine("  仅本页可见 " + (onlyThis ? "PASS" : "FAIL") +
                                  "   页名水印 " + (titleOk ? "PASS" : "FAIL") +
                                  "   指示条对齐 " + (markOk ? "PASS" : "FAIL"));
                    if (!onlyThis || !titleOk || !markOk) pageBad++;

                    if (pg != null && card != null)
                        sb.AppendLine("  页体 " + Show(f, pages[i]) + "   卡片 " + Show(f, cards[i]) +
                                      "   卡片右边距 " + (pg.Width - card.Right) +
                                      "   下边距 " + (pg.Height - card.Bottom));

                    int pfit = 0;
                    CheckTextFit(pg, sb, ref pfit);
                    textBad += pfit;

                    int ov = ReportOverlapsDeep(pg, sb, titles[i]);
                    overlapBad += ov;

                    sb.AppendLine("  文字完整 " + (pfit == 0 ? "PASS" : "FAIL(" + pfit + ")") +
                                  "   页内控件交叠 " + (ov == 0 ? "PASS" : "FAIL(" + ov + ")"));

                    LayoutSnapshot(f, watch[i], before);
                }

                // ---- 自适应：窗口放大 400 x 220，再逐页量一遍 ----
                Size oldSize = f.Size;
                f.Size = new Size(f.Width + 400, f.Height + 220);
                f.PerformLayout();
                Application.DoEvents();
                Dictionary<string, Rectangle> after = new Dictionary<string, Rectangle>();
                for (int i = 0; i < pages.Length; i++)
                {
                    CallSwitchPage(f, i);
                    f.PerformLayout();
                    Application.DoEvents();
                    LayoutSnapshot(f, watch[i], after);
                }
                int dW = f.Width - oldSize.Width;
                int dH = f.Height - oldSize.Height;

                sb.AppendLine();
                sb.AppendLine("--- 自适应布局验证：窗口放大 " + dW + " x " + dH + " 像素 ---");
                for (int i = 0; i < pages.Length; i++)
                {
                    sb.AppendLine("  [第 " + (i + 1) + " 页]");
                    for (int k = 0; k < watch[i].Length; k++)
                        sb.AppendLine("  " + watch[i][k].PadRight(14) + Show(before, watch[i][k]) + "  ->  " + Show(after, watch[i][k]));
                }

                string[] belowGraph = new string[] { "lblCpu", "pnlCores", "lblMem", "pnlMem" };
                int covered = 0;
                for (int i = 0; i < belowGraph.Length; i++)
                {
                    if (after["pnlGraph"].Bottom > after[belowGraph[i]].Top)
                    {
                        covered++;
                        sb.AppendLine("  !! 曲线图盖住了 " + belowGraph[i]);
                    }
                    if ((after[belowGraph[i]].Top - before[belowGraph[i]].Top) != dH)
                    {
                        covered++;
                        sb.AppendLine("  !! " + belowGraph[i] + " 没有跟着卡片下移");
                    }
                }

                int resizeBad = 0;
                sb.AppendLine();
                sb.AppendLine("--- 关键判定 ---");
                sb.AppendLine("  导航栏高度跟随        " + Show(before, "pnlNav") + " -> " + Show(after, "pnlNav") +
                              ((after["pnlNav"].Height - before["pnlNav"].Height) == dH ? "   PASS" : "   FAIL"));
                if ((after["pnlNav"].Height - before["pnlNav"].Height) != dH) resizeBad++;
                bool okMark = (after["pageMark0"].Left - before["pageMark0"].Left) == dW &&
                              (after["pageMark0"].Top - before["pageMark0"].Top) == dH;
                sb.AppendLine("  水印贴右下跟随        " + Show(before, "pageMark0") + " -> " + Show(after, "pageMark0") +
                              (okMark ? "   PASS" : "   FAIL"));
                if (!okMark) resizeBad++;
                sb.AppendLine("  页体宽高跟随          " + Show(before, "pnlBody") + " -> " + Show(after, "pnlBody") +
                              ((after["pnlBody"].Width - before["pnlBody"].Width) == dW &&
                               (after["pnlBody"].Height - before["pnlBody"].Height) == dH ? "   PASS" : "   FAIL"));
                if ((after["pnlBody"].Width - before["pnlBody"].Width) != dW ||
                    (after["pnlBody"].Height - before["pnlBody"].Height) != dH) resizeBad++;
                sb.AppendLine("  监控卡片双向伸缩      " + Show(before, "gbMonitor") + " -> " + Show(after, "gbMonitor") +
                              ((after["gbMonitor"].Width - before["gbMonitor"].Width) == dW &&
                               (after["gbMonitor"].Height - before["gbMonitor"].Height) == dH ? "   PASS" : "   FAIL"));
                if ((after["gbMonitor"].Width - before["gbMonitor"].Width) != dW ||
                    (after["gbMonitor"].Height - before["gbMonitor"].Height) != dH) resizeBad++;
                sb.AppendLine("  曲线图吸收高度        " + Show(before, "pnlGraph") + " -> " + Show(after, "pnlGraph") +
                              ((after["pnlGraph"].Height - before["pnlGraph"].Height) == dH ? "   PASS" : "   FAIL"));
                if ((after["pnlGraph"].Height - before["pnlGraph"].Height) != dH) resizeBad++;
                sb.AppendLine("  曲线图不遮挡下方四行  " + (covered == 0 ? "   PASS（间距恒定）" : "   FAIL"));
                if (covered != 0) resizeBad++;
                sb.AppendLine("  滑块拉伸 tbMax        " + Show(before, "tbMax") + " -> " + Show(after, "tbMax") +
                              ((after["tbMax"].Width - before["tbMax"].Width) == dW ? "   PASS" : "   FAIL"));
                if ((after["tbMax"].Width - before["tbMax"].Width) != dW) resizeBad++;
                sb.AppendLine("  右侧按钮跟随 btnApply " + Show(before, "btnApply") + " -> " + Show(after, "btnApply") +
                              ((after["btnApply"].Left - before["btnApply"].Left) == dW ? "   PASS" : "   FAIL"));
                if ((after["btnApply"].Left - before["btnApply"].Left) != dW) resizeBad++;
                bool okTwin = before["tbMax"].Width == before["tbMin"].Width &&
                              after["tbMax"].Width == after["tbMin"].Width &&
                              before["tbMax"].Left == before["tbMin"].Left &&
                              before["numMax"].Left == before["numMin"].Left &&
                              after["numMax"].Left == after["numMin"].Left &&
                              before["numMax"].Width == before["numMin"].Width;
                sb.AppendLine("  最大/最小两行结构对齐 " + Show(before, "tbMax") + " / " + Show(before, "tbMin") +
                              (okTwin ? "   PASS（等宽同列）" : "   FAIL"));
                if (!okTwin) resizeBad++;
                bool okCards =
                    (after["gbThermal"].Width - before["gbThermal"].Width) == dW &&
                    (after["gbLight"].Width - before["gbLight"].Width) == dW &&
                    (after["gbSystem"].Width - before["gbSystem"].Width) == dW;
                sb.AppendLine("  温控/背光/系统卡片拉伸 " + Show(before, "gbThermal") + " / " + Show(before, "gbLight") + " / " + Show(before, "gbSystem") +
                              (okCards ? "   PASS" : "   FAIL"));
                if (!okCards) resizeBad++;
                bool okPalette = (after["paletteLight"].Width - before["paletteLight"].Width) == dW;
                bool okRight = (after["btnLightDefault"].Left - before["btnLightDefault"].Left) == dW &&
                               (after["btnHotkey"].Left - before["btnHotkey"].Left) == dW &&
                               (after["btnElevate"].Left - before["btnElevate"].Left) == dW;
                sb.AppendLine("  调色板/右对齐按钮     " + (okPalette ? "调色板 PASS" : "调色板 FAIL") +
                              "   " + (okRight ? "右对齐 PASS" : "右对齐 FAIL"));
                if (!okPalette || !okRight) resizeBad++;

                // ---- 缩回设计尺寸：几何必须完全复原 ----
                f.Size = oldSize;
                f.PerformLayout();
                Application.DoEvents();
                CallSwitchPage(f, 0);
                f.PerformLayout();
                Application.DoEvents();
                bool okBack = Show(f, "gbMonitor") == Show(before, "gbMonitor") &&
                              Show(f, "pnlNav") == Show(before, "pnlNav") &&
                              Show(f, "pnlGraph") == Show(before, "pnlGraph");
                sb.AppendLine("  缩回设计尺寸完全复原  " + Show(f, "gbMonitor") + (okBack ? "   PASS" : "   FAIL"));
                if (!okBack) resizeBad++;

                // ---- 键盘切页：Ctrl+Tab 翻页 / Ctrl+3 直达 ----
                sb.AppendLine();
                sb.AppendLine("--- 键盘切页 ---");
                int keyBad = 0;
                CallSwitchPage(f, 0);
                f.PerformLayout();
                Application.DoEvents();
                System.Reflection.MethodInfo mpk = typeof(MainForm).GetMethod("ProcessCmdKey",
                    System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                Label kt = FindByName(f, "pageMark0") as Label;
                if (mpk == null || kt == null)
                {
                    keyBad++;
                    sb.AppendLine("  !! 找不到 ProcessCmdKey 或页名水印");
                }
                else
                {
                    Message m1 = Message.Create(f.Handle, 0x0100, (IntPtr)Keys.Tab, IntPtr.Zero);
                    bool h1 = (bool)mpk.Invoke(f, new object[] { m1, Keys.Control | Keys.Tab });
                    Label nowMark = FindByName(f, "pageMark1") as Label;
                    bool ok1 = h1 && nowMark != null && nowMark.Text == titles[1] && OwnVisible(nowMark.Parent);
                    sb.AppendLine("  Ctrl+Tab  切到 " + titles[1] + (ok1 ? "   PASS" : "   FAIL"));
                    if (!ok1) keyBad++;

                    Message m2 = Message.Create(f.Handle, 0x0100, (IntPtr)Keys.D3, IntPtr.Zero);
                    bool h2 = (bool)mpk.Invoke(f, new object[] { m2, Keys.Control | Keys.D3 });
                    Label nowMark2 = FindByName(f, "pageMark2") as Label;
                    bool ok2 = h2 && nowMark2 != null && nowMark2.Text == titles[2] && OwnVisible(nowMark2.Parent);
                    sb.AppendLine("  Ctrl+3    切到 " + titles[2] + (ok2 ? "   PASS" : "   FAIL"));
                    if (!ok2) keyBad++;
                }

                // ---- 换缩放档会整界面重建：直接调 RebuildUi，验证重建后结构完好且停在原页 ----
                sb.AppendLine();
                sb.AppendLine("--- 界面重建（换缩放档）---");
                int rebBad = 0;
                CallSwitchPage(f, 2);
                f.PerformLayout();
                Application.DoEvents();
                System.Reflection.MethodInfo mrb = typeof(MainForm).GetMethod("RebuildUi",
                    System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                if (mrb == null)
                {
                    rebBad++;
                    sb.AppendLine("  !! 找不到 RebuildUi");
                }
                else
                {
                    mrb.Invoke(f, null);
                    f.PerformLayout();
                    Application.DoEvents();
                    int np = PageCount(FindByName(f, "pnlBody"));
                    Label rt = FindByName(f, "pageMark2") as Label;
                    Control rc = FindByName(f, "gbThermal");
                    bool okReb = np == pages.Length && rt != null && rt.Text == titles[2] && rc != null;
                    sb.AppendLine("  重建后 页面数 " + np + " · 当前页 " + (rt == null ? "?" : rt.Text) +
                                  " · 温控卡片 " + (rc == null ? "缺失" : "在") + (okReb ? "   PASS" : "   FAIL"));
                    if (!okReb) rebBad++;
                }

                // ---- 全局：状态栏 + 快捷键对话框 ----
                sb.AppendLine();
                sb.AppendLine("--- 状态栏与对话框 ---");
                int problems = 0;
                CheckStatusStrip(f, sb, ref problems);
                HotkeyForm hf = new HotkeyForm(new HotkeyStore.Config());
                IntPtr hh = hf.Handle;
                int hp = 0;
                CheckTextFit(hf, sb, ref hp);
                sb.AppendLine("  快捷键对话框文字  " + (hp == 0 ? "PASS" : "FAIL(" + hp + ")"));
                problems += hp;
                hf.Dispose();

                sb.AppendLine();
                sb.AppendLine("--- 调用 RefreshAutoStartUi() 验证自启开关与真实任务状态的同步 ---");
                try
                {
                    System.Reflection.MethodInfo mi = typeof(MainForm).GetMethod("RefreshAutoStartUi",
                        System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                    if (mi == null)
                    {
                        sb.AppendLine("  失败: 未找到 RefreshAutoStartUi 方法");
                    }
                    else
                    {
                        mi.Invoke(f, null);
                        sb.AppendLine("  调用成功，无异常");
                        CheckBox cb = FindCheckBox(f, "开机自启动");
                        if (cb == null)
                        {
                            sb.AppendLine("  失败: 未找到「开机自启动」复选框");
                        }
                        else
                        {
                            bool real = AutoStart.IsEnabled();
                            sb.AppendLine("  复选框勾选状态 : " + (cb.Checked ? "已勾选" : "未勾选"));
                            sb.AppendLine("  计划任务实际状态: " + (real ? "已启用" : "未启用"));
                            sb.AppendLine("  两者一致        : " + (cb.Checked == real ? "是 (PASS)" : "否 (FAIL)"));
                        }
                    }
                }
                catch (Exception ex)
                {
                    Exception inner = ex.InnerException != null ? ex.InnerException : ex;
                    sb.AppendLine("  异常: " + inner.Message);
                }

                sb.AppendLine();
                sb.AppendLine("=== 判定汇总 ===");
                sb.AppendLine("  外壳结构问题   " + shellBad);
                sb.AppendLine("  分页切换问题   " + pageBad);
                sb.AppendLine("  文字被截断     " + textBad);
                sb.AppendLine("  控件交叠       " + overlapBad);
                sb.AppendLine("  自适应布局问题 " + resizeBad);
                sb.AppendLine("  状态栏/对话框  " + problems);
                sb.AppendLine("  键盘切页问题   " + keyBad);
                sb.AppendLine("  界面重建问题   " + rebBad);
                bool allOk = (shellBad + pageBad + textBad + overlapBad + resizeBad + problems + keyBad + rebBad) == 0;
                sb.AppendLine("  结果: " + (allOk ? "全部 PASS" : "存在 FAIL"));

                f.Dispose();
                sb.AppendLine();
                sb.AppendLine("=== UI 自检结束 ===");
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--uishot")
            {
                // 无界面地把五个页面各渲染成一张 PNG。给文档配图、也给人快速看效果：
                // 不用真起窗口，所以不会碰硬件、不写配置、也不抢单实例互斥量。
                // 顺带也是自绘代码（温度条/曲线/逐核/内存/调色板）的一次真实绘制。
                string dir = args.Length > 1
                    ? args[1]
                    : Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "shots");
                Directory.CreateDirectory(dir);

                StringBuilder rs = new StringBuilder();
                rs.AppendLine("=== SysConsole 页面渲染 ===");
                // 必须真的 Show 一次：没显示过的窗口 DrawToBitmap 只能得到空白图。
                // skipLoad=true 保证不碰硬件、不起轮询、不注册快捷键；
                // 再把它挪到屏幕外 + 全透明，用户什么都看不到。
                MainForm sf = new MainForm(true, true, true);
                sf.ShowInTaskbar = false;
                sf.StartPosition = FormStartPosition.Manual;
                sf.Location = new Point(-32000, -32000);   // 屏幕外，不用 Opacity：
                // Opacity<1 会把整张图按 alpha 混合，DrawToBitmap 拿到的颜色就淡了。
                IntPtr sh = sf.Handle;
                sf.Show();
                Application.DoEvents();
                string[] shotTitles = new string[] { "系统概览", "性能与散热", "温度保护", "键盘背光", "系统与设置", "风扇曲线" };
                for (int i = 0; i < shotTitles.Length; i++)
                {
                    CallSwitchPage(sf, i);
                    sf.PerformLayout();
                    Application.DoEvents();
                    string path = Path.Combine(dir, string.Format(CultureInfo.InvariantCulture, "{0}-{1}.png", i + 1, shotTitles[i]));
                    try
                    {
                        using (Bitmap bmp = new Bitmap(sf.ClientSize.Width, sf.ClientSize.Height))
                        {
                            using (Graphics g = Graphics.FromImage(bmp)) g.Clear(sf.BackColor);
                            // 逐个渲染顶层容器，而不是对窗体本身 DrawToBitmap：
                            // 后者会把标题栏和左右边框一起画进来（实测偏移 11x45），
                            // 客户区右侧和底部就被顶掉了。四个容器互不重叠，正好铺满。
                            List<Control> tops = new List<Control>();
                            foreach (Control c in sf.Controls) if (OwnVisible(c)) tops.Add(c);
                            for (int t = tops.Count - 1; t >= 0; t--)
                                tops[t].DrawToBitmap(bmp, tops[t].Bounds);
                            bmp.Save(path, System.Drawing.Imaging.ImageFormat.Png);
                        }
                        rs.AppendLine(string.Format(CultureInfo.InvariantCulture,
                            "  {0}  {1}x{2}  ->  {3}", shotTitles[i], sf.ClientSize.Width, sf.ClientSize.Height, path));
                    }
                    catch (Exception ex)
                    {
                        rs.AppendLine("  " + shotTitles[i] + " 渲染失败: " + ex.Message);
                    }
                }
                sf.Hide();
                sf.Dispose();
                Emit(rs.ToString());
                return;
            }

            if (cmd == "--uiaudit")
            {
                // 版面余量审计：逐页把每个带文字控件的"需要多大 / 实际多大"列出来，
                // 按余量从小到大排序。--uitest 只回答"有没有超"，这里回答"还剩几像素" ——
                // 只剩几像素的地方，换个缩放档、换台机器、或一次真实数据刷新就会被裁。
                // 宽度和高度都查：高度不足时文字是上下被切掉，比横向截断更难发现。
                MainForm af = new MainForm(true, true);
                IntPtr ah = af.Handle;
                string[] apages = new string[] { "page0", "page1", "page2", "page3", "page4", "page5" };
                string[] atitles = new string[] { "系统概览", "性能与散热", "温度保护", "键盘背光", "系统与设置", "风扇曲线" };
                StringBuilder ab = new StringBuilder();
                ab.AppendLine("=== SysConsole 版面余量审计（缩放 " + UiScaleStore.Load() + "%）===");
                int crit = 0, tight = 0, okc = 0;
                for (int i = 0; i < apages.Length; i++)
                {
                    CallSwitchPage(af, i);
                    af.PerformLayout();
                    Application.DoEvents();
                    Control pg = FindByName(af, apages[i]);
                    if (pg == null) { ab.AppendLine("  !! 缺页面 " + apages[i]); continue; }
                    List<KeyValuePair<int, string>> rows = new List<KeyValuePair<int, string>>();
                    AuditMargins(pg, atitles[i], rows, ref crit, ref tight, ref okc);
                    rows.Sort(delegate(KeyValuePair<int, string> a, KeyValuePair<int, string> b) { return a.Key.CompareTo(b.Key); });
                    ab.AppendLine();
                    ab.AppendLine("--- " + atitles[i] + "（共 " + rows.Count + " 个文字控件，列出余量最小的 12 个）---");
                    int show = Math.Min(12, rows.Count);
                    for (int k = 0; k < show; k++) ab.AppendLine(rows[k].Value);
                }
                // 快捷键设置对话框是另一个窗口，字体/尺寸都自己写死，单独审一遍
                {
                    HotkeyForm hk = new HotkeyForm(new HotkeyStore.Config());
                    IntPtr hh2 = hk.Handle;
                    List<KeyValuePair<int, string>> hrows = new List<KeyValuePair<int, string>>();
                    AuditMargins(hk, "快捷键对话框", hrows, ref crit, ref tight, ref okc);
                    hrows.Sort(delegate(KeyValuePair<int, string> a, KeyValuePair<int, string> b) { return a.Key.CompareTo(b.Key); });
                    ab.AppendLine();
                    ab.AppendLine("--- 快捷键设置对话框（共 " + hrows.Count + " 个文字控件，列出余量最小的 10 个）---");
                    int hs = Math.Min(10, hrows.Count);
                    for (int k = 0; k < hs; k++) ab.AppendLine(hrows[k].Value);
                    hk.Dispose();
                }

                ab.AppendLine();
                ab.AppendLine("=== 汇总 ===");
                ab.AppendLine("  已裁/放不下 (<0) : " + crit);
                ab.AppendLine("  很紧 (<8)        : " + tight);
                ab.AppendLine("  正常 (>=8)       : " + okc);
                Emit(ab.ToString());
                af.Dispose();
                return;
            }

            if (cmd == "--uitest-live")
            {
                // 真正把窗口显示出来、跑几秒轮询，再用"运行时真实文字"量一遍。
                // 默认尺寸下的自检只能看到控件的初始文字（很多是 "--" 或空串），
                // 量不出运行时才填进去的长文本。
                MainForm lf = new MainForm(false, true);
                lf.StartPosition = FormStartPosition.Manual;
                lf.Location = new Point(0, 0);
                lf.Show();
                for (int i = 0; i < 45; i++) { Application.DoEvents(); System.Threading.Thread.Sleep(100); }
                StringBuilder ls = new StringBuilder();
                ls.AppendLine("=== SysConsole 实时文字检查（含运行时数据）===");
                int lp = 0;
                CheckTextFit(lf, ls, ref lp);
                CheckStatusStrip(lf, ls, ref lp);
                ls.AppendLine();
                ls.AppendLine(lp == 0 ? "结果: 运行时全部文字均可完整显示  PASS"
                                      : "结果: 运行时共 " + lp + " 处文字会被截断  FAIL");

                // 界面缩放的实时重建路径也要验一遍：切到最小档再切回原档，
                // 看窗体是否真的变了、重建之后文字和卡片是否还完整。
                int origPct = UiScaleStore.Load();
                ComboBox cs = FindByName(lf, "cmbScale") as ComboBox;
                if (cs != null && cs.Items.Count > 1)
                {
                    ls.AppendLine();
                    ls.AppendLine("--- 界面缩放实时重建检查 ---");
                    ls.AppendLine("  可选档位    : " + string.Join(" / ", UiScaleStore.Options()));
                    int w0 = lf.Width;
                    cs.SelectedIndex = 0;
                    for (int i = 0; i < 25; i++) { Application.DoEvents(); System.Threading.Thread.Sleep(40); }
                    int p2 = 0;
                    CheckTextFit(lf, ls, ref p2);
                    ls.AppendLine("  切到最小档  : 窗体宽 " + w0 + " -> " + lf.Width +
                                  "   页面数 " + PageCount(FindByName(lf, "pnlBody")) + "   文字问题 " + p2);

                    int wMin = lf.Width;

                    ComboBox cs2 = FindByName(lf, "cmbScale") as ComboBox;
                    if (cs2 != null) { cs2.SelectedIndex = cs2.Items.Count - 1; }
                    for (int i = 0; i < 25; i++) { Application.DoEvents(); System.Threading.Thread.Sleep(40); }
                    int p3 = 0;
                    CheckTextFit(lf, ls, ref p3);
                    int wMax = lf.Width;
                    ls.AppendLine("  切到最大档  : 窗体宽 " + wMax +
                                  "   页面数 " + PageCount(FindByName(lf, "pnlBody")) + "   文字问题 " + p3);

                    // 复原这一档只验证"确实回到中间尺寸、卡片结构没散" ——
                    // w0 是启动时从 UiState 恢复的历史尺寸，未必等于设计尺寸，
                    // 拿它当基准会误报。
                    ComboBox cs3 = FindByName(lf, "cmbScale") as ComboBox;
                    if (cs3 != null) cs3.SelectedItem = UiScaleStore.Label(origPct);
                    for (int i = 0; i < 25; i++) { Application.DoEvents(); System.Threading.Thread.Sleep(40); }
                    bool okBack = lf.Width > Math.Min(wMin, wMax) && lf.Width < Math.Max(wMin, wMax)
                                  && PageCount(FindByName(lf, "pnlBody")) == 5;
                    ls.AppendLine("  复原为 " + origPct + "% : 窗体宽 " + lf.Width +
                                  " (最小 " + wMin + " / 最大 " + wMax + ")" +
                                  (okBack ? "   PASS" : "   FAIL"));
                }
                else UiScaleStore.Save(origPct);
                Emit(ls.ToString());
                lf.Close();
                return;
            }

            if (cmd == "--uiscale")
            {
                // --uiscale         查看当前设置
                // --uiscale N       设置（80-100，受屏幕可用高度限制）
                if (args.Length > 1)
                {
                    int pct;
                    if (!int.TryParse(args[1].TrimEnd('%'), NumberStyles.Integer,
                                      CultureInfo.InvariantCulture, out pct))
                    { Emit("用法: --uiscale [80-100]"); return; }
                    int c = UiScaleStore.Clamp(pct);
                    UiScaleStore.Save(c);
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                        "界面缩放已设为 {0}%（请求 {1}%，本机屏幕上限 {2}%）", c, pct, UiScaleStore.MaxForScreen()));
                }
                else
                {
                    sb.AppendLine("当前界面缩放 : " + UiScaleStore.Load() + "%");
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                        "可选范围     : {0}% - {1}%（上限由屏幕可用高度决定）",
                        UiScaleStore.Min, UiScaleStore.MaxForScreen()));
                }
                sb.AppendLine("配置文件     : " + UiScaleStore.FilePath());
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--rainbow")
            {
                // --rainbow on|off|status  —— 开关 EC 固件自带的硬件彩虹
                //
                // 出自原厂 StartRainbowMode（RVA 0x3E5B0）：往 0x767 的 bit7 写 1 就开。
                // 它由键盘固件驱动，零 CPU 占用，而且本进程退出后仍然在跑。
                // ⚠️ 只翻转 bit7，其它位按读回值原样保留（bit0~3 与风扇有关）。
                string a1 = args.Length > 1 ? args[1].ToLowerInvariant() : "status";
                sb.AppendLine("管理员   : " + Elevation.IsElevated());

                if (a1 == "on" || a1 == "off")
                {
                    bool want = a1 == "on";
                    // 先按原厂 RunEffctEC 复位残留状态
                    Ec.KbColor.ClearEffectState();
                    string err = Ec.KbColor.SetHardwareRainbow(want);
                    sb.AppendLine(err == null
                        ? ("已" + (want ? "开启" : "关闭") + "硬件彩虹（0x767 bit7 = " + (want ? "1" : "0") + "）。")
                        : ("操作失败：" + err));
                    if (want)
                        sb.AppendLine("它由 EC 固件驱动，本进程退出后仍在跑。要关掉：--rainbow off");
                }
                else
                {
                    int cur = 0;
                    sb.AppendLine("用法     : --rainbow on|off|status");
                    sb.AppendLine("当前状态 : " + (Ec.KbColor.IsHardwareRainbowOn() ? "已开启" : "已关闭"));
                    sb.AppendLine("0x767    : " + cur);
                }
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--blink")
            {
                // --blink on|off [慢|中|快]   —— 让当前颜色以可调频率明暗交替
                // 硬件做不到这个：0x7C5 的闪烁只有黄/红/绿/蓝四个固定颜色，与底色无关。
                string a1 = args.Length > 1 ? args[1].ToLowerInvariant() : "status";
                string a2 = args.Length > 2 ? args[2] : "中";
                int rate = a2 == "慢" || a2 == "slow" ? 0 : (a2 == "快" || a2 == "fast" ? 2 : 1);
                sb.AppendLine("管理员   : " + Elevation.IsElevated());

                if (a1 == "on" || a1 == "off")
                {
                    int lr, lg, lb;
                    if (!Ec.KbColor.ReadLevels(out lr, out lg, out lb))
                    { Emit("EC 设备不可用：" + Ec.LastError); return; }
                    int r = Ec.KbColor.RFromLevel(lr), g = Ec.KbColor.GFromLevel(lg), b = Ec.KbColor.BFromLevel(lb);
                    int half = rate == 0 ? 900 : (rate == 1 ? 600 : 350);
                    if (a1 == "off")
                    {
                        Ec.KbColor.SetHardwareRainbow(false);
                        Ec.KbColor.ClearEffectState();
                        Ec.KbColor.ApplyRgb(r, g, b, false);
                        sb.AppendLine("已停止闪烁，恢复常亮。");
                    }
                    else
                    {
                        Ec.KbColor.SetHardwareRainbow(false);
                        Ec.KbColor.ClearEffectState();
                        double period = rate == 0 ? 1.8 : (rate == 1 ? 1.2 : 0.7);
                        sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                            "开始闪烁：颜色 RGB({0},{1},{2})，一个明暗来回 {3:0.#} 秒（暗相保留 20% 亮度，不会全黑）。按 Ctrl+C 结束。",
                            r, g, b, period));
                        sb.AppendLine("（这是软件实现的，属于阻塞运行；界面里的「闪烁」勾选框是常驻的。）");
                        double ph = 0, last = 0;
                        Stopwatch bs = Stopwatch.StartNew();
                        while (true)
                        {
                            double now = bs.Elapsed.TotalSeconds;
                            double dt = now - last;
                            last = now;
                            if (dt <= 0 || dt > 0.5) dt = 0.03;
                            ph += dt / period;
                            if (ph >= 1) ph -= Math.Floor(ph);
                            double v;
                            if (ph < 0.35) v = 1.0;
                            else if (ph < 0.50) { double x = (ph - 0.35) / 0.15; v = 1.0 - x * x * (3 - 2 * x); }
                            else if (ph < 0.85) v = 0.0;
                            else { double x = (ph - 0.85) / 0.15; v = x * x * (3 - 2 * x); }
                            double f = 0.20 + 0.80 * v;
                            Ec.KbColor.ApplyRgbFast((int)Math.Round(r * f),
                                                    (int)Math.Round(g * f),
                                                    (int)Math.Round(b * f));
                            System.Threading.Thread.Sleep(30);
                        }
                    }
                }
                else
                {
                    sb.AppendLine("用法     : --blink on|off [慢|中|快]");
                    sb.AppendLine("说明     : 让当前颜色按频率明暗交替（软件实现）");
                }
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--keytest")
            {
                int sec = 30;
                if (args.Length > 1)
                {
                    int n;
                    if (int.TryParse(args[1], out n) && n > 0 && n <= 300) sec = n;
                }
                KeyTest.Run(sec);
                sb.AppendLine("按键诊断完成。");
                sb.AppendLine("结果文件: " + KeyTest.ResultPath());
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--preset")
            {
                string key = args.Length > 1 ? args[1] : "balanced";
                Power.Preset p = Power.FindPreset(key);
                if (p == null)
                {
                    Emit("未知场景: " + key + "  (可用: performance | balanced | quiet)");
                    return;
                }
                sb.AppendLine("应用场景: " + p.Name + " (" + p.Key + ")");
                sb.AppendLine("管理员: " + Elevation.IsElevated());
                sb.AppendLine(Power.ApplyPreset(p));
                sb.AppendLine("--- 应用后回读 ---");
                PowerState st = Power.Read();
                sb.AppendLine("  睿频加速        : " + (st.TurboEnabled ? "开启" : "关闭"));
                sb.AppendLine("  电源模式        : " + Power.ModeName(st.Mode));
                sb.AppendLine("  散热策略        : " + (st.CoolingPolicy == Power.COOLING_ACTIVE ? "主动" : "被动"));
                sb.AppendLine("  最大处理器状态  : " + st.MaxState + " %");
                sb.AppendLine("  最小处理器状态  : " + st.MinState + " %");
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--autostart")
            {
                string what = args.Length > 1 ? args[1].ToLowerInvariant() : "status";
                if (what == "on")
                {
                    string r = AutoStart.Enable(Application.ExecutablePath);
                    sb.AppendLine("启用开机自启: " + r);
                }
                else if (what == "off")
                {
                    string r = AutoStart.Disable();
                    sb.AppendLine("关闭开机自启: " + r);
                }
                sb.AppendLine("当前状态: " + (AutoStart.IsEnabled() ? "已启用" : "未启用"));
                sb.AppendLine("任务名称: " + AutoStart.TaskName);
                sb.AppendLine("程序路径: " + Application.ExecutablePath);
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--set")
            {
                // --set turbo=on|off mode=balanced|performance|efficiency cooling=active|passive max=100 min=5
                sb.AppendLine("管理员: " + Elevation.IsElevated());
                for (int i = 1; i < args.Length; i++)
                {
                    string a = args[i];
                    int eq = a.IndexOf('=');
                    if (eq <= 0) continue;
                    string k = a.Substring(0, eq).ToLowerInvariant();
                    string v = a.Substring(eq + 1).ToLowerInvariant();
                    if (k == "turbo") sb.AppendLine("TURBO : " + Power.SetTurbo(v == "on" || v == "1" || v == "true"));
                    else if (k == "mode")
                    {
                        int m = Power.MODE_BALANCED;
                        if (v == "performance") m = Power.MODE_PERFORMANCE;
                        else if (v == "efficiency") m = Power.MODE_EFFICIENCY;
                        sb.AppendLine("MODE  : " + Power.SetMode(m));
                    }
                    else if (k == "cooling") sb.AppendLine("COOL  : " + Power.SetCooling(v == "active" ? Power.COOLING_ACTIVE : Power.COOLING_PASSIVE));
                    else if (k == "max") { int n; if (int.TryParse(v, out n)) sb.AppendLine("MAX   : " + Power.SetMaxState(n)); }
                    else if (k == "min") { int n; if (int.TryParse(v, out n)) sb.AppendLine("MIN   : " + Power.SetMinState(n)); }
                }
                PowerState st = Power.Read();
                sb.AppendLine("--- 回读 ---");
                sb.AppendLine("  睿频=" + (st.TurboEnabled ? "开" : "关") + "  模式=" + Power.ModeName(st.Mode) +
                              "  散热=" + (st.CoolingPolicy == Power.COOLING_ACTIVE ? "主动" : "被动") +
                              "  最大=" + st.MaxState + "%  最小=" + st.MinState + "%");
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--fan")
            {
                Emit(Ec.Report());
                return;
            }

            if (cmd == "--fanboost")
            {
                // --fanboost on|off|toggle|status|ensure
                string what = args.Length > 1 ? args[1].ToLowerInvariant() : "status";
                sb.AppendLine("管理员: " + Elevation.IsElevated());
                if (what == "on") sb.AppendLine(Ec.FanBoost.Enable());
                else if (what == "off") sb.AppendLine(Ec.FanBoost.Disable());
                else if (what == "toggle") sb.AppendLine(Ec.FanBoost.Toggle());
                else if (what == "ensure") sb.AppendLine(Ec.EnsureDevice());
                else if (what != "status") { Emit("未知参数: " + what + "  (可用: on | off | toggle | status | ensure)"); return; }
                sb.AppendLine();
                sb.AppendLine(Ec.FanBoost.Status());
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--color")
            {
                // --color R G B          按 0..255 RGB 设色（内部按原厂公式换算电平）
                // --color read           读当前/出厂电平
                // --color default        恢复 EC 出厂色
                // --color levels r g b   直接写电平（1..50）
                string a1 = args.Length > 1 ? args[1].ToLowerInvariant() : "read";
                sb.AppendLine("管理员: " + Elevation.IsElevated());
                if (a1 == "read" || args.Length < 4)
                {
                    int lr, lg, lb, dr, dg, db;
                    if (Ec.KbColor.ReadLevels(out lr, out lg, out lb))
                        sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                            "当前电平 : {0}/{1}/{2}   ≈ RGB({3},{4},{5})", lr, lg, lb,
                            Ec.KbColor.RFromLevel(lr), Ec.KbColor.GFromLevel(lg), Ec.KbColor.BFromLevel(lb)));
                    else sb.AppendLine("读取电平失败: " + Ec.LastError);
                    if (Ec.KbColor.ReadDefaults(out dr, out dg, out db))
                        sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                            "出厂电平 : {0}/{1}/{2}", dr, dg, db));
                    sb.AppendLine("触发字节 0x767 = " + Ec.Read(Ec.REG_KB_TRIGGER) +
                                  "    状态 0x768 = " + Ec.Read(Ec.REG_KB_STATUS));
                    Emit(sb.ToString());
                    return;
                }
                if (a1 == "default")
                {
                    int dr, dg, db;
                    if (!Ec.KbColor.ReadDefaults(out dr, out dg, out db)) { Emit("读出厂色失败: " + Ec.LastError); return; }
                    string e = Ec.KbColor.ApplyLevels(dr, dg, db, true);
                    sb.AppendLine(e == null ? "已恢复出厂电平 " + dr + "/" + dg + "/" + db : e);
                    Emit(sb.ToString());
                    return;
                }
                if (a1 == "levels")
                {
                    int rl, gl, bl;
                    if (args.Length < 5 || !int.TryParse(args[2], out rl) ||
                        !int.TryParse(args[3], out gl) || !int.TryParse(args[4], out bl))
                    { Emit("用法: --color levels <r> <g> <b>   (电平 1..50)"); return; }
                    string e = Ec.KbColor.ApplyLevels(rl, gl, bl, true);
                    sb.AppendLine(e == null ? "已写入电平 " + rl + "/" + gl + "/" + bl : e);
                    Emit(sb.ToString());
                    return;
                }
                int r, g, b;
                if (!int.TryParse(a1, out r) || args.Length < 4 ||
                    !int.TryParse(args[2], out g) || !int.TryParse(args[3], out b))
                { Emit("用法: --color <R> <G> <B> (0..255) | read | default | levels r g b"); return; }
                string er2 = Ec.KbColor.ApplyRgb(r, g, b, true);
                sb.AppendLine(er2 == null
                    ? string.Format(CultureInfo.InvariantCulture, "已设置 RGB({0},{1},{2})   {3}",
                                    r, g, b, Ec.KbColor.LevelText(r, g, b))
                    : er2);
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--fancurve")
            {
                // --fancurve                    查看曲线与当前状态（只读，不碰 EC 写）
                // --fancurve on | off           启用 / 关闭并还原
                // --fancurve set t1 t2 t3 [回差]  设置三个温度上限（档位固定 静音/安静/标准/强冷）
                // --fancurve preview <温度>     只看会选哪一档
                // --fancurve run [秒数]         真的跑一会儿闭环（会写 0x751，结束时还原）
                FanCurveConfig fc = FanCurveStore.Load();
                string what = args.Length > 1 ? args[1].ToLowerInvariant() : "status";

                if (what == "on" || what == "off")
                {
                    fc.Enabled = (what == "on");
                    FanCurveStore.Save(fc);
                    sb.AppendLine(what == "on"
                        ? "风扇曲线: 已启用（由主程序每秒跑一次；主程序退出时会还原风扇模式）"
                        : "风扇曲线: 已关闭");
                    if (what == "off") sb.AppendLine(FanCurve.Restore());
                }
                else if (what == "set")
                {
                    int t1, t2, t3;
                    if (args.Length < 5 ||
                        !int.TryParse(args[2], NumberStyles.Integer, CultureInfo.InvariantCulture, out t1) ||
                        !int.TryParse(args[3], NumberStyles.Integer, CultureInfo.InvariantCulture, out t2) ||
                        !int.TryParse(args[4], NumberStyles.Integer, CultureInfo.InvariantCulture, out t3))
                    { Emit("用法: --fancurve set <t1> <t2> <t3> [回差]    例如 --fancurve set 50 65 78 3"); return; }
                    int hys = fc.Hysteresis;
                    if (args.Length > 5) int.TryParse(args[5], NumberStyles.Integer, CultureInfo.InvariantCulture, out hys);
                    System.Collections.Generic.List<FanCurvePoint> pts2 = new System.Collections.Generic.List<FanCurvePoint>();
                    pts2.Add(new FanCurvePoint(t1, 0));
                    pts2.Add(new FanCurvePoint(t2, 1));
                    pts2.Add(new FanCurvePoint(t3, 2));
                    pts2.Add(new FanCurvePoint(0, 3));
                    fc.Points = pts2;
                    if (hys < 0) hys = 0;
                    if (hys > 15) hys = 15;
                    fc.Hysteresis = hys;
                    FanCurveStore.Save(fc);
                    sb.AppendLine("风扇曲线已更新");
                }
                else if (what == "preview")
                {
                    double t;
                    if (args.Length < 3 ||
                        !double.TryParse(args[2], NumberStyles.Float, CultureInfo.InvariantCulture, out t))
                    { Emit("用法: --fancurve preview <温度>"); return; }
                    sb.AppendLine(FanCurve.Preview(t, fc));
                    Emit(sb.ToString());
                    return;
                }
                else if (what == "run")
                {
                    int sec = 20;
                    if (args.Length > 2)
                    {
                        int n;
                        if (int.TryParse(args[2], NumberStyles.Integer, CultureInfo.InvariantCulture, out n) && n > 0 && n <= 180) sec = n;
                    }
                    FanCurveConfig rc = fc.Clone();
                    rc.Enabled = true;
                    sb.AppendLine("风扇曲线试运行 " + sec + " 秒（每秒一次，结束时还原风扇模式）");
                    for (int i = 0; i < sec; i++)
                    {
                        double t = Sensors.Read().MaxZoneTemp;
                        string msg = FanCurve.Tick(t, rc);
                        Ec.FanReadout fr1 = Ec.ReadFan();
                        sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                            "  {0,3}s  {1:0.0}°C  档位 {2,-4}  {3}",
                            i + 1, t, FanLevels.Name(FanCurve.CurrentLevel),
                            fr1.Ok ? (fr1.Fan1Rpm + " / " + fr1.Fan2Rpm + " RPM  占空比 " + fr1.Fan1Duty + "/" + fr1.Fan2Duty) : "读取失败"));
                        if (msg != null) sb.AppendLine("        " + msg);
                        System.Threading.Thread.Sleep(1000);
                    }
                    sb.AppendLine("  " + FanCurve.Restore());
                    Emit(sb.ToString());
                    return;
                }
                else if (what != "status") { Emit("未知参数: " + what + "  (可用: status | on | off | set | preview | run)"); return; }

                // ---- 状态（只读）----
                int curReg = Ec.Read(Ec.REG_FAN_CTRL);
                Ec.FanReadout frr = Ec.ReadFan();
                sb.AppendLine("风扇曲线 : " + (fc.Enabled ? "已启用" : "已关闭") + "      回差 " + fc.Hysteresis + "°C");
                for (int i = 0; i < fc.Points.Count; i++)
                {
                    bool last = (i == fc.Points.Count - 1);
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                        "  {0}  ->  {1}（稳态占空比 {2}）",
                        last ? ("≥ " + fc.Points[i - 1].LimitC + "°C") : ("< " + fc.Points[i].LimitC + "°C"),
                        FanLevels.Name(fc.Points[i].Level), FanLevels.DutyText[fc.Points[i].Level]));
                }
                sb.AppendLine("安全底线 : ≥" + FanCurve.MinStandardC.ToString("0", CultureInfo.InvariantCulture) +
                              "°C 不允许低于「标准」；≥" + FanCurve.ForceBoostC.ToString("0", CultureInfo.InvariantCulture) +
                              "°C 强制强冷（优先于曲线，不可关闭）");
                sb.AppendLine("当前 EC  : 0x751 = 0x" + (curReg < 0 ? "??" : curReg.ToString("X2", CultureInfo.InvariantCulture)) +
                              "（" + (curReg < 0 ? "读取失败" : FanLevels.Name(FanLevels.FromReg(curReg))) + "）   " +
                              (frr.Ok ? frr.Summary : "风扇读取失败"));
                sb.Append("预览     : ");
                double[] demo = new double[] { 40, 55, 70, 78, 85 };
                for (int i = 0; i < demo.Length; i++)
                    sb.Append(string.Format(CultureInfo.InvariantCulture, "{0:0}°C→{1}{2}",
                        demo[i], FanLevels.Name(Math.Max(FanCurve.TargetLevel(demo[i], fc), FanCurve.SafetyFloor(demo[i]))),
                        i == demo.Length - 1 ? "" : "   "));
                sb.AppendLine();
                Emit(sb.ToString());
                return;
            }

            if (cmd == "--fantest")
            {
                // 风扇曲线画布的交互自检：用反射给它发鼠标事件，模拟拖动四个圆点。
                // 拖动是唯一会高频触发"改配置 → 存盘 → 重绘"的路径，专门跑一遍看
                // 会不会抛异常或卡住。
                StringBuilder fb = new StringBuilder();
                fb.AppendLine("=== 风扇曲线画布交互自检 ===");
                MainForm ff = new MainForm(true, true);
                IntPtr fh = ff.Handle;
                CallSwitchPage(ff, 5);
                ff.PerformLayout();
                Application.DoEvents();

                object panel = FindByName(ff, "pnlFanCurve");
                if (panel == null) { fb.AppendLine("  !! 找不到 pnlFanCurve"); Emit(fb.ToString()); ff.Dispose(); return; }
                Type pt = panel.GetType();
                System.Reflection.BindingFlags BF = System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance;
                System.Reflection.MethodInfo hAt = pt.GetMethod("HandleAt", BF);
                System.Reflection.FieldInfo fPoints = pt.GetField("Points", BF);
                System.Reflection.MethodInfo mDown = typeof(Control).GetMethod("OnMouseDown", BF);
                System.Reflection.MethodInfo mMove = typeof(Control).GetMethod("OnMouseMove", BF);
                System.Reflection.MethodInfo mUp = typeof(Control).GetMethod("OnMouseUp", BF);
                if (hAt == null || fPoints == null || mDown == null || mMove == null || mUp == null)
                { fb.AppendLine("  !! 反射取不到方法/字段"); Emit(fb.ToString()); ff.Dispose(); return; }

                bool hadFile = File.Exists(FanCurveStore.FilePath());
                Control ctl = panel as Control;
                int w = ctl.Width, h = ctl.Height;
                Stopwatch sw = Stopwatch.StartNew();
                int edges = 0, errs = 0;
                for (int i = 0; i < 4; i++)
                {
                    Point h0 = (Point)hAt.Invoke(panel, new object[] { i });
                    try
                    {
                        mDown.Invoke(panel, new object[] { new MouseEventArgs(MouseButtons.Left, 1, h0.X, h0.Y, 0) });
                        for (int k = 0; k < 10; k++)
                        {
                            int nx = h0.X + ((k % 2 == 0) ? 24 : -24) * (k / 2 + 1);
                            int ny = h0.Y + ((k % 3 == 0) ? 30 : -30);
                            if (nx < 2) nx = 2;
                            if (nx > w - 2) nx = w - 2;
                            if (ny < 2) ny = 2;
                            if (ny > h - 2) ny = h - 2;
                            mMove.Invoke(panel, new object[] { new MouseEventArgs(MouseButtons.Left, 1, nx, ny, 0) });
                        }
                        mUp.Invoke(panel, new object[] { new MouseEventArgs(MouseButtons.Left, 1, h0.X, h0.Y, 0) });
                    }
                    catch (Exception ex) { errs++; fb.AppendLine("  !! 第 " + i + " 个圆点拖动异常: " + ex.Message); }
                }
                sw.Stop();
                Application.DoEvents();

                // ⚠ 防回归：连续画 5 遍，确认 MainForm 的共享字体没被 Dispose 掉。
                // 曾经用 using (Font f = fSmall) 把共享字体释放了 —— 第一次绘制之后
                // 每次 DrawString 都失败，WinForms 反复重绘，UI 线程满 CPU 死循环。
                int paintErr = 0;
                for (int k = 0; k < 5; k++)
                {
                    try
                    {
                        using (Bitmap bmp2 = new Bitmap(ctl.Width, ctl.Height))
                            ctl.DrawToBitmap(bmp2, new Rectangle(0, 0, ctl.Width, ctl.Height));
                    }
                    catch (Exception ex) { paintErr++; fb.AppendLine("  !! 第 " + k + " 次绘制异常: " + ex.Message); }
                }
                string[] fontNames = new string[] { "fSmall", "fNormal", "fSect", "fBig" };
                int deadFonts = 0;
                for (int k = 0; k < fontNames.Length; k++)
                {
                    System.Reflection.FieldInfo fi = typeof(MainForm).GetField(fontNames[k],
                        System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);
                    if (fi == null) { deadFonts++; fb.AppendLine("  !! 找不到字体字段 " + fontNames[k]); continue; }
                    Font fo = fi.GetValue(null) as Font;
                    try
                    {
                        if (fo == null || fo.Height <= 0) { deadFonts++; fb.AppendLine("  !! 字体 " + fontNames[k] + " 不可用"); }
                    }
                    catch (Exception ex) { deadFonts++; fb.AppendLine("  !! 字体 " + fontNames[k] + " 已被释放: " + ex.GetType().Name); }
                }
                fb.AppendLine("  连画 5 遍 / 共享字体: 绘制异常 " + paintErr + " 次，失效字体 " + deadFonts + " 个");
                errs += paintErr + deadFonts;

                System.Collections.IEnumerable pts = (System.Collections.IEnumerable)fPoints.GetValue(panel);
                fb.Append("  拖动后曲线: ");
                foreach (object o in pts)
                {
                    FanCurvePoint fp = (FanCurvePoint)o;
                    fb.Append("[" + fp.LimitC + "°C→" + FanLevels.Name(fp.Level) + "] ");
                }
                fb.AppendLine();
                // 单点合法性：阈值递增、档位不倒挂
                List<FanCurvePoint> chk = new List<FanCurvePoint>();
                foreach (object o in pts) chk.Add((FanCurvePoint)o);
                for (int i = 1; i < 3; i++)
                {
                    if (chk[i].LimitC <= chk[i - 1].LimitC) edges++;
                    if (chk[i].Level < chk[i - 1].Level) edges++;
                }
                if (chk[3].Level < chk[2].Level) edges++;

                // 再验证"实测点云"画得出来：塞 60 个合成样本，画到位图里数像素
                System.Reflection.MethodInfo mAdd = pt.GetMethod("AddSample", BF);
                int dotPx = 0;
                if (mAdd != null)
                {
                    for (int i = 0; i < 60; i++)
                        mAdd.Invoke(panel, new object[] { 45.0 + (i % 30), 2200 + (i % 20) * 150 });
                    using (Bitmap bmp = new Bitmap(ctl.Width, ctl.Height))
                    {
                        ctl.DrawToBitmap(bmp, new Rectangle(0, 0, ctl.Width, ctl.Height));
                        for (int y = 0; y < bmp.Height; y += 2)
                            for (int x = 0; x < bmp.Width; x += 2)
                            {
                                Color c = bmp.GetPixel(x, y);
                                // 半透明主题蓝落在白底上 → 浅蓝；网格灰线不满足 B > R+30
                                if (c.B > c.R + 30 && c.B > 200 && c.R > 120 && c.R < 235) dotPx++;
                            }
                    }
                    fb.AppendLine("  合成 60 个实测点 → 点云像素(抽样) = " + dotPx);
                    if (dotPx < 50) errs++;
                }
                else { fb.AppendLine("  !! 取不到 AddSample"); errs++; }

                fb.AppendLine("  拖动 40 次耗时 : " + sw.ElapsedMilliseconds + " ms");
                fb.AppendLine("  异常 / 倒挂     : " + errs + " / " + edges);
                fb.AppendLine("  结果: " + ((errs == 0 && edges == 0) ? "PASS" : "FAIL"));
                Emit(fb.ToString());

                // 没配置文件就当测试没发生过，别在用户机器上留东西
                if (!hadFile) { try { if (File.Exists(FanCurveStore.FilePath())) File.Delete(FanCurveStore.FilePath()); } catch { } }
                ff.Dispose();
                return;
            }

            if (cmd == "--wall")
            {
                // --wall on|off|target=85|floor=30|step=5|drop_turbo=on|link_boost=on|margin=5
                // 温度墙是闭环控制，实际执行在 GUI 进程里；这里只负责改配置。
                ThermalWallConfig w = WallStore.Load();
                sb.AppendLine("管理员: " + Elevation.IsElevated());
                bool changed = false;
                for (int i = 1; i < args.Length; i++)
                {
                    string a = args[i].ToLowerInvariant();
                    if (a == "on") { w.Enabled = true; changed = true; continue; }
                    if (a == "off") { w.Enabled = false; changed = true; continue; }
                    int eq = a.IndexOf('=');
                    if (eq <= 0) continue;
                    string k = a.Substring(0, eq);
                    string v = a.Substring(eq + 1);
                    double d; int n;
                    if (k == "target") { if (double.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out d)) { w.TargetC = d; changed = true; } }
                    else if (k == "floor") { if (int.TryParse(v, out n)) { w.FloorState = n; changed = true; } }
                    else if (k == "step") { if (int.TryParse(v, out n)) { w.StepPercent = n; changed = true; } }
                    else if (k == "drop_turbo") { w.DropTurbo = (v == "on" || v == "1" || v == "true"); changed = true; }
                    else if (k == "link_boost") { w.LinkFanBoost = (v == "on" || v == "1" || v == "true"); changed = true; }
                    else if (k == "margin") { if (double.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out d)) { w.LinkMarginC = d; changed = true; } }
                }
                if (changed) { WallStore.Save(w); sb.AppendLine("配置已保存（GUI 下次启动时生效）"); }
                sb.AppendLine();
                sb.AppendLine("温度墙   : " + (w.Enabled ? "已启用" : "未启用"));
                sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "目标温度 : {0:0.#} °C   回差 {1:0.#} °C", w.TargetC, w.HysteresisC));
                sb.AppendLine("控制范围 : 处理器上限 " + w.FloorState + "% - 你设定的值，每次调整 " + w.StepPercent + "%");
                sb.AppendLine("超温关睿频: " + (w.DropTurbo ? "开" : "关"));
                sb.AppendLine("联动强冷 : " + (w.LinkFanBoost ? "开（距目标 " + w.LinkMarginC.ToString("0.#") + "°C 时）" : "关"));
                sb.AppendLine("配置文件 : " + WallStore.FilePath());
                Emit(sb.ToString());
                return;
            }

            Emit("SysConsole 用法:\r\n" +
                 "  SysConsole.exe                     启动图形控制台\r\n" +
                 "  SysConsole.exe --tray              启动并最小化到托盘\r\n" +
                 "  SysConsole.exe --selftest          无界面自检，结果写入 cli-last.txt\r\n" +
                 "  SysConsole.exe --preset <key>      应用场景 performance|balanced|quiet\r\n" +
                 "  SysConsole.exe --autostart on|off|status\r\n" +
                 "  SysConsole.exe --set turbo=on mode=balanced cooling=active max=100 min=5\r\n" +
                 "  SysConsole.exe --keytest [秒]      按键诊断，探测 Fn 等功能键是否上报给 Windows\r\n" +
                 "  SysConsole.exe --fan                读取 EC：风扇转速/模式/功耗上限（原生 IOCTL）\r\n" +
                 "  SysConsole.exe --fanboost on|off|status   一键强冷（直写 EC 0x751，不依赖 OEM 软件）\r\n" +
                 "  SysConsole.exe --wall on|off target=85 floor=30 step=5 drop_turbo=on link_boost=on\r\n" +
                 "\r\n日志目录: " + Log.Dir());
        }

        static int _uiCount;

        /// <summary>
        /// 收集单个页面的文字余量。余量 = min(横向余量, 纵向余量)：
        ///   横向 = 可用宽度 - 文字需要宽度（CheckBox 扣掉勾选框，GroupBox 扣掉边框）
        ///   纵向 = 可用高度 - 行数 × 字体行高
        /// </summary>
        static void AuditMargins(Control root, string page, List<KeyValuePair<int, string>> into,
                                 ref int crit, ref int tight, ref int okc)
        {
            string t = root.Text;
            if (!string.IsNullOrEmpty(t) && ((root is Label) || (root is CheckBox) || (root is Button) || (root is GroupBox)))
            {
                string[] tl = t.Replace("\r\n", "\n").Split('\n');
                int needW = 0;
                for (int i = 0; i < tl.Length; i++)
                {
                    int w = TextRenderer.MeasureText(tl[i], root.Font).Width;
                    if (w > needW) needW = w;
                }
                int availW = root.ClientSize.Width;
                if (root is CheckBox) availW -= 20;
                if (root is GroupBox) availW -= 18;
                int availH = root.ClientSize.Height;
                int needH = tl.Length * root.Font.Height;
                int mw = availW - needW;
                int mh = availH - needH;
                int margin = Math.Min(mw, mh);
                if (margin < 0) crit++; else if (margin < 8) tight++; else okc++;
                into.Add(new KeyValuePair<int, string>(margin, string.Format(CultureInfo.InvariantCulture,
                    "  {0,5}  (横 {1,5} 纵 {2,5})  {3,-9} {4,-26} \"{5}\"",
                    margin, mw, mh, root.GetType().Name, page + "/" + CtrlName(root),
                    tl.Length > 1 ? tl[0] + " …" : Shorten(t))));
            }

            ComboBox cb = root as ComboBox;
            if (cb != null)
            {
                int avail = cb.ClientSize.Width - 24;
                for (int i = 0; i < cb.Items.Count; i++)
                {
                    string item = Convert.ToString(cb.Items[i]);
                    int need = TextRenderer.MeasureText(item, cb.Font).Width;
                    int m2 = avail - need;
                    if (m2 < 0) crit++; else if (m2 < 8) tight++; else okc++;
                    into.Add(new KeyValuePair<int, string>(m2, string.Format(CultureInfo.InvariantCulture,
                        "  {0,5}  (横 {1,5} 纵 {2,5})  {3,-9} {4,-26} \"{5}\"",
                        m2, m2, 0, "ComboBox项", page + "/" + CtrlName(cb), Shorten(item))));
                }
            }

            foreach (Control c in root.Controls) AuditMargins(c, page, into, ref crit, ref tight, ref okc);
        }


        /// <summary>页面容器里以 page 开头的面板数量。</summary>
        static int PageCount(Control body)
        {
            if (body == null) return 0;
            int n = 0;
            foreach (Control c in body.Controls)
                if (!string.IsNullOrEmpty(c.Name) && c.Name.StartsWith("page", StringComparison.Ordinal)) n++;
            return n;
        }

        /// <summary>调用 MainForm 的私有 SwitchPage（自检从外部切页）。</summary>
        static void CallSwitchPage(MainForm f, int index)
        {
            System.Reflection.MethodInfo mi = typeof(MainForm).GetMethod("SwitchPage",
                System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            if (mi == null) throw new InvalidOperationException("MainForm.SwitchPage 不存在");
            mi.Invoke(f, new object[] { index });
        }

        /// <summary>
        /// 控件"自己"的可见标志。
        ///
        /// Control.Visible 会把父级的状态一起算进来：窗口只要没 Show 过，整棵树
        /// 都返回 false。无界面自检正是这种情况，于是原来那句"两张卡片内均无控件
        /// 交叠 PASS"其实是空转 —— kids 列表是空的。这里直接读 Control 内部的
        /// STATE_VISIBLE 位，只看控件自己有没有被设定为可见。
        /// </summary>
        static bool OwnVisible(Control c)
        {
            System.Reflection.MethodInfo mi = typeof(Control).GetMethod("GetState",
                System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            if (mi == null) return c.Visible;
            try { return (bool)mi.Invoke(c, new object[] { 0x02 }); }
            catch { return c.Visible; }
        }

        /// <summary>和 ReportOverlaps 一样，但按"控件自己的可见标志"过滤。</summary>
        static int ReportOverlapsOwn(Control parent, StringBuilder sb, string label)
        {
            if (parent == null) return 0;
            List<Control> kids = new List<Control>();
            foreach (Control c in parent.Controls) if (OwnVisible(c)) kids.Add(c);
            int n = 0;
            for (int i = 0; i < kids.Count; i++)
            {
                for (int j = i + 1; j < kids.Count; j++)
                {
                    if (kids[i].Name != null && kids[i].Name.StartsWith("pageMark", StringComparison.Ordinal)) continue;
                    if (kids[j].Name != null && kids[j].Name.StartsWith("pageMark", StringComparison.Ordinal)) continue;
                    Rectangle a = kids[i].Bounds, b = kids[j].Bounds;
                    if (a.Height <= 1 || b.Height <= 1) continue;
                    if (!a.IntersectsWith(b)) continue;
                    n++;
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                        "  !! {0}：{1} {2} 压住 {3} {4}", label, CtrlName(kids[i]), a, CtrlName(kids[j]), b));
                }
            }
            return n;
        }

        /// <summary>
        /// 交叠检查走整棵子树：分页版把控件放进了页面里的卡片，只查顶层兄弟会漏掉
        /// 卡片内部的交叠。数值框/下拉框/滑块内部还有自己的子控件，那些不算。
        /// </summary>
        static int ReportOverlapsDeep(Control parent, StringBuilder sb, string label)
        {
            int n = ReportOverlapsOwn(parent, sb, label);
            // 说明：页名水印（pageMark*）是刻意的叠放 —— 监控页的卡片铺满整页，
            // 水印就落在卡片底部的空白上。它不参与交叠判定。
            foreach (Control c in parent.Controls)
            {
                if (c is Panel || c is GroupBox) n += ReportOverlapsDeep(c, sb, label + "/" + CtrlName(c));
            }
            return n;
        }

        static void DumpControl(Control c, int depth, System.Text.StringBuilder sb)
        {
            _uiCount++;
            string txt = c.Text;
            if (txt != null && txt.Length > 44) txt = txt.Substring(0, 44) + "...";
            sb.Append(new string(' ', depth * 2));
            sb.Append(c.GetType().Name);
            if (!string.IsNullOrEmpty(txt)) sb.Append("  [").Append(txt).Append("]");
            sb.Append("  @").Append(c.Left).Append(',').Append(c.Top)
              .Append(' ').Append(c.Width).Append('x').Append(c.Height);
            if (!c.Enabled) sb.Append("  (disabled)");
            if (c is CheckBox) sb.Append(((CheckBox)c).Checked ? "  <已勾选>" : "  <未勾选>");
            if (c is Panel || c is GroupBox || c is TrackBar || c is Button || c is CheckBox)
            {
                string a = c.Anchor.ToString();
                sb.Append("  [anchor: ").Append(a).Append(']');
            }
            sb.AppendLine();
            foreach (Control ch in c.Controls) DumpControl(ch, depth + 1, sb);
        }

        static CheckBox FindCheckBox(Control root, string text)
        {
            CheckBox self = root as CheckBox;
            if (self != null && self.Text == text) return self;
            foreach (Control c in root.Controls)
            {
                CheckBox r = FindCheckBox(c, text);
                if (r != null) return r;
            }
            return null;
        }

        static string Shorten(string s)
        {
            if (s == null) return "";
            s = s.Replace("\r", " ").Replace("\n", " ");
            return s.Length <= 46 ? s : s.Substring(0, 46) + "...";
        }

        // Measures every caption against the room the control actually gives it.
        // This is how clipped option text gets found instead of guessed at.
        static void CheckTextFit(Control root, StringBuilder sb, ref int problems)
        {
            string t = root.Text;

            if (!string.IsNullOrEmpty(t))
            {
                bool check = (root is Label) || (root is CheckBox) || (root is Button) || (root is GroupBox);
                if (check)
                {
                    string[] tl = t.Replace("\r\n", "\n").Split('\n');
                    int needW = 0;
                    for (int li = 0; li < tl.Length; li++)
                    {
                        int w = TextRenderer.MeasureText(tl[li], root.Font).Width;
                        if (w > needW) needW = w;
                    }
                    int avail = root.ClientSize.Width;
                    if (root is CheckBox) avail -= 20;      // glyph + gap
                    if (root is GroupBox) avail -= 18;      // frame + leading space
                    if (needW + 3 > avail)
                    {
                        problems++;
                        sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                            "  [{0,-10}] \"{1}\"  需要 {2}px / 可用 {3}px  超出 {4}px",
                            root.GetType().Name, Shorten(tl.Length > 1 ? tl[0] + " …" : t),
                            needW, avail, needW + 3 - avail));
                    }
                    // multi-line captions must also have the height to show every line
                    int needH = tl.Length * (root.Font.Height + 2);
                    if (tl.Length > 1 && needH > root.ClientSize.Height + 2)
                    {
                        problems++;
                        sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                            "  [{0,-10}] \"{1}\"  {2} 行需要高 {3}px / 可用 {4}px",
                            root.GetType().Name, Shorten(tl[0] + " …"), tl.Length, needH, root.ClientSize.Height));
                    }
                }
            }

            // Dropdown items are the usual culprit: the closed box must fit the widest one.
            ComboBox cb = root as ComboBox;
            if (cb != null)
            {
                int avail = cb.ClientSize.Width - 24;   // arrow button
                for (int i = 0; i < cb.Items.Count; i++)
                {
                    string item = Convert.ToString(cb.Items[i]);
                    Size need = TextRenderer.MeasureText(item, cb.Font);
                    if (need.Width + 4 > avail)
                    {
                        problems++;
                        sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                            "  [ComboBox项 ] \"{0}\"  需要 {1}px / 可用 {2}px  超出 {3}px  (控件宽 {4})",
                            Shorten(item), need.Width, avail, need.Width + 4 - avail, cb.ClientSize.Width));
                    }
                }
            }

            // TextBox that displays values must not clip them either.
            TextBox tb = root as TextBox;
            if (tb != null && !string.IsNullOrEmpty(tb.Text) && tb.ReadOnly)
            {
                Size need = TextRenderer.MeasureText(tb.Text, tb.Font);
                int avail = tb.ClientSize.Width - 8;
                if (need.Width + 3 > avail)
                {
                    problems++;
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                        "  [TextBox   ] \"{0}\"  需要 {1}px / 可用 {2}px  超出 {3}px",
                        Shorten(tb.Text), need.Width, avail, need.Width + 3 - avail));
                }
            }

            // A caption can fit its own box yet still be clipped by the parent.
            if (root.Parent != null && !(root is StatusStrip) && root.Visible)
            {
                Control pc = root.Parent;
                int overR = root.Right - pc.ClientSize.Width;
                int overB = root.Bottom - pc.ClientSize.Height;
                if (overR > 0 || overB > 0)
                {
                    problems++;
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                        "  [超出父容器 ] {0} \"{1}\"  右溢出 {2}px / 下溢出 {3}px  (父容器 {4}x{5})",
                        root.GetType().Name, Shorten(t), overR > 0 ? overR : 0, overB > 0 ? overB : 0,
                        pc.ClientSize.Width, pc.ClientSize.Height));
                }
            }

            foreach (Control c in root.Controls) CheckTextFit(c, sb, ref problems);
        }

        static void CheckStatusStrip(Control root, StringBuilder sb, ref int problems)
        {
            StatusStrip ss = null;
            foreach (Control c in root.Controls) { StatusStrip s = c as StatusStrip; if (s != null) { ss = s; break; } }
            if (ss == null) return;

            int total = 0, springW = 0;
            for (int i = 0; i < ss.Items.Count; i++)
            {
                ToolStripItem it = ss.Items[i];
                int w = TextRenderer.MeasureText(it.Text, it.Font).Width + 10;
                ToolStripStatusLabel sl = it as ToolStripStatusLabel;
                if (sl != null && sl.Spring) springW = w; else total += w;
            }
            sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                "  [状态栏     ] 固定项合计 {0}px，弹性项需要 {1}px，状态栏宽 {2}px", total, springW, ss.ClientSize.Width));
            if (total + springW > ss.ClientSize.Width)
            {
                problems++;
                sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                    "  [状态栏     ] 超出 {0}px —— 弹性项(状态文字)会被截断", total + springW - ss.ClientSize.Width));
            }
        }

        static Control FindByName(Control root, string name)
        {
            if (root.Name == name) return root;
            foreach (Control c in root.Controls)
            {
                Control r = FindByName(c, name);
                if (r != null) return r;
            }
            return null;
        }

        static void LayoutSnapshot(Control root, string[] names, Dictionary<string, Rectangle> into)
        {
            for (int i = 0; i < names.Length; i++)
            {
                Control c = FindByName(root, names[i]);
                into[names[i]] = (c == null) ? Rectangle.Empty : c.Bounds;
            }
        }

        static string CtrlName(Control c)
        {
            if (!string.IsNullOrEmpty(c.Name)) return c.Name;
            string t = c.Text == null ? "" : c.Text;
            if (t.Length > 14) t = t.Substring(0, 14) + "…";
            return c.GetType().Name + "[" + t + "]";
        }

        /// <summary>
        /// 同一个容器里的兄弟控件不允许矩形交叠 —— 交叠就意味着 z 序靠上的那个会把
        /// 下面那个盖住（Controls.Add 先加的在前，后加的在后）。高度 ≤1 的是分隔线，
        /// 本来就横跨整行，跳过。
        /// </summary>
        static int ReportOverlaps(Control parent, StringBuilder sb, string label)
        {
            if (parent == null) return 0;
            List<Control> kids = new List<Control>();
            foreach (Control c in parent.Controls) if (c.Visible) kids.Add(c);
            int n = 0;
            for (int i = 0; i < kids.Count; i++)
            {
                for (int j = i + 1; j < kids.Count; j++)
                {
                    Rectangle a = kids[i].Bounds, b = kids[j].Bounds;
                    if (a.Height <= 1 || b.Height <= 1) continue;
                    if (!a.IntersectsWith(b)) continue;
                    n++;
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                        "  !! {0}：{1} {2} 压住 {3} {4}", label, CtrlName(kids[i]), a, CtrlName(kids[j]), b));
                }
            }
            return n;
        }

        // 顶层 GroupBox 数量。界面被拆散时这个数会变大，用它守住"只有两个大卡片"：
        // 系统监控（只读）+ 操作面板（所有可操作项）。
        static int CountTopCards(Control root)
        {
            int n = 0;
            for (int i = 0; i < root.Controls.Count; i++)
            {
                if (root.Controls[i] is GroupBox) n++;
            }
            return n;
        }

        static string Show(Dictionary<string, Rectangle> snap, string name)
        {
            Rectangle r;
            if (!snap.TryGetValue(name, out r) || r == Rectangle.Empty) return "(未找到)";
            return r.Width + "x" + r.Height + " @" + r.Left + "," + r.Top;
        }

        static string Show(Control root, string name)
        {
            Control c = FindByName(root, name);
            if (c == null) return "(未找到)";
            return c.Width + "x" + c.Height + " @" + c.Left + "," + c.Top;
        }
    }
}
