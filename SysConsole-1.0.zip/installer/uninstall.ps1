﻿#Requires -RunAsAdministrator
<#
    uninstall.ps1 —— 系统控制台（SysConsole）卸载脚本

    用法：
        powershell -NoProfile -ExecutionPolicy Bypass -File uninstall.ps1
        powershell -NoProfile -ExecutionPolicy Bypass -File uninstall.ps1 -KeepSettings

    -KeepSettings  直接保留配置与日志目录，不弹出询问

    流程：
        [1] 确认管理员权限
        [2] 停掉正在运行的 SysConsole
        [3] 注销开机自启（优先用程序自己的 --autostart off）
        [4] 删除开始菜单 / 桌面快捷方式
        [5] 询问是否删除 %LOCALAPPDATA%\SysConsole（配置与日志，默认保留）
        [6] 删除 %ProgramFiles%\SysConsole
        [7] 检查残留

    源码目录（installer 的上一级）不会被碰。

    编码说明：本文件必须保存为 UTF-8 带 BOM，否则 PowerShell 5.1 下中文会乱码。
#>

[CmdletBinding()]
param(
    [switch]$KeepSettings
)

$ErrorActionPreference = 'Continue'

# ------------------------------------------------------------------ 路径

$dstRoot  = Join-Path $env:ProgramFiles 'SysConsole'
$dstExe   = Join-Path $dstRoot 'SysConsole.exe'
$taskName = 'SysConsoleAutostart'
$menuName = '系统控制台.lnk'
$dataDir  = Join-Path $env:LOCALAPPDATA 'SysConsole'

# 注意：Join-Path 不接受空字符串，所以用户桌面路径要先判空再拼
$shortcuts = @(
    (Join-Path $env:ProgramData ('Microsoft\Windows\Start Menu\Programs\' + $menuName)),
    (Join-Path $env:PUBLIC ('Desktop\' + $menuName))
)
$userDesktop = [Environment]::GetFolderPath('Desktop')
if (-not [string]::IsNullOrEmpty($userDesktop)) {
    $shortcuts += (Join-Path $userDesktop $menuName)
}

# ------------------------------------------------------------------ 输出助手

function Say  ($t) { Write-Host $t }
function Step ($n, $t) { Write-Host ('  [' + $n + '] ' + $t) -ForegroundColor Cyan }
function Ok   ($t) { Write-Host ('      ' + $t) -ForegroundColor Gray }
function Warn ($t) { Write-Host ('      ' + $t) -ForegroundColor Yellow }

Say ''
Write-Host '============================================================' -ForegroundColor Cyan
Write-Host '   系统控制台 SysConsole  -  卸载' -ForegroundColor Cyan
Write-Host '============================================================' -ForegroundColor Cyan

# ------------------------------------------------------------------ [1] 权限

Step 1 '检查管理员权限'
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host ''
    Write-Host '卸载失败：需要管理员权限。请右键选择“以管理员身份运行”。' -ForegroundColor Red
    Write-Host ''
    exit 1
}
Ok '已具备管理员权限'

# ------------------------------------------------------------------ [2] 停进程

Step 2 '停止正在运行的 SysConsole'
$procs = @(Get-Process -Name 'SysConsole' -ErrorAction SilentlyContinue)
if ($procs.Count -eq 0) {
    Ok '当前没有正在运行的实例'
} else {
    foreach ($p in $procs) {
        Ok ('结束进程 PID ' + $p.Id)
        try { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue } catch { }
    }
    for ($i = 0; $i -lt 24; $i++) {
        Start-Sleep -Milliseconds 500
        if (@(Get-Process -Name 'SysConsole' -ErrorAction SilentlyContinue).Count -eq 0) { break }
    }
    if (@(Get-Process -Name 'SysConsole' -ErrorAction SilentlyContinue).Count -eq 0) {
        Ok '进程已全部退出'
    } else {
        Warn '仍有进程没退出，后面的删除可能会失败，建议手动结束后重试。'
    }
}

# ------------------------------------------------------------------ [3] 注销自启

Step 3 '注销开机自启'
if (Test-Path -LiteralPath $dstExe) {
    try {
        $out = & $dstExe --autostart off 2>&1
        $text = (($out | Out-String).Trim()) -replace "`r?`n", '  |  '
        if ([string]::IsNullOrEmpty($text)) { Ok '已调用 --autostart off' } else { Ok $text }
    } catch {
        Warn ('调用 --autostart off 出错：' + $_.Exception.Message)
    }
} else {
    Ok '程序文件已不在，改为直接注销计划任务'
}

# 兜底：不管上面走哪条路，只要任务还在就删掉
$task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
if ($task) {
    try {
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction Stop
        Ok ('已删除计划任务 ' + $taskName)
    } catch {
        Warn ('Unregister-ScheduledTask 失败：' + $_.Exception.Message + '，改用 schtasks')
        $r = schtasks /Delete /TN $taskName /F 2>&1
        Ok (($r | Out-String).Trim())
    }
    if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
        Warn ('计划任务 ' + $taskName + ' 仍然存在，请手动在“任务计划程序”里删除。')
    }
} else {
    Ok '计划任务本来就不存在'
}

# ------------------------------------------------------------------ [4] 快捷方式

Step 4 '删除快捷方式'
$removed = 0
foreach ($l in $shortcuts) {
    if ([string]::IsNullOrEmpty($l)) { continue }
    if (Test-Path -LiteralPath $l) {
        try {
            Remove-Item -LiteralPath $l -Force -ErrorAction Stop
            Ok ('已删除 ' + $l)
            $removed++
        } catch {
            Warn ('删除失败 ' + $l + '：' + $_.Exception.Message)
        }
    }
}
if ($removed -eq 0) { Ok '没有找到需要删除的快捷方式' }

# ------------------------------------------------------------------ [5] 配置目录

Step 5 '配置与日志目录'
Say        ('      位置：' + $dataDir)
if (Test-Path -LiteralPath $dataDir) {
    $doDelete = $false
    if ($KeepSettings) {
        Ok '-KeepSettings：保留配置与日志'
    } else {
        try {
            $ans = Read-Host '      是否一并删除？（输入 y 删除，直接回车保留）'
            if ($ans -match '^\s*[Yy]') { $doDelete = $true }
        } catch {
            Ok '当前环境无法交互输入，按默认保留处理'
        }
    }
    if ($doDelete) {
        try {
            Remove-Item -LiteralPath $dataDir -Recurse -Force -ErrorAction Stop
            Ok '已删除配置与日志'
        } catch {
            Warn ('删除失败：' + $_.Exception.Message)
        }
    } else {
        Ok '已保留（里面有日志、温度墙/超温保护/背光颜色等设置）'
    }
} else {
    Ok '目录不存在，无需处理'
}

# ------------------------------------------------------------------ [6] 程序目录

Step 6 '删除程序目录 ' + $dstRoot
if (Test-Path -LiteralPath $dstRoot) {
    try {
        Remove-Item -LiteralPath $dstRoot -Recurse -Force -ErrorAction Stop
    } catch {
        Warn ('删除出错：' + $_.Exception.Message)
    }
    if (Test-Path -LiteralPath $dstRoot) {
        Warn '目录仍然存在，可能有文件被占用。请重试，或手动删除。'
    } else {
        Ok '已删除'
    }
} else {
    Ok '本来就没有安装到 Program Files'
}

# ------------------------------------------------------------------ [7] 残留检查

Step 7 '残留检查'
$leftover = 0
if (Test-Path -LiteralPath $dstRoot) { Warn ('程序目录仍在：' + $dstRoot); $leftover++ }
if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) { Warn ('计划任务仍在：' + $taskName); $leftover++ }
foreach ($l in $shortcuts) {
    if (-not [string]::IsNullOrEmpty($l) -and (Test-Path -LiteralPath $l)) { Warn ('快捷方式仍在：' + $l); $leftover++ }
}
if (@(Get-Process -Name 'SysConsole' -ErrorAction SilentlyContinue).Count -gt 0) { Warn '仍有 SysConsole 进程在运行'; $leftover++ }

Say ''
if ($leftover -eq 0) {
    Write-Host '卸载完成，没有留下任何残留。' -ForegroundColor Green
} else {
    Write-Host ('卸载完成，但有 ' + $leftover + ' 项残留（见上面的黄色提示）。') -ForegroundColor Yellow
}
if (Test-Path -LiteralPath $dataDir) {
    Say ''
    Say ('  配置与日志仍保留在：' + $dataDir)
    Say  '  不需要的话可以直接删掉这个目录。'
}
Say ''
exit 0
