#Requires -RunAsAdministrator
# uninstall.ps1 - remove SysConsole: autostart task, shortcuts, program files.
# Run ELEVATED. Leaves the source tree (this folder) untouched.
#
# ASCII only on purpose (Windows PowerShell 5.1 mangles UTF-8 scripts without a BOM).

$ErrorActionPreference = 'Continue'

$dstRoot = Join-Path $env:ProgramFiles 'SysConsole'
$cnName = [string]([char]0x7CFB + [char]0x7EDF + [char]0x63A7 + [char]0x5236 + [char]0x53F0)

Write-Host '=== Uninstalling SysConsole ===' -ForegroundColor Cyan

Write-Host '  [1] stopping running instance'
Get-Process SysConsole -ErrorAction SilentlyContinue | ForEach-Object {
    Write-Host ("      kill PID " + $_.Id)
    Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
}
Start-Sleep -Seconds 3

Write-Host '  [2] removing autostart task'
$r = schtasks /Delete /TN "SysConsoleAutostart" /F 2>&1
Write-Host ("      " + ($r -join ' '))
$still = Get-ScheduledTask -TaskName 'SysConsoleAutostart' -ErrorAction SilentlyContinue
Write-Host ("      task gone: " + ($null -eq $still))

Write-Host '  [3] removing shortcuts'
$targets = @(
    (Join-Path $env:ProgramData ("Microsoft\Windows\Start Menu\Programs\" + $cnName + ".lnk")),
    (Join-Path $env:PUBLIC ("Desktop\" + $cnName + ".lnk"))
)
foreach ($l in $targets) {
    if (Test-Path -LiteralPath $l) {
        Remove-Item -LiteralPath $l -Force -ErrorAction SilentlyContinue
        Write-Host ("      removed " + $l)
    }
}

Write-Host '  [4] removing program files'
if (Test-Path $dstRoot) {
    Remove-Item -LiteralPath $dstRoot -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host ("      " + $dstRoot + " gone: " + (-not (Test-Path $dstRoot)))
} else {
    Write-Host '      not installed in Program Files (skipped)'
}

Write-Host '  [5] optional data folder'
$dataDir = Join-Path $env:LOCALAPPDATA 'SysConsole'
Write-Host ("      logs kept at: " + $dataDir)
Write-Host '      delete it manually if you want logs removed too.'

Write-Host ''
Write-Host 'Uninstall complete.' -ForegroundColor Green
